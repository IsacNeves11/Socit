export function scoreAlert(alert){
  const metric = key => Math.max(1, Math.min(5, Number(alert[key] ?? ({threat:2,impact:2,assetCriticality:2,context:2}[key])) || 2));
  const baseline = Math.max(1, Math.min(5, Math.ceil((metric("threat")+metric("impact")+metric("assetCriticality")+metric("context"))/4)));
  const type = String(alert.event_type || alert.threat_type || alert.type || "unknown").trim().toLowerCase().replaceAll("-","_");
  const text = [alert.title,alert.description,alert.event_type,alert.threat_type].filter(Boolean).join(" ").toLowerCase();
  const count = Math.max(1, Number(alert.events_count ?? alert.event_count ?? alert.events ?? 1) || 1);
  const loginTypes = new Set(["brute_force","authentication_failed","authentication_failure","failed_login","login_failure","login_incorrect","invalid_login","invalid_credentials","multiple_failed_logins","failed_password","ssh_failed","login_failed"]);
  const loginFailure = loginTypes.has(type) || ["failed login","failed password","authentication failure","multiple failed","login incorreto","senha incorreta","invalid credentials","brute force","força bruta"].some(x=>text.includes(x));
  let score;
  if(loginFailure) score = baseline + (count >= 3 || ["brute_force","multiple_failed_logins"].includes(type) ? 4 : 1);
  else score = Math.max(baseline, ({malware:6,data_exfiltration:6,malicious_ip:5,anomalous_login:4,port_scan:2}[type] || 1));
  if(alert.timestamp){ const d=new Date(alert.timestamp); if(!Number.isNaN(d.getTime()) && (d.getHours()>=22 || d.getHours()<6)) score+=2; }
  const context = [alert.username,alert.asset,alert.target,alert.business_unit,alert.department,alert.title,alert.description].filter(Boolean).join(" ").toLowerCase();
  if(/finance|finan|fiscal|diretor|diretoria|executiv|executive|president|presidente|\bcfo\b|\bceo\b|\bboard\b/.test(context)) score+=3;
  return Math.max(1,Math.min(10,Math.trunc(score)));
}

export function severityFromScore(score){
  if(score >= 7) return "critical";
  if(score >= 6) return "high";
  if(score >= 4) return "medium";
  return "low";
}

export function severityLabel(severity){
  return {critical:"CRÍTICO",high:"ALTO",medium:"MÉDIO",low:"BAIXO"}[severity];
}

export function priorityFromSeverity(severity){
  return {critical:1,high:2,medium:3,low:4}[severity];
}

export function enrich(alert){
  const score = scoreAlert(alert);
  const severity = severityFromScore(score);
  return {...alert, score, severity, priority:priorityFromSeverity(severity)};
}
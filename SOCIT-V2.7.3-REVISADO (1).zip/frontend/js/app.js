import { severityLabel } from "./scoring.js";
import { playbooks } from "./playbooks.js";

const SOC_API = window.SOC_API || "/api";
const WAZUH_DEMO_TOKEN = typeof window.SOC_WAZUH_DEMO_TOKEN === "string" ? window.SOC_WAZUH_DEMO_TOKEN : "";
const APP_VERSION = "2.7.3";
let authToken = "";
let currentUser = null;
let alerts = [];
let currentView = "dashboard";
let selectedId = null;
let apiMetrics = null;
let apiHealth = null;
let refreshInFlight = false;
let refreshTimer = null;
let incidentFilters = {q:"", severity:"", status:""};
let detailRequestSeq = 0;
let demoEnvironment = false;

const content = document.querySelector("#app-content");
const title = document.querySelector("#page-title");
const toast = document.querySelector("#toast");
const authScreen = document.querySelector("#auth-screen");
const appShell = document.querySelector("#app-shell");

function setAuth(token, user){
  authToken = token || "";
  currentUser = user || null;
}
function getSavedUser(){ return currentUser; }
function renderLogin(message=""){
  appShell.hidden=true;
  authScreen.hidden=false;
  authScreen.innerHTML=`<div class="auth-card">
    <div class="brand auth-brand"><div class="brand-mark">S</div><div><strong>SOC<span>IT</span></strong><small>INTELLIGENT TRIAGE · V2.7.3</small></div></div>
    <div class="eyebrow">ACESSO OPERACIONAL</div><h1>Entrar no SOC</h1><p class="muted">Use uma conta autorizada para acessar incidentes, playbooks e ações operacionais.</p>
    <form id="loginForm" class="auth-form">
      <label>Usuário<input id="loginUser" class="input" autocomplete="username" required maxlength="80" placeholder="analyst"></label>
      <label>Senha<input id="loginPass" class="input" type="password" autocomplete="current-password" required maxlength="200" placeholder="••••••••••••"></label>
      <button class="btn btn-primary" type="submit">Entrar</button>
      <div id="loginError" class="auth-error">${esc(message)}</div>
    </form>
    <div class="auth-demo"><strong>Acesso protegido</strong><span>Use credenciais autorizadas para este ambiente. Nunca compartilhe senhas ou tokens de integração.</span></div>
  </div>`;
  document.querySelector("#loginForm").addEventListener("submit", async e=>{
    e.preventDefault();
    const btn=e.currentTarget.querySelector("button"); btn.disabled=true;
    try{
      const data=await rawFetch("/auth/login",{method:"POST",body:JSON.stringify({username:document.querySelector("#loginUser").value,password:document.querySelector("#loginPass").value})},false);
      setAuth(data.access_token,data.user);
      showApp();
      await syncFromBackend(false);
      render();
      startAutoRefresh();
    }catch(err){
      document.querySelector("#loginError").textContent=err.message||"Falha ao autenticar.";
    }finally{btn.disabled=false;}
  });
  setTimeout(()=>document.querySelector("#loginUser")?.focus(),0);
}
function showApp(){
  authScreen.hidden=true;
  appShell.hidden=false;
  currentUser=currentUser||getSavedUser();
  document.querySelector("#user-chip").textContent=currentUser?`${currentUser.display_name} · ${currentUser.role}`:"";
  document.querySelectorAll(".admin-only").forEach(el=>el.style.display=currentUser?.role==="admin"?"flex":"none");
  setDemoControls(false);
}
function forceLogout(message="Sessão encerrada."){
  clearInterval(refreshTimer); refreshTimer=null; refreshInFlight=false;
  setAuth("",null); currentView="dashboard"; selectedId=null;
  renderLogin(message);
}
async function bootstrapAuth(){
  renderLogin();
}

function setDemoControls(visible){
  document.querySelectorAll(".demo-only").forEach(el=>{el.style.display=visible?"inline-flex":"none";});
}
function showToast(message){
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(()=>toast.classList.remove("show"),2400);
}
function esc(v=""){
  return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}
function severityBadge(a){ return `<span class="badge sev ${esc(a.severity)}">${severityLabel(a.severity)||"N/D"}</span>`; }
function stats(){
  return alerts.reduce((o,a)=>{o[a.severity]=(o[a.severity]||0)+1;return o},{critical:0,high:0,medium:0,low:0});
}
function sorted(){ return [...alerts].sort((a,b)=>a.priority-b.priority || b.score-a.score || b.events-a.events); }
function durationLabel(seconds){
  if(seconds==null || Number.isNaN(Number(seconds))) return "—";
  const s=Math.max(0,Math.round(Number(seconds)));
  if(s<60) return `${s}s`;
  const m=Math.floor(s/60);
  if(m<60) return `${m}m`;
  const h=Math.floor(m/60), mm=m%60;
  return `${h}h ${mm}m`;
}

function renderDashboard(){
  const activeSeverity=apiMetrics?.by_active_severity||apiMetrics?.by_severity; const s=activeSeverity ? {critical:activeSeverity.critical||0,high:activeSeverity.high||0,medium:activeSeverity.medium||0,low:activeSeverity.low||0} : stats(), queue=sorted().filter(a=>! ["resolved","false_positive"].includes(a.statusCode)).slice(0,6);
  const totalIncidents=apiMetrics?.total_incidents ?? alerts.length;
  const totalEvents=apiMetrics?.total_consolidated_events ?? alerts.reduce((n,a)=>n+a.events,0);
  const activeTotal=(s.critical||0)+(s.high||0)+(s.medium||0)+(s.low||0);
  const queueSize=apiHealth?.queue_size ?? 0;
  const ops=apiMetrics?.operations||{};
  title.textContent="Visão operacional";
  content.innerHTML=`
  <div class="grid stats">
    <div class="card stat accent-red"><div class="label">Críticos</div><div class="value">${s.critical||0}</div><div class="sub">Prioridade imediata</div></div>
    <div class="card stat accent-orange"><div class="label">Altos</div><div class="value">${s.high||0}</div><div class="sub">Análise prioritária</div></div>
    <div class="card stat accent-yellow"><div class="label">Médios</div><div class="value">${s.medium||0}</div><div class="sub">Triagem programada</div></div>
    <div class="card stat accent-cyan"><div class="label">Incidentes</div><div class="value">${totalIncidents}</div><div class="sub">${totalEvents} eventos consolidados</div></div>
  </div>
  <section class="card section" style="margin-bottom:18px">
    <div class="section-head"><h2>Indicadores operacionais</h2><span class="muted">Baseados no histórico de incidentes</span></div>
    <div class="grid three">
      <div class="fact"><small>MTTA MÉDIO</small><strong>${durationLabel(ops.mtta_seconds_avg)}</strong></div>
      <div class="fact"><small>MTTR MÉDIO</small><strong>${durationLabel(ops.mttr_seconds_avg)}</strong></div>
      <div class="fact"><small>PROCESSAMENTO DA FILA</small><strong>${durationLabel(ops.queue_processing_seconds_avg)}</strong></div>
    </div>
  </section>
  <div class="grid two">
    <section class="card section">
      <div class="section-head"><h2>Fila prioritária</h2><button class="btn" data-view-btn="incidents">Ver todos</button></div>
      <div class="queue">${queue.length?queue.map(row).join(""):emptyState()}</div>
    </section>
    <section class="card section">
      <div class="section-head"><h2>Distribuição de risco</h2><span class="muted">${activeTotal} ativos</span></div>
      ${riskBar("critical",s.critical||0,activeTotal)}
      ${riskBar("high",s.high||0,activeTotal)}
      ${riskBar("medium",s.medium||0,activeTotal)}
      ${riskBar("low",s.low||0,activeTotal)}
      <div style="margin-top:20px;padding:12px;background:#0a1726;border:1px solid #183049;border-radius:10px">
        <div class="muted" style="font-size:10px;text-transform:uppercase">Pipeline</div>
        <strong>${queueSize} alertas aguardando processamento</strong>
        <div class="muted" style="font-size:11px;margin-top:3px">A fila é persistida no banco configurado e processada por workers.</div>
      </div>
    </section>
  </div>`;
  bind();
}
function emptyState(){ return `<div class="empty">Nenhum incidente encontrado.</div>`; }
function riskBar(k,n,total){
  const pct=total?Math.round(n/total*100):0;
  return `<div class="bar-row"><span class="sev ${k}">${severityLabel(k)}</span><div class="bar"><div class="fill ${k}" style="width:${pct}%"></div></div><strong>${n}</strong></div>`;
}
function row(a){
  return `<div class="incident-row" data-open="${esc(a.id)}">
   <div>${severityBadge(a)}</div>
   <div><div class="row-title">${esc(a.id)} · ${esc(a.type)}</div><div class="row-meta">${esc(a.created)} · ${esc(a.asset)} · ${a.events} eventos</div></div>
   <div class="muted">P${a.priority}</div><div class="score">${a.score}/10</div>
  </div>`;
}

function renderIncidents(){
  title.textContent="Fila de incidentes";
  content.innerHTML=`
  <section class="card section">
    <div class="toolbar">
      <input id="search" class="input" value="${esc(incidentFilters.q)}" placeholder="Buscar ID, tipo, origem, alvo...">
      <select id="severityFilter" class="select"><option value="">Todos os riscos</option><option value="critical" ${incidentFilters.severity==='critical'?'selected':''}>Crítico</option><option value="high" ${incidentFilters.severity==='high'?'selected':''}>Alto</option><option value="medium" ${incidentFilters.severity==='medium'?'selected':''}>Médio</option><option value="low" ${incidentFilters.severity==='low'?'selected':''}>Baixo</option></select>
      <select id="statusFilter" class="select"><option value="">Todos os status</option><option value="open" ${incidentFilters.status==='open'?'selected':''}>Novo</option><option value="investigating" ${incidentFilters.status==='investigating'?'selected':''}>Em investigação</option><option value="resolved" ${incidentFilters.status==='resolved'?'selected':''}>Resolvido</option><option value="escalated" ${incidentFilters.status==='escalated'?'selected':''}>Escalado</option><option value="false_positive" ${incidentFilters.status==='false_positive'?'selected':''}>Falso positivo</option></select>
    </div>
    <div id="incidentTable" class="table-wrap"></div>
  </section>`;
  const renderTable=()=>{
    const q=(document.querySelector("#search")?.value||"");
    const sf=document.querySelector("#severityFilter")?.value||"";
    const st=document.querySelector("#statusFilter")?.value||"";
    incidentFilters={q, severity:sf, status:st};
    const qLower=q.toLowerCase();
    const data=sorted().filter(a=>{
      const statusOk=!st||a.statusCode===st;
      return (!qLower||JSON.stringify(a).toLowerCase().includes(qLower)) && (!sf||a.severity===sf) && statusOk;
    });
    document.querySelector("#incidentTable").innerHTML=data.length?`<table class="table"><thead><tr><th>Prioridade</th><th>Incidente</th><th>Risco</th><th>Origem</th><th>Ativo</th><th>Eventos</th><th>Status</th></tr></thead><tbody>${data.map(a=>`<tr class="clickable" data-open="${esc(a.id)}"><td><strong>P${a.priority}</strong></td><td><strong>${esc(a.id)}</strong><br><span class="muted">${esc(a.type)}</span></td><td>${severityBadge(a)}</td><td>${esc(a.source)}</td><td>${esc(a.asset)}</td><td>${a.events}</td><td>${esc(a.status)}</td></tr>`).join("")}</tbody></table>`:emptyState();
    bind();
  };
  ["search","severityFilter","statusFilter"].forEach(id=>{
    const el=document.querySelector("#"+id);
    el.addEventListener("input",renderTable);
    el.addEventListener("change",renderTable);
  });
  renderTable();
}

async function renderDetail(id){
  const base=alerts.find(x=>x.id===id);
  if(!base){ currentView="incidents"; selectedId=null; return renderIncidents(); }
  const requestSeq=++detailRequestSeq;
  selectedId=id;
  currentView="detail";
  title.textContent=`${base.id} · ${base.type}`;
  try{
    const full=await SOCV2.incident(id);
    if(requestSeq!==detailRequestSeq || selectedId!==id || currentView!=="detail") return;
    const mapped=mapIncident(full);
    const a={...base,...mapped,audit:Array.isArray(full.audit)?full.audit:[],rawEvents:Array.isArray(full.events)?full.events:[]};
    renderDetailView(a);
  }catch{
    if(requestSeq===detailRequestSeq && selectedId===id && currentView==="detail") renderDetailView(base);
  }
}
function renderDetailView(a){
  const pb=playbooks[a.playbook]||{title:"Playbook não disponível",summary:"Sem playbook cadastrado.",steps:[]};
  const auditHtml=a.audit?.length ? a.audit.map(item=>`<div class="timeline-item"><small>${esc(new Date(item.created_at).toLocaleString("pt-BR"))}</small><p>Status: <strong>${esc(item.from_status||"-")}</strong> → <strong>${esc(item.to_status||"-")}</strong>${item.note?` · ${esc(item.note)}`:""}</p></div>`).join("") : `<div class="timeline-item"><small>Histórico</small><p>Nenhuma ação operacional registrada ainda.</p></div>`;
  content.innerHTML=`
  <div class="detail">
   <section class="card detail-card">
    <div class="hero-risk"><div><div class="eyebrow">INCIDENTE ${esc(a.id)}</div><h2>${esc(a.type)}</h2><div class="muted">${esc(a.created)} · ${esc(a.source)} → ${esc(a.target)}</div></div><div style="text-align:right">${severityBadge(a)}<div class="risk-number">${a.score}<span style="font-size:13px;color:var(--muted)">/10</span></div><div class="muted">prioridade P${a.priority}</div></div></div>
    <div class="detail-tools"><button class="btn" data-view-btn="incidents">← Voltar para incidentes</button><label class="muted">Responsável <input id="ownerInput" class="input compact" value="${esc(a.owner||"Não atribuído")}" maxlength="120" readonly aria-readonly="true"></label><label class="muted">Observação <input id="noteInput" class="input compact" maxlength="1000" placeholder="Nota opcional"></label></div>
    <div class="facts">
     <div class="fact"><small>ATIVO AFETADO</small><strong>${esc(a.asset)}</strong></div>
     <div class="fact"><small>EVENTOS CONSOLIDADOS</small><strong>${a.events}</strong></div>
     <div class="fact"><small>STATUS</small><strong>${esc(a.status)}</strong></div>
     <div class="fact"><small>ORIGEM</small><strong>${esc(a.source)}</strong></div>
     <div class="fact"><small>USUÁRIO</small><strong>${esc(a.username||"N/A")}</strong></div>
    </div>
    <h3>O que aconteceu</h3><p class="muted">${esc(a.description)}</p>
    <h3>Evidências correlacionadas</h3><ul>${a.evidence.map(e=>`<li style="margin:8px 0">${esc(e)}</li>`).join("")}</ul>
    <h3>Por que esta prioridade?</h3><p class="muted">Score de risco: ${a.score}/10. O motor combina ameaça (${a.threat}/5), impacto (${a.impact}/5), criticidade do ativo (${a.assetCriticality}/5) e contexto (${a.context}/5), depois normaliza a pontuação para a escala do projeto.</p>
    <div class="timeline"><div class="timeline-item"><small>${esc(a.created)}</small><p>Incidente processado pelo pipeline de triagem.</p></div>${auditHtml}</div>
   </section>
   <aside class="card detail-card">
     <div class="eyebrow">PLAYBOOK BÁSICO</div><h2>${esc(pb.title)}</h2><p class="muted">${esc(pb.summary)}</p>
     <div>${pb.steps.map((s,i)=>`<div class="playbook-step"><div class="num">${i+1}</div><div>${esc(s)}</div></div>`).join("")}</div>
     <div style="display:grid;gap:8px;margin-top:18px">
       <button class="btn btn-primary" data-action="investigate">Iniciar investigação</button>
       <button class="btn" data-action="resolve">Marcar como resolvido</button>
       <button class="btn btn-danger" data-action="escalate">Escalar incidente</button>
       <button class="btn" data-action="falsePositive">Marcar como falso positivo</button>
     </div>
   </aside>
  </div>`;
  bind();
}
function renderPlaybooks(){
  title.textContent="Playbooks operacionais";
  content.innerHTML=`<div class="grid two">${Object.values(playbooks).map(pb=>`<section class="card section"><div class="eyebrow">PLAYBOOK</div><h2>${esc(pb.title)}</h2><p class="muted">${esc(pb.summary)}</p>${pb.steps.map((s,i)=>`<div class="playbook-step"><div class="num">${i+1}</div><div>${esc(s)}</div></div>`).join("")}</section>`).join("")}</div>`;
}
async function renderUsers(){
  title.textContent="Gestão de usuários";
  if(currentUser?.role!=="admin"){ content.innerHTML=emptyState(); return; }
  try{
    const data=await v2Fetch("/users");
    const rows=data.items||[];
    content.innerHTML=`<section class="card section"><div class="section-head"><h2>Usuários e papéis</h2><button class="btn btn-primary" id="newUserBtn">+ Novo usuário</button></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>Usuário</th><th>Nome</th><th>Papel</th><th>Status</th><th>Ação</th></tr></thead><tbody>${rows.map(u=>`<tr><td><strong>${esc(u.username)}</strong></td><td>${esc(u.display_name)}</td><td>${esc(u.role)}</td><td>${u.active?"Ativo":"Inativo"}</td><td><button class="btn" data-user-edit="${esc(u.id)}">Editar</button></td></tr>`).join("")}</tbody></table></div>
    </section>`;
    document.querySelector("#newUserBtn").onclick=()=>showUserDialog();
    document.querySelectorAll("[data-user-edit]").forEach(btn=>btn.onclick=()=>showUserDialog(rows.find(x=>x.id===btn.dataset.userEdit)));
  }catch(err){ content.innerHTML=`<section class="card section"><p class="muted">${esc(err.message)}</p></section>`; }
}
function showUserDialog(user=null){
  const isEdit=!!user;
  const html=`<div class="modal-backdrop" id="userModal"><div class="modal card"><div class="section-head"><h2>${isEdit?"Editar usuário":"Novo usuário"}</h2><button class="btn" id="closeUserModal">Fechar</button></div>
    ${isEdit?"":`<label>Usuário<input id="uUsername" class="input" maxlength="80" placeholder="novo.analista"></label>`}
    <label>Nome<input id="uName" class="input" maxlength="120" value="${esc(user?.display_name||"")}"></label>
    <label>Papel<select id="uRole" class="select"><option value="analyst" ${user?.role==="analyst"?"selected":""}>Analista</option><option value="supervisor" ${user?.role==="supervisor"?"selected":""}>Supervisor</option><option value="admin" ${user?.role==="admin"?"selected":""}>Administrador</option></select></label>
    ${isEdit?`<label><input id="uActive" type="checkbox" ${user.active?"checked":""}> Usuário ativo</label>`:`<label>Senha inicial<input id="uPassword" class="input" type="password" minlength="12" placeholder="Ex.: Analyst@123456"></label>`}
    <button class="btn btn-primary" id="saveUserBtn">Salvar</button><div id="userModalMsg" class="auth-error"></div>
  </div></div>`;
  document.body.insertAdjacentHTML("beforeend",html);
  document.querySelector("#closeUserModal").onclick=()=>document.querySelector("#userModal")?.remove();
  document.querySelector("#saveUserBtn").onclick=async()=>{
    const msg=document.querySelector("#userModalMsg");
    try{
      let data;
      if(isEdit){ data=await v2Fetch(`/users/${encodeURIComponent(user.id)}`,{method:"PATCH",body:JSON.stringify({display_name:document.querySelector("#uName").value,role:document.querySelector("#uRole").value,active:document.querySelector("#uActive").checked})}); }
      else { data=await v2Fetch("/users",{method:"POST",body:JSON.stringify({username:document.querySelector("#uUsername").value,display_name:document.querySelector("#uName").value,role:document.querySelector("#uRole").value,password:document.querySelector("#uPassword").value})}); }
      document.querySelector("#userModal")?.remove(); await renderUsers(); showToast("Usuário atualizado.");
    }catch(err){msg.textContent=err.message;}
  };
}

function renderReports(){
  title.textContent="Relatórios";
  const s=stats();
  const totalIncidents=apiMetrics?.total_incidents ?? alerts.length;
  const totalEvents=apiMetrics?.total_consolidated_events ?? alerts.reduce((n,a)=>n+a.events,0);
  const reduction=apiMetrics?.correlation_reduction_percent ?? 0;
  content.innerHTML=`<section class="card section">
   <div class="section-head"><h2>Resumo de triagem</h2><button class="btn btn-primary" id="exportBtn">Exportar CSV</button></div>
   <div class="facts">
    <div class="fact"><small>INCIDENTES</small><strong>${totalIncidents}</strong></div>
    <div class="fact"><small>EVENTOS CONSOLIDADOS</small><strong>${totalEvents}</strong></div>
    <div class="fact"><small>CRÍTICOS + ALTOS</small><strong>${(apiMetrics?.by_severity?.critical||s.critical||0)+(apiMetrics?.by_severity?.high||s.high||0)}</strong></div>
    <div class="fact"><small>REDUÇÃO POR CORRELAÇÃO*</small><strong>${reduction}%</strong></div>
   </div>
   <p class="muted" style="margin-top:18px">*Indicador operacional: relação entre incidentes consolidados e eventos contabilizados no pipeline. Não mede efetividade de detecção.</p>
  </section>`;
  document.querySelector("#exportBtn").onclick=exportCSV;
}
async function exportCSV(){
  try{
    const all=[];
    let offset=0;
    do{
      const page=await SOCV2.incidents(`?limit=500&offset=${offset}`);
      all.push(...(page.items||[]));
      offset += page.items?.length||0;
      if(!page.items?.length || !page.has_more) break;
    }while(offset<50000);
    const header=["ID","Tipo","Origem","Alvo","Ativo","Eventos","Score","Severidade","Prioridade","Status"];
    const rows=all.map(x=>{const m=mapIncident(x); return [m.id,m.type,m.source,m.target,m.asset,m.events,m.score,severityLabel(m.severity),m.priority,m.status];});
    const csvSafe=v=>{const text=String(v??""); return /^[=+\-@]/.test(text)?`'${text}`:text;};
    const csv=[header,...rows].map(r=>r.map(v=>`"${csvSafe(v).replaceAll('"','""')}"`).join(";")).join("\n");
    const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"});
    const url=URL.createObjectURL(blob), link=document.createElement("a");
    link.href=url;link.download="soc-triagem-relatorio.csv";link.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    showToast(`Relatório CSV exportado (${all.length} incidentes).`);
  }catch(err){ console.error(err); showToast("Não foi possível exportar o relatório."); }
}

function render(){
  if(currentView==="dashboard")renderDashboard();
  else if(currentView==="incidents")renderIncidents();
  else if(currentView==="detail" && selectedId) renderDetail(selectedId);
  else if(currentView==="playbooks")renderPlaybooks();
  else if(currentView==="reports")renderReports();
  else if(currentView==="users")renderUsers();
}
function bind(){
  document.querySelectorAll("[data-open]").forEach(el=>el.onclick=()=>renderDetail(el.dataset.open));
  document.querySelectorAll("[data-view-btn]").forEach(el=>el.onclick=()=>{currentView=el.dataset.viewBtn; if(currentView!=="detail") selectedId=null; render()});
  document.querySelectorAll("[data-action]").forEach(el=>el.onclick=async()=>{
    const a=alerts.find(x=>x.id===selectedId); if(!a)return;
    const statusMap={investigate:"investigating",resolve:"resolved",escalate:"escalated",falsePositive:"false_positive"};
    const status=statusMap[el.dataset.action];
    const note=document.querySelector("#noteInput")?.value.trim() || null;
    if(status==="resolved" && a.score>=10 && (!note || note.length<10)){
      showToast("Score 10: registre a ação de contenção na Observação (mínimo de 10 caracteres).Não encerre sem documentar a contenção.");
      document.querySelector("#noteInput")?.focus();
      return;
    }
    const ownerUserId=status==="investigating" ? currentUser?.id : undefined;
    try {
      await SOCV2.updateStatus(a.id,status,undefined,note,ownerUserId);
      showToast(`${a.id} atualizado no backend.`);
      await syncFromBackend(false);
      await renderDetail(a.id);
    } catch(err){
      console.error(err);
      showToast("Backend indisponível — nenhuma alteração foi aplicada localmente.");
    }
  });
}

document.querySelectorAll(".nav-item").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");
  currentView=btn.dataset.view;
  selectedId=null;
  render();
});

document.querySelector("#passwordBtn").onclick=()=>{
  document.body.insertAdjacentHTML("beforeend",`<div class="modal-backdrop" id="passwordModal"><div class="modal card"><div class="section-head"><h2>Trocar senha</h2><button class="btn" id="closePasswordModal">Fechar</button></div>
    <label>Senha atual<input id="currentPassword" class="input" type="password" autocomplete="current-password"></label>
    <label>Nova senha<input id="newPassword" class="input" type="password" autocomplete="new-password" placeholder="12+ caracteres, maiúscula, minúscula, número e símbolo"></label>
    <button class="btn btn-primary" id="savePasswordBtn">Alterar senha</button><div id="passwordMsg" class="auth-error"></div>
  </div></div>`);
  document.querySelector("#closePasswordModal").onclick=()=>document.querySelector("#passwordModal")?.remove();
  document.querySelector("#savePasswordBtn").onclick=async()=>{
    const msg=document.querySelector("#passwordMsg");
    try{
      const r=await v2Fetch("/auth/password",{method:"POST",body:JSON.stringify({current_password:document.querySelector("#currentPassword").value,new_password:document.querySelector("#newPassword").value})});
      document.querySelector("#passwordModal")?.remove(); forceLogout(r.message||"Senha alterada. Entre novamente.");
    }catch(err){ msg.textContent=err.message; }
  };
};

document.querySelector("#logoutBtn").onclick=async()=>{
  try{ if(authToken) await v2Fetch("/auth/logout",{method:"POST"}); }catch{}
  forceLogout("Você saiu da sessão.");
};

document.querySelector("#simulateBtn").onclick=async()=>{
  if(!demoEnvironment){showToast("Simulação desativada fora do ambiente demo.");return;}
  const n=Math.floor(Math.random()*900)+100;
  const ip=`203.0.113.${Math.floor(Math.random()*200+1)}`;
  const payload={alert_id:`sim-${Date.now()}-${Math.floor(Math.random()*1e6)}`,source:"soc-simulator",event_type:"brute_force",title:`Brute force simulado ${n}`,source_ip:ip,username:"admin",asset:"Servidor de autenticação",asset_criticality:5,threat:5,impact:5,context:5};
  try {
    const r=await SOCV2.ingestSync(payload);
    showToast(`Alerta processado → ${r.incident_id||"sem incidente"}`);
    await syncFromBackend(false);
  } catch(err) {
    console.error(err);
    showToast("Não foi possível enviar o alerta.");
  }
};


document.querySelector("#simulateWazuhBtn")?.addEventListener("click", async()=>{
  if(!demoEnvironment){showToast("Simulação Wazuh desativada fora do ambiente demo.");return;}
  const now = new Date().toISOString();
  const wazuh = {
    timestamp: now,
    id: `wazuh-demo-${Date.now()}`,
    rule: {id:"5710", level:12, description:"sshd: Multiple failed logins detected — possible brute force", groups:["authentication_failed","sshd","local"]},
    agent: {id:"001", name:"srv-ad-01"},
    manager: {name:"wazuh-manager"},
    data: {srcip:"198.51.100.44", dstip:"192.168.10.10", dstuser:"admin"},
    soc: {asset:"srv-ad-01", asset_criticality:5, business_impact:5, context_score:5},
    full_log:"Failed password for admin from 198.51.100.44"
  };
  try{
    const r=await SOCV2.wazuhSync(wazuh);
    showToast(`Wazuh processado → ${r.incident_id||"sem incidente"}`);
    await syncFromBackend(false);
  }catch(err){
    console.error(err);
    showToast("Não foi possível processar o alerta Wazuh.");
  }
});

async function rawFetch(path, options={}, includeAuth=true){
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),7000);
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(includeAuth && authToken) headers.Authorization=`Bearer ${authToken}`;
  try{
    const response=await fetch(`${SOC_API}${path}`,{...options,signal:controller.signal,headers});
    let data=null; try{ data=await response.json(); } catch {}
    if(!response.ok){
      if(response.status===401 && includeAuth){ forceLogout("Sua sessão expirou. Entre novamente."); }
      const detail=data?.detail || `API ${response.status}`;
      throw new Error(detail);
    }
    return data;
  }catch(err){
    if(err.name==='AbortError') throw new Error('Tempo limite da API excedido.');
    throw err;
  }finally{ clearTimeout(timeout); }
}
const v2Fetch=rawFetch;
window.SOCV2={
  health:()=>v2Fetch("/health",{},false),
  healthDetails:()=>v2Fetch("/health/details"),
  incidents:(params="")=>v2Fetch(`/incidents${params}`),
  incident:(id)=>v2Fetch(`/incidents/${encodeURIComponent(id)}`),
  metrics:()=>v2Fetch("/metrics"),
  ingest:(alert)=>v2Fetch("/alerts",{method:"POST",body:JSON.stringify(alert)}),
  ingestSync:(alert)=>v2Fetch("/alerts/sync",{method:"POST",body:JSON.stringify(alert)}),
  wazuh:(alert)=>v2Fetch("/webhooks/wazuh",{method:"POST",body:JSON.stringify(alert),headers:WAZUH_DEMO_TOKEN?{"X-SOC-Webhook-Token":WAZUH_DEMO_TOKEN}:{}}),
  wazuhSync:(alert)=>v2Fetch("/webhooks/wazuh/sync",{method:"POST",body:JSON.stringify(alert),headers:WAZUH_DEMO_TOKEN?{"X-SOC-Webhook-Token":WAZUH_DEMO_TOKEN}:{}}),
  batch:(alerts)=>v2Fetch("/alerts/batch",{method:"POST",body:JSON.stringify(alerts)}),
  updateStatus:(id,status,owner=undefined,note=null,ownerUserId=undefined)=>{
    const body={status};
    if(owner!==undefined) body.owner=owner;
    if(ownerUserId!==undefined) body.owner_user_id=ownerUserId;
    if(note!==null) body.note=note;
    return v2Fetch(`/incidents/${encodeURIComponent(id)}/status`,{method:"PATCH",body:JSON.stringify(body)});
  }
};

function apiStatusLabel(status){
  return ({open:"Novo",investigating:"Em investigação",resolved:"Resolvido",escalated:"Escalado",false_positive:"Falso positivo"})[status] || status || "Novo";
}
const typeLabelByType={
  brute_force:"Força bruta",malicious_ip:"IP malicioso",malware:"Malware",anomalous_login:"Login anômalo",port_scan:"Varredura de portas",data_exfiltration:"Exfiltração de dados"
};
const playbookByType={
  brute_force:"Força bruta / credencial suspeita",malicious_ip:"IP malicioso detectado",malware:"Malware detectado",anomalous_login:"Login suspeito",port_scan:"Reconhecimento de rede",data_exfiltration:"Exfiltração de dados"
};
function mapIncident(x){
  let evidence={};
  if(typeof x.evidence==="string"){ try { evidence=JSON.parse(x.evidence)||{}; } catch {} }
  else if(x.evidence && typeof x.evidence==="object") evidence=x.evidence;
  const first=evidence.first_event||{};
  const statusCode=x.status||"open";
  const sourceDisplay=(evidence.source_ips?.length>1?evidence.source_ips.join(", "):x.source_ip||x.source||"N/A");
  const sourceIp=x.source_ip||"N/A";
  const asset=x.asset||x.destination_ip||"N/A";
  return {
    id:x.id,
    type:typeLabelByType[x.event_type]||x.event_type||"Incidente",
    source:sourceDisplay,
    sourceIp,
    target:asset,
    asset,
    username:x.username||null,
    events:x.event_count||1,
    score:Number.isFinite(Number(x.score))?Number(x.score):0,
    severity:x.severity||"low",
    priority:x.priority??4,
    status:apiStatusLabel(statusCode),
    statusCode,
    owner:x.owner||null,
    created:(Number.isNaN(new Date(x.created_at).getTime())?"Data indisponível":new Date(x.created_at).toLocaleString("pt-BR")),
    threat:x.threat_score||0,
    impact:x.impact_score||0,
    assetCriticality:x.asset_criticality||0,
    context:x.context_score||0,
    description:first.description||first.title||x.title||x.impact||"Incidente processado pelo motor de triagem.",
    evidence:[`Origem: ${sourceDisplay}`,`Usuário: ${x.username||"N/A"}`,`Ativo: ${asset}`,`Eventos correlacionados: ${x.event_count||1}`,`Recomendação: ${x.recommendation||"N/A"}`,...(Array.isArray(evidence.event_ids)?[`Eventos rastreáveis: ${evidence.event_ids.length}`]:[]),...(Array.isArray(evidence.source_ips)&&evidence.source_ips.length>1?[`Origens correlacionadas: ${evidence.source_ips.join(", ")}`]:[])],
    playbook:playbookByType[x.event_type]||x.event_type
  };
}

async function syncFromBackend(showError=true){
  if(refreshInFlight)return;
  refreshInFlight=true;
  try{
    const publicHealth=await SOCV2.health();
    demoEnvironment=publicHealth?.environment==="demo" && publicHealth?.demo_mode===true;
    setDemoControls(demoEnvironment);
    const [data,metrics,health]=await Promise.all([SOCV2.incidents("?limit=500"),SOCV2.metrics(),SOCV2.healthDetails()]);
    alerts=(data.items||[]).map(mapIncident);
    apiMetrics=metrics;
    apiHealth=health;
    // Never display bundled mock incidents beside live backend metrics.
    // An empty backend must produce an empty queue and matching zero counters.
    document.querySelector(".live")?.replaceChildren(Object.assign(document.createElement("span"),{textContent:`● API ONLINE · FILA ${health.queue_size||0}`}));
    if(currentView!=="detail") render();
  }catch(err){
    console.warn("Backend indisponível.",err);
    apiHealth=null;
    apiMetrics=null;
    alerts=[];
    if(showError) showToast(demoEnvironment?"Backend offline — modo de demonstração.":"Backend indisponível — dados reais ocultados por segurança.");
    setDemoControls(demoEnvironment);
    render();
  }finally{ refreshInFlight=false; }
}

function startAutoRefresh(){
  clearInterval(refreshTimer);
  refreshTimer=setInterval(()=>syncFromBackend(false),5000);
}

console.info(`SOC Intelligent Triage V${APP_VERSION} API ready:`,SOC_API);
bootstrapAuth();

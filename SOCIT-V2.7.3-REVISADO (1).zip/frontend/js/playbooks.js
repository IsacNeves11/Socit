export const playbooks = {
  "Força bruta / credencial suspeita": {
    title:"Força bruta / credencial suspeita",
    summary:"Resposta inicial para múltiplas tentativas de autenticação contra uma conta.",
    steps:["Verificar IP, horário e volume de tentativas.","Confirmar se houve autenticação bem-sucedida.","Bloquear a origem quando houver evidência de abuso.","Validar o acesso com o proprietário da conta.","Redefinir credenciais e habilitar MFA quando aplicável."]
  },
  "IP malicioso detectado": {
    title:"IP malicioso detectado",
    summary:"Resposta inicial para comunicação com infraestrutura externa suspeita.",
    steps:["Identificar o equipamento que originou a conexão.","Bloquear a comunicação conforme política da organização.","Preservar evidências e registros de conexão.","Executar análise do endpoint.","Verificar outros ativos que acessaram o mesmo destino."]
  },
  "Malware detectado": {
    title:"Malware detectado",
    summary:"Contenção e investigação inicial de uma detecção de malware.",
    steps:["Isolar o endpoint da rede.","Identificar arquivo, processo e usuário envolvidos.","Executar análise pelo EDR/antimalware.","Preservar evidências antes de alterações destrutivas.","Verificar propagação ou indicadores semelhantes em outros ativos."]
  },
  "Login suspeito": {
    title:"Login suspeito",
    summary:"Validação de autenticação fora do padrão.",
    steps:["Comparar horário, origem e comportamento histórico.","Verificar autenticação multifator.","Confirmar a legitimidade com o usuário.","Investigar sessões e ações posteriores.","Redefinir credenciais se houver indícios de comprometimento."]
  },
  "Exfiltração de dados": {
    title:"Exfiltração de dados",
    summary:"Contenção e investigação inicial para possível transferência indevida de dados.",
    steps:["Identificar origem, destino e volume transferido.","Preservar logs e evidências antes de alterar o endpoint.","Restringir o canal suspeito conforme a política da organização.","Validar a conta, processo e dados envolvidos.","Escalar para resposta a incidente se houver confirmação de exfiltração."]
  },
  "Reconhecimento de rede": {
    title:"Reconhecimento de rede",
    summary:"Investigação inicial de atividade de varredura.",
    steps:["Identificar origem da varredura.","Determinar quais ativos e portas foram consultados.","Verificar se houve exploração após a varredura.","Correlacionar com outros eventos.","Escalar se houver indícios de progressão para ataque."]
  }
};
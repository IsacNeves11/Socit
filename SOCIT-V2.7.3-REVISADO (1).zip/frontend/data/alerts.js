export const seedAlerts = [
  {
    id:"INC-1024", type:"Força bruta", source:"185.44.21.9", target:"adm-financeiro",
    asset:"Servidor de autenticação", events:47, threat:5, impact:5, assetCriticality:5, context:5,
    status:"Aguardando análise", created:"03:42", description:"47 tentativas de autenticação com múltiplas senhas contra uma conta administrativa durante a madrugada.",
    evidence:["47 falhas de autenticação em 11 minutos","Origem externa não reconhecida","Conta possui privilégio administrativo","1 tentativa de autenticação bem-sucedida após as falhas"],
    playbook:"Força bruta / credencial suspeita"
  },
  {
    id:"INC-1021", type:"IP malicioso", source:"91.208.77.14", target:"WS-027", asset:"Estação de trabalho", events:12, threat:5, impact:4, assetCriticality:3, context:4,
    status:"Aguardando análise", created:"04:11", description:"Estação estabeleceu conexões repetidas com um endereço classificado como malicioso.",
    evidence:["12 conexões externas em 6 minutos","Destino externo suspeito","Processo de origem ainda não identificado"],
    playbook:"IP malicioso detectado"
  },
  {
    id:"INC-1018", type:"Malware", source:"WS-114", target:"WS-114", asset:"Notebook executivo", events:3, threat:5, impact:4, assetCriticality:4, context:3,
    status:"Em investigação", created:"05:26", description:"Endpoint Protection identificou um arquivo potencialmente malicioso.",
    evidence:["Detecção pelo EDR","Arquivo executado antes da detecção","Usuário conectado no momento do evento"],
    playbook:"Malware detectado"
  },
  {
    id:"INC-1015", type:"Login anômalo", source:"200.18.4.77", target:"maria.silva", asset:"Sistema corporativo", events:6, threat:3, impact:3, assetCriticality:3, context:3,
    status:"Aguardando análise", created:"06:18", description:"Login realizado fora do horário habitual e a partir de origem não usual.",
    evidence:["Login às 02:18","Localização diferente do padrão recente","MFA aprovado"],
    playbook:"Login suspeito"
  },
  {
    id:"INC-1011", type:"Varredura de portas", source:"10.10.8.33", target:"REDE-INTERNA", asset:"Segmento de rede", events:31, threat:2, impact:2, assetCriticality:3, context:2,
    status:"Aguardando análise", created:"07:04", description:"Atividade de reconhecimento de portas detectada em segmento interno.",
    evidence:["31 portas consultadas","Sem exploração confirmada","Origem é um equipamento interno"],
    playbook:"Reconhecimento de rede"
  },
  {
    id:"INC-1007", type:"Login incorreto", source:"10.0.3.45", target:"joao.souza", asset:"Sistema corporativo", events:2, threat:1, impact:1, assetCriticality:2, context:1,
    status:"Novo", created:"07:35", description:"Duas tentativas de autenticação incorreta em sequência.",
    evidence:["2 falhas de login","Sem outros eventos correlacionados"],
    playbook:"Login suspeito"
  }
];
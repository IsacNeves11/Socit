# Changelog — SOC Intelligent Triage V2.7.2

- Rejeição explícita de credenciais demo padrão em `pilot`/`production`, inclusive quando configuradas por variável de ambiente.
- Limite de body HTTP aplicado durante streaming ASGI quando `Content-Length` está ausente ou incorreto.
- Bridge Wazuh valida status HTTP esperado e `accepted:false`.
- Evidência de incidente compactada; payload completo continua em `events.payload`, com hash/excerpt limitado.
- Backup/restore PowerShell usa streams binários para dumps PostgreSQL.
- Checklist de teste de campo para Docker/WSL/Wazuh.
- Suíte de pré-auditoria V2.7.2 adicionada.

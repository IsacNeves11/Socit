# Auditoria V2.6.1 — SOC Intelligent Triage

## Achados reais corrigidos

1. Timestamps nos extremos de `datetime` podiam causar `OverflowError`/HTTP 500 ao montar a janela de correlação. A janela agora é calculada com `timedelta` e limites seguros.
2. Swagger, ReDoc e OpenAPI permaneciam públicos em modo de produção. Agora ficam desabilitados quando `SOC_DEMO_MODE=0`.
3. Uma base criada em modo demo podia ser promovida para produção mantendo uma senha demo conhecida. A inicialização de produção agora recusa credenciais demo padrão ainda ativas.
4. Offsets de listagem agora têm limite máximo para reduzir consultas abusivas.
5. A ponte Wazuh agora identifica a versão 2.6.1 corretamente.
6. Scripts de inicialização e testes foram alinhados à versão 2.6.1.

## Bateria final

- `DEEP_AUDIT_12_OK`
- `FULL_AUDIT_OK 5/5`
- `MIGRATION_OK`
- `SELF_TEST_OK`
- `V26_HTTP_TEST_OK`
- `V26_REGRESSION_OK`
- `V26_SECURITY_OK`
- `V26_AUTH_RBAC_OK`
- `WAZUH_BRIDGE_OK`
- `WAZUH_TEST_OK`
- `PROD_PUBLIC_SURFACE_OK`
- `JS_CHECK_OK`
- Compilação Python sem erro
- Integridade do ZIP validada

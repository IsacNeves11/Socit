# Security baseline — V2.7 Pilot

## Pré-piloto

- Definir domínio e TLS aprovados pela empresa.
- Trocar todas as credenciais padrão.
- Armazenar secrets fora do código e do repositório.
- Usar PostgreSQL em `SOC_ENV=pilot/production`.
- Restringir a porta do backend à rede/reverse proxy autorizado.
- Ativar `SOC_REQUIRE_HTTPS=1`.
- Definir `SOC_TRUSTED_ORIGINS` somente com origens necessárias.
- Configurar backup e testar restore.
- Centralizar logs do aplicativo/reverse proxy.
- Definir retenção para eventos/incident history conforme política da empresa.

## Comportamento seguro

- A integração Wazuh usa token dedicado.
- A aplicação não executa bloqueio de IP, isolamento de host ou alteração de credencial automaticamente.
- Ações destrutivas devem ser implementadas somente após revisão, aprovação e testes específicos do ambiente.
- Logs não devem conter senhas, tokens ou payloads completos com segredos.
- Em caso de incidente de segurança, revogue o token Wazuh e as sessões dos usuários e troque secrets.

## Threat model mínimo

1. Ataque ao webhook: mitigado por token + limite de corpo + validação.
2. Roubo de sessão: sessões revogáveis e tokens armazenados como hash.
3. Escalada de privilégio: RBAC no backend.
4. Exposição de arquivos: somente `frontend/` é montado como estático.
5. Falha/replay de ingestão: IDs e deduplicação.
6. Corrida na correlação/fila: transação, locks específicos e claim token.
7. Indisponibilidade do banco: health/readiness e restart do container; recuperação depende do backup PostgreSQL.

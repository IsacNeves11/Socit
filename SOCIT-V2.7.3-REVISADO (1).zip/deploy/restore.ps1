param(
  [Parameter(Mandatory=$true)][string]$BackupFile
)
$ErrorActionPreference = "Stop"
if (-not (Test-Path $BackupFile)) { throw "Backup não encontrado: $BackupFile" }
$full = (Resolve-Path $BackupFile).Path
$bytes = [IO.File]::ReadAllBytes($full)
if ($bytes.Length -le 0) { throw "Arquivo de backup vazio." }
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = "docker"
$psi.Arguments = "compose exec -T postgres pg_restore -U soc -d soc --clean --if-exists --no-owner --no-acl"
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardError = $true
$process = New-Object System.Diagnostics.Process
$process.StartInfo = $psi
try {
  [void]$process.Start()
  $process.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length)
  $process.StandardInput.Close()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) { throw "pg_restore falhou: $stderr" }
  Write-Host "Restore concluído."
} finally { $process.Dispose() }

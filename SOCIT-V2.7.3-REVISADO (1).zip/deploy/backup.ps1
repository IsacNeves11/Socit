param(
  [string]$OutputDir = ".\backups"
)
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force $OutputDir | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$out = Join-Path $OutputDir "soc-$stamp.dump"
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = "docker"
$psi.Arguments = "compose exec -T postgres pg_dump -U soc -d soc --format=custom"
$psi.UseShellExecute = $false
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$process = New-Object System.Diagnostics.Process
$process.StartInfo = $psi
try {
  [void]$process.Start()
  $stream = [IO.File]::Create($out)
  try { $process.StandardOutput.BaseStream.CopyTo($stream) } finally { $stream.Dispose() }
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  if ($process.ExitCode -ne 0) { throw "pg_dump falhou: $stderr" }
  if (-not (Test-Path $out) -or (Get-Item $out).Length -le 0) { throw "Backup vazio." }
  Write-Host "Backup criado em $out"
} catch {
  Remove-Item $out -Force -ErrorAction SilentlyContinue
  throw
} finally { $process.Dispose() }

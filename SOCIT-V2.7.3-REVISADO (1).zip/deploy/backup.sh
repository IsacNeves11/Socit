#!/usr/bin/env bash
set -euo pipefail
out_dir="${1:-./backups}"
mkdir -p "$out_dir"
stamp="$(date +%Y%m%d-%H%M%S)"
out="$out_dir/soc-$stamp.dump"
if ! docker compose exec -T postgres pg_dump -U soc -d soc --format=custom > "$out"; then
  rm -f "$out"
  echo "Falha ao criar backup PostgreSQL." >&2
  exit 1
fi
if [[ ! -s "$out" ]]; then
  rm -f "$out"
  echo "Backup vazio; operação abortada." >&2
  exit 1
fi
echo "Backup criado em $out"

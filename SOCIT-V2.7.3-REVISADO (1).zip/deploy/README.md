# Deployment de piloto

## Requisitos

- Docker Desktop com WSL 2 no Windows ou Docker Engine + Compose no Linux.
- 4 vCPU e 8 GB de RAM como referência para um laboratório Wazuh single-node; o próprio Wazuh documenta esses requisitos para seu stack Docker single-node.
- DNS/nome de host definido pela empresa.
- TLS terminado por reverse proxy aprovado pela empresa.

## Subir o SOC + PostgreSQL

1. Copie `.env.example` para `.env`.
2. Troque TODAS as senhas e tokens.
3. Defina `SOC_TRUSTED_ORIGINS` para a origem real do dashboard.
4. Execute `docker compose up -d --build`.
5. Verifique `docker compose ps`.
6. Para teste privado sem reverse proxy, use o `.env.local-pilot.example` como base, defina `SOC_REQUIRE_HTTPS=0` e valide `http://127.0.0.1:8080/api/health` e `/api/ready`.
7. Depois do login, valide também `/api/health/details` com o token autenticado.
8. Para HTTPS, coloque o reverse proxy aprovado na frente e defina `SOC_TRUSTED_PROXY_CIDRS` para a rede real do proxy; o backend aceita `X-Forwarded-Proto` somente desses proxies confiáveis.

Em `SOC_ENV=pilot`, o backend recusa SQLite e exige PostgreSQL + token do webhook + credenciais não-demo.

## TLS / reverse proxy

A aplicação consegue exigir HTTPS usando `SOC_REQUIRE_HTTPS=1`. Quando existe um reverse proxy na frente, ele deve encaminhar `X-Forwarded-Proto: https` e estar listado em `SOC_TRUSTED_PROXY_CIDRS`. Sem isso, o backend ignora o header e exige HTTPS real.

Não exponha a porta 8000 diretamente na internet. No compose de laboratório ela fica presa ao loopback (`127.0.0.1:8080`).

## Backup

Antes de um restore, pare temporariamente o serviço `soc` para evitar alterações concorrentes no banco:

```powershell
docker compose stop soc
.\deploy\restore.ps1 .\backups\SEU-BACKUP.dump
docker compose start soc
```


Use `backup.ps1` no Windows ou `backup.sh` no Linux/macOS. Para restaurar, use `restore.ps1` ou `restore.sh`. Os scripts usam `pg_dump` dentro do container e gravam o artefato fora dos volumes.

## Rollback

- Preserve o backup do PostgreSQL antes de qualquer atualização.
- Guarde a tag/arquivo ZIP da versão anterior.
- Faça `docker compose down` somente se a mudança exigir recriação; os dados permanecem no volume PostgreSQL.
- Restaure o backup se o schema ou dados precisarem ser revertidos.

## Integração Wazuh

O Wazuh Integrator aceita integração customizada com `<name>` iniciado por `custom-`, passando arquivo de alerta, `api_key` e `hook_url` ao script. O projeto possui o script em `integrations/custom-soc-intelligent-triage` e um exemplo em `integrations/wazuh_ossec_config.xml`.

Para o Wazuh em outra máquina, configure `hook_url` para o endereço HTTPS aprovado da empresa, não para `127.0.0.1`.

# Checklist de teste de campo — V2.7.3

## 1. Pré-requisitos do Windows

```powershell
wsl --update
wsl --status
wsl -l -v
docker --version
docker compose version
```

## 2. Piloto privado

1. Copie `.env.local-pilot.example` para `.env`.
2. Substitua todos os valores `PUT-A-...` por valores fortes e únicos.
3. Suba:

```powershell
docker compose up -d --build
```

4. Valide:

```powershell
Invoke-RestMethod http://127.0.0.1:8080/api/health
Invoke-RestMethod http://127.0.0.1:8080/api/ready
```

5. Abra `http://127.0.0.1:8080` e valide login/RBAC.

## 3. Persistência

Reinicie o serviço:

```powershell
docker compose restart soc
```

Confirme que o mesmo banco e os incidentes continuam presentes.

## 4. Wazuh

1. Instale o script `integrations/custom-soc-intelligent-triage` no Wazuh Manager.
2. Use `integrations/wazuh_ossec_config.xml` como referência e troque `hook_url`/token pelo ambiente real.
3. Confirme que o Wazuh consegue alcançar o endpoint HTTPS do SOC.
4. Gere um alerta de laboratório autorizado.
5. Confirme o caminho:

`Wazuh → Integrator → webhook → fila → worker → incidente → dashboard`

## 5. Cenário principal de demonstração

Produza várias falhas de autenticação contra um ativo de laboratório, dentro de 5 minutos.

Esperado:

- evento classificado como `brute_force`;
- múltiplos eventos correlacionados em um incidente;
- score elevado conforme criticidade/impacto/contexto;
- prioridade exibida corretamente;
- evidências preservadas;
- responsável atribuído ao iniciar investigação;
- ação registrada em auditoria.

## 6. Recuperação

Durante um teste controlado:

```powershell
docker compose restart soc
```

Confirme que jobs pendentes não são perdidos nem duplicados.

## 7. Backup

```powershell
.\deploy\backup.ps1
```

Para restore em laboratório, pare o app antes:

```powershell
docker compose stop soc
.\deploy\restore.ps1 .\backups\SEU-BACKUP.dump
docker compose start soc
```

## Critério de aprovação do campo

A solução só deve ser considerada aprovada para piloto quando o fluxo Wazuh → SOC → incidente → ação do analista funcionar de ponta a ponta no ambiente controlado da empresa.

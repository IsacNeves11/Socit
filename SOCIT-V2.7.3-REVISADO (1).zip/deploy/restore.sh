#!/usr/bin/env bash
set -euo pipefail
backup_file="${1:?Informe o arquivo de backup}"
[[ -f "$backup_file" ]] || { echo "Backup não encontrado: $backup_file" >&2; exit 1; }
[[ -s "$backup_file" ]] || { echo "Arquivo de backup vazio." >&2; exit 1; }
if ! cat "$backup_file" | docker compose exec -T postgres pg_restore -U soc -d soc --clean --if-exists --no-owner --no-acl; then
  echo "Falha ao restaurar o backup PostgreSQL." >&2
  exit 1
fi
echo "Restore concluído."

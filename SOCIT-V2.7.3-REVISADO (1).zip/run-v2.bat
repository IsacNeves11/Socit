@echo off
call "%~dp0run-v2.7.bat" %*

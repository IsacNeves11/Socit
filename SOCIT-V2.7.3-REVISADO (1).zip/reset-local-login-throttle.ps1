$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$db = Join-Path $root "backend\soc.db"

Write-Host "SOC Intelligent Triage - reset do bloqueio local de login" -ForegroundColor Cyan
Write-Host "Este procedimento altera somente login_throttle para IPs de loopback." 
Write-Host "Incidentes, eventos, usuarios, auditoria e sessoes nao serao apagados."
Write-Host ""
Write-Host "IMPORTANTE: feche/pare primeiro a janela SOC Backend com Ctrl+C."
$answer = Read-Host "Digite SIM para criar backup e remover o bloqueio local"
if ($answer -ne "SIM") { Write-Host "Cancelado. Nenhuma alteracao realizada."; exit 0 }
if (-not (Test-Path $db)) {
  Write-Error "Banco nao encontrado em '$db'. Nao foi alterado nada. Abra este script na pasta raiz correta da V2.7.3."
  exit 2
}
$python = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) {
  $command = Get-Command python -ErrorAction SilentlyContinue
  if (-not $command) { Write-Error "Python nao encontrado. Instale Python ou execute run-v2.bat uma vez antes."; exit 2 }
  $python = $command.Source
}
$pyCode = @'
from pathlib import Path
import datetime, sqlite3, sys
source = Path(sys.argv[1])
if not source.is_file():
    raise SystemExit(f"Database not found: {source}")
stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
backup = source.with_name(f"{source.stem}.backup-login-reset-{stamp}{source.suffix}")
# SQLite's backup API creates a consistent copy, including committed WAL content.
with sqlite3.connect(source, timeout=15) as original:
    with sqlite3.connect(backup) as target:
        original.backup(target)
with sqlite3.connect(source, timeout=15) as con:
    tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "login_throttle" not in tables:
        raise SystemExit("Table login_throttle not found. No throttle row changed.")
    cur = con.execute("DELETE FROM login_throttle WHERE ip_address IN (?, ?)", ("127.0.0.1", "::1"))
    con.commit()
    print(f"Local throttle rows removed: {cur.rowcount}")
print(f"Backup created: {backup}")
print("Done. Incident/event records were not deleted.")
'@
$pyCode | & $python - $db
if ($LASTEXITCODE -ne 0) { Write-Error "O script Python falhou. Confira a mensagem acima."; exit $LASTEXITCODE }

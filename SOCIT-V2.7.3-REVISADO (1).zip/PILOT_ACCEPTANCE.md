# Critérios de aceitação do piloto

O piloto é considerado tecnicamente aprovado quando todos os itens abaixo forem demonstrados no ambiente autorizado da empresa.

## Ingestão

- [ ] Wazuh envia um alerta real para `/api/webhooks/wazuh`.
- [ ] Token inválido é recusado.
- [ ] Token válido recebe HTTP 202.
- [ ] O alerta aparece na fila.

## Triagem

- [ ] O evento é normalizado sem perda do identificador.
- [ ] A regra/tipo é identificado.
- [ ] A criticidade do ativo e contexto entram no score.
- [ ] O score/severidade aparecem no dashboard.

## Correlação

- [ ] Alertas relacionados são consolidados.
- [ ] Alertas de alvos diferentes não são misturados.
- [ ] Replay do mesmo alert_id não cria evento duplicado.
- [ ] Eventos atrasados continuam dentro da janela correta.

## Operação

- [ ] Analista inicia investigação.
- [ ] Responsável e observação ficam auditados.
- [ ] Supervisor consegue escalar.
- [ ] Incidente pode ser resolvido.
- [ ] Histórico é visível.

## Confiabilidade

- [ ] Backend reinicia sem perder a fila pendente.
- [ ] Job em processamento pode ser recuperado.
- [ ] Backup do PostgreSQL é criado.
- [ ] Restore foi testado em ambiente separado.

## Valor de negócio

Medir antes e depois do piloto:

- volume bruto de eventos;
- número de incidentes consolidados;
- percentual de redução por correlação;
- MTTA;
- MTTR;
- quantidade de incidentes críticos corretamente priorizados;
- feedback dos analistas sobre ruído/alert fatigue.

# Relatório de Auditoria — SOC Intelligent Triage V2.7.2

## Escopo
Revisão geral do release Pilot Ready com foco em segurança de aplicação, autenticação/RBAC, persistência, fila, concorrência, correlação, integração Wazuh, frontend, configuração e artefato de implantação.

## Problemas encontrados e corrigidos nesta rodada

1. **Credenciais de exemplo poderiam escapar da validação de placeholder.** A validação foi ampliada para formatos `PUT-A-*`, `REPLACE-WITH-*` e equivalentes.
2. **Atribuição livre de responsável.** O campo de responsável agora referencia um usuário ativo; analistas não podem atribuir incidentes a terceiros.
3. **Rate limit de login somente em memória.** Foi adicionada persistência em `login_throttle`, compartilhada entre workers e validada após recarga do processo.
4. **Concorrência do bootstrap.** O PostgreSQL usa lock de inicialização e os usuários padrão são criados com `ON CONFLICT DO NOTHING`, evitando disputa entre workers.
5. **Replay concorrente do mesmo `alert_id`.** O PostgreSQL usa lock por identidade do alerta antes da deduplicação/correlação.
6. **Métricas antigas em indisponibilidade do backend.** O frontend agora limpa também `apiMetrics` quando não consegue obter dados reais.
7. **Documentação de auditoria/testes incompleta.** `run-audit.ps1`, README e o relatório foram atualizados.
8. **Scripts de implantação.** Permissões executáveis e validações de shell permanecem verificadas.

## Verificações executadas

- `SELF_TEST_OK`
- `FULL_AUDIT_OK 5/5`
- `MIGRATION_OK`
- `PILOT_CONFIG_OK`
- `REPLAY_IDEMPOTENCY_OK`
- `LOGIN_THROTTLE_PERSISTENCE_OK`
- `WAZUH_TEST_OK`
- `WAZUH_BRIDGE_OK`
- `WAZUH_BRIDGE_RETRY_OK`
- `V27_AUTH_RBAC_OK`
- `V27_HTTP_TEST_OK`
- `V27_REGRESSION_OK`
- `V27_SECURITY_OK`
- `DEEP_AUDIT_12_OK`
- `V271_DEEP_AUDIT_OK 16/16`
- `PY_COMPILE_OK` / `JS_OK`
- `XML_OK` / `DEPLOY_STATIC_OK`
- `SCRIPT_PERMISSIONS_OK`
- `VERSION_CONSISTENCY_OK`
- `SECRET_SCAN_OK`

## Limitações da auditoria local

Não há Docker, PostgreSQL ou Wazuh reais disponíveis neste ambiente de execução. Portanto, a compatibilidade PostgreSQL e o fluxo Wazuh foram validados por testes de contrato, SQL/compatibilidade, bridge HTTP local, integração e configuração, mas ainda precisam de execução no ambiente autorizado da empresa.

## Decisão

A V2.7.2 está aprovada como **base de piloto técnico**, condicionada à validação real com Docker + PostgreSQL + Wazuh e aos controles de infraestrutura da empresa. Não deve ser tratada como substituta de um SOC/SIEM enterprise sem validação operacional, segurança independente e testes de carga.

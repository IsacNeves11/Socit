# Auditoria V2.6.0 — SOC Intelligent Triage

## Escopo

Revisão de autenticação, autorização (RBAC), sessões, migração SQLite, integração Wazuh, fila persistida, correlação, frontend, API e compatibilidade com a base V2.5.1.

## Controles adicionados

- PBKDF2-HMAC-SHA256 com salt aleatório e 310.000 iterações.
- Sessões opacas com token armazenado apenas como SHA-256 e expiração configurável.
- Revogação de sessão no logout, troca de senha e desativação/alteração de papel.
- Rate limit local de 5 falhas por IP em 5 minutos no login.
- Papéis `analyst`, `supervisor`, `admin`.
- Escalada de incidentes restrita a supervisor/admin.
- Gestão de usuários restrita a admin.
- Pelo menos um administrador ativo deve existir.
- Em `SOC_DEMO_MODE=0`, senhas e token Wazuh são obrigatórios.
- CORS permite `Authorization` e o token Wazuh.

## Validação

- SELF_TEST_OK
- FULL_AUDIT_OK 5/5
- MIGRATION_OK
- WAZUH_TEST_OK
- WAZUH_BRIDGE_OK
- V26_AUTH_RBAC_OK
- JS syntax OK
- HTTP/CORS/security smoke test

## Observação de produção

A versão continua sendo uma base de piloto/demonstração. Produção real ainda exige TLS/reverse proxy, gestão externa de segredos, rate limiting distribuído, observabilidade, backup/HA do banco e integração controlada com SIEM/EDR.
- V26_HTTP_TEST_OK
- V26_SECURITY_OK
- V26_REGRESSION_OK

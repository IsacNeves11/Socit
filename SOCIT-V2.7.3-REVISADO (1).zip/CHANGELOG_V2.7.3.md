# SOC Intelligent Triage V2.7.3 — correções alinhadas ao escopo

- Calcula score de risco de 1 a 10 pela matriz: baseline de ameaça/impacto/criticidade/contexto; login isolado +1; falhas repetidas +4; fora de horário +2; Financeiro/Diretoria/executivo +3; teto 10. Classifica: Crítico 7–10, Alto 6, Médio 4–5, Baixo 1–3.
- Migra scores históricos de 0–20 para 1–10 uma única vez ao migrar schema v7 para v8; preserva eventos, evidências, usuários, sessões e auditoria.
- Remove o fallback que mostrava alertas fictícios na fila quando o backend estava vazio; fila e indicadores agora usam a mesma fonte de dados.
- Inclui o status Falso positivo.
- Impede encerrar um incidente com score 10 sem uma observação documentando a contenção (mínimo de 10 caracteres).
- Mantém a API de incidentes e operações protegida por token de sessão; o painel inicia com a autenticação visível e respeita o atributo HTML hidden.
- Inclui o script local de desbloqueio de login com backup do banco, útil para ambientes de demonstração bloqueados.

## Limites

Esta versão é um protótipo/demonstração. A integração com Wazuh e as ações de contenção no ambiente real precisam ser validadas e autorizadas no SOC de destino. O registro de uma observação confirma que o analista documentou a ação; não executa bloqueio automático em firewall/EDR.

#!/usr/bin/env python3
"""Wazuh custom-integration bridge for SOC Intelligent Triage.

Wazuh Integrator contract:
  argv[1] = alert JSON file
  argv[2] = api_key (optional)
  argv[3] = hook_url (optional)

Manual usage is also supported:
  python integrations/wazuh_integration.py <alert.json> [url]
"""
from pathlib import Path
import time
import json
import os
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse

DEFAULT_URL = os.getenv("SOC_WAZUH_WEBHOOK_URL", "http://127.0.0.1:8000/api/webhooks/wazuh")
ENV_TOKEN = os.getenv("SOC_WAZUH_WEBHOOK_TOKEN", "").strip()

if len(sys.argv) < 2:
    raise SystemExit("Uso: python integrations/wazuh_integration.py <alert.json> [api_key] [hook_url]")

path = Path(sys.argv[1])
if not path.is_file():
    raise SystemExit(f"Arquivo de alerta não encontrado: {path}")

api_key = sys.argv[2].strip() if len(sys.argv) >= 3 else ""
hook_arg = sys.argv[3].strip() if len(sys.argv) >= 4 else ""
# Backward-compatible manual mode: a lone second argument beginning with http is treated as the URL.
if len(sys.argv) == 3 and api_key.lower().startswith(("http://", "https://")):
    hook_arg, api_key = api_key, ""
url = hook_arg or DEFAULT_URL
parsed_url = urlparse(url)
if parsed_url.scheme not in {"http", "https"} or not parsed_url.netloc:
    raise SystemExit("hook_url precisa usar http:// ou https:// com host válido")
token = ENV_TOKEN or api_key

MAX_ALERT_BYTES = 4 * 1024 * 1024
try:
    if path.stat().st_size > MAX_ALERT_BYTES:
        raise SystemExit(f"Arquivo de alerta excede o limite de {MAX_ALERT_BYTES} bytes")
    alert = json.loads(path.read_text(encoding="utf-8"))
except (OSError, json.JSONDecodeError) as exc:
    raise SystemExit(f"Falha ao ler o alerta JSON: {exc}") from exc

if not isinstance(alert, dict):
    raise SystemExit("O alerta precisa ser um objeto JSON")

payload = json.dumps(alert, ensure_ascii=False).encode("utf-8")
request = urllib.request.Request(
    url,
    data=payload,
    headers={"Content-Type": "application/json", "User-Agent": "SOC-Intelligent-Triage-Wazuh/2.7.3"},
    method="POST",
)
if token:
    request.add_header("X-SOC-Webhook-Token", token)

last_error = None
for attempt in range(1, 4):
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read(512 * 1024).decode("utf-8", errors="replace")
            if response.status not in {200, 202}:
                raise SystemExit(f"Wazuh bridge recebeu HTTP inesperado: {response.status}")
            if body:
                try:
                    result = json.loads(body)
                    if isinstance(result, dict) and result.get("accepted") is False:
                        raise SystemExit("SOC recusou o alerta Wazuh")
                except json.JSONDecodeError:
                    pass
            print(body)
            raise SystemExit(0)
    except urllib.error.HTTPError as exc:
        detail = exc.read(4096).decode("utf-8", errors="replace")
        # Retry transient server-side/rate-limit failures only.
        if exc.code in {429, 500, 502, 503, 504} and attempt < 3:
            time.sleep(attempt)
            last_error = f"HTTP {exc.code}: {detail}"
            continue
        raise SystemExit(f"Wazuh bridge retornou HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        last_error = f"Falha de conexão com o SOC: {exc.reason}"
        if attempt < 3:
            time.sleep(attempt)
            continue
        raise SystemExit(last_error) from exc
    except SystemExit:
        raise
    except Exception as exc:
        last_error = f"Falha ao enviar alerta ao SOC: {exc}"
        if attempt < 3:
            time.sleep(attempt)
            continue
        raise SystemExit(last_error) from exc
raise SystemExit(last_error or "Falha ao enviar alerta ao SOC")

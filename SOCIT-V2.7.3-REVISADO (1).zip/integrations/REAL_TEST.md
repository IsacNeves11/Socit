# Teste real Wazuh -> SOC Intelligent Triage

## 1. Copiar o script para o Wazuh manager

O Wazuh exige que uma integração customizada use, em `/var/ossec/integrations/`, o mesmo nome informado em `<name>` e que o arquivo tenha permissão de execução e proprietário `root:wazuh`.

Em Docker Desktop, a partir desta pasta do projeto:

```powershell
docker cp .\integrations\custom-soc-intelligent-triage <WAZUH_MANAGER_CONTAINER>:/var/ossec/integrations/custom-soc-intelligent-triage
docker exec <WAZUH_MANAGER_CONTAINER> chown root:wazuh /var/ossec/integrations/custom-soc-intelligent-triage
docker exec <WAZUH_MANAGER_CONTAINER> chmod 750 /var/ossec/integrations/custom-soc-intelligent-triage
```

## 2. Configurar o Integrator

Adicione o bloco de `integrations/wazuh_ossec_config.xml` no `/var/ossec/etc/ossec.conf`.

Para Wazuh dentro do Docker Desktop, `host.docker.internal` aponta para o host Windows onde o SOC deve estar acessível. Caso o Wazuh esteja em outra máquina, troque pelo endereço dessa máquina.

Depois reinicie o Wazuh manager.

## 3. Iniciar o SOC

No Windows, no diretório do SOC:

```powershell
$env:SOC_DEMO_MODE="1"
$env:SOC_HOST="0.0.0.0"
$env:SOC_PORT="8000"
$env:SOC_WAZUH_WEBHOOK_TOKEN="SOCWazuhTeste-2026!"
.\run-v2.7.bat
```

Teste a saúde:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/health | ConvertTo-Json -Depth 10
```

## 4. Gerar um alerta real pelo motor do Wazuh

No manager, crie uma regra local (IDs customizados entre 100000 e 120000) em `/var/ossec/etc/rules/local_rules.xml`:

```xml
<group name="soc_real_test,">
  <rule id="100100" level="12">
    <decoded_as>json</decoded_as>
    <field name="event_type">SOC_TEST_BRUTE_FORCE</field>
    <description>SOC real test - brute force against admin</description>
    <group>authentication_failures,brute_force,</group>
  </rule>
</group>
```

Monitore um arquivo JSON de teste no manager com um bloco `localfile`:

```xml
<localfile>
  <log_format>json</log_format>
  <location>/var/log/soc-test.json</location>
</localfile>
```

Reinicie o manager para aplicar as alterações.

## 5. Validar a regra antes do disparo

No manager:

```bash
/var/ossec/bin/wazuh-logtest
```

Cole uma linha JSON única:

```json
{"event_type":"SOC_TEST_BRUTE_FORCE","srcip":"10.10.10.50","dstip":"10.10.10.10","user":"admin","host":"srv-ad-01","message":"47 failed logins"}
```

O Wazuh deve mostrar o decoder `json` e a regra `100100` antes de continuar. O `wazuh-logtest` testa as regras em sandbox; para gerar alertas reais é necessário reiniciar o manager após mudanças nas regras.

## 6. Disparar o evento real

Dentro do container do manager:

```bash
printf '%s\n' '{"event_type":"SOC_TEST_BRUTE_FORCE","srcip":"10.10.10.50","dstip":"10.10.10.10","user":"admin","host":"srv-ad-01","message":"47 failed logins"}' >> /var/log/soc-test.json
```

Acompanhe:

```bash
tail -f /var/ossec/logs/integrations.log
```

E no Windows:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/health | ConvertTo-Json -Depth 10
```

## 7. Resultado esperado

No dashboard do SOC deve aparecer um incidente recebido pelo Wazuh, com origem `10.10.10.50`, usuário `admin`, ativo `srv-ad-01`, tipo `brute_force` e regra `100100`.

A primeira ocorrência deve refletir o score derivado do nível 12 do Wazuh. Os campos de criticidade/impacto podem ser configurados posteriormente via enriquecimento; o objetivo desta primeira prova é validar o caminho real Wazuh -> Integrator -> webhook -> fila -> correlação -> incidente.

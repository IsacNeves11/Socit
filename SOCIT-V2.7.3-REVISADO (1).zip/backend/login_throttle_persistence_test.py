import importlib, os, sys, tempfile
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
db_path = Path(tempfile.mkdtemp(prefix="soc-throttle-persist-")) / "soc.db"
os.environ["SOC_ENV"] = "demo"
os.environ["SOC_DEMO_MODE"] = "1"
os.environ["SOC_DB_PATH"] = str(db_path)
for k in ("SOC_ADMIN_PASSWORD","SOC_SUPERVISOR_PASSWORD","SOC_ANALYST_PASSWORD","SOC_WAZUH_WEBHOOK_TOKEN"):
    os.environ.pop(k, None)
import main
main = importlib.reload(main)
with TestClient(main.app) as c:
    for _ in range(main.LOGIN_MAX_FAILURES):
        r = c.post("/api/auth/login", json={"username":"admin","password":"DefinitelyWrong@123"})
        assert r.status_code == 401, r.text
    assert c.post("/api/auth/login", json={"username":"admin","password":"Admin@123456"}).status_code == 429
# Simulate a fresh application process. The persistent DB throttle must still apply.
sys.modules.pop("main", None)
main = importlib.import_module("main")
main = importlib.reload(main)
with TestClient(main.app) as c:
    assert c.post("/api/auth/login", json={"username":"admin","password":"Admin@123456"}).status_code == 429
print("LOGIN_THROTTLE_PERSISTENCE_OK")

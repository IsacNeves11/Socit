import json, subprocess, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

root=Path(__file__).resolve().parents[1]
sample=root/'backend/examples/wazuh_bruteforce.json'
received={}
class H(BaseHTTPRequestHandler):
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0'))
        received['headers']=dict(self.headers)
        received['body']=self.rfile.read(n)
        self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b'{"accepted":true}')
    def log_message(self,*args): pass

server=HTTPServer(('127.0.0.1',0),H)
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/hook'
cmd=[sys.executable,str(root/'integrations/wazuh_integration.py'),str(sample),'bridge-secret',url]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
server.shutdown()
assert r.returncode==0, r.stderr
assert 'accepted' in r.stdout
assert any(k.lower()=='x-soc-webhook-token' and v=='bridge-secret' for k,v in received['headers'].items())
json.loads(received['body'])
# manual backward-compatible mode
server=HTTPServer(('127.0.0.1',0),H); received.clear(); threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}/hook'
r=subprocess.run([sys.executable,str(root/'integrations/wazuh_integration.py'),str(sample),url],capture_output=True,text=True,timeout=10)
server.shutdown(); assert r.returncode==0, r.stderr
assert not any(k.lower()=='x-soc-webhook-token' for k in received['headers'])
print('WAZUH_BRIDGE_OK')

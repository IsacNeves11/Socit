import json, subprocess, sys, tempfile, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
received = {"count": 0, "auth": None, "payload": None}

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        received["count"] += 1
        body = self.rfile.read(length)
        received["auth"] = self.headers.get("X-SOC-Webhook-Token")
        received["payload"] = json.loads(body.decode("utf-8"))
        if received["count"] < 3:
            self.send_response(503)
            self.end_headers()
            self.wfile.write(b"retry")
            return
        self.send_response(202)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"accepted":true}')
    def log_message(self, *_args):
        pass

server = HTTPServer(("127.0.0.1", 0), Handler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()

try:
    with tempfile.TemporaryDirectory() as td:
        alert = Path(td) / "alert.json"
        alert.write_text(json.dumps({"id":"retry-test","rule":{"id":"100100","level":12},"agent":{"id":"001"}}), encoding="utf-8")
        url = f"http://127.0.0.1:{server.server_port}/hook"
        proc = subprocess.run(
            [sys.executable, str(ROOT / "integrations" / "wazuh_integration.py"), str(alert), "bridge-secret", url],
            capture_output=True, text=True, timeout=12,
        )
        assert proc.returncode == 0, proc.stderr or proc.stdout
        assert received["count"] == 3
        assert received["auth"] == "bridge-secret"
        assert received["payload"]["id"] == "retry-test"
finally:
    server.shutdown()
    server.server_close()

# Unsafe schemes must be rejected before any network request.
with tempfile.TemporaryDirectory() as td:
    alert = Path(td) / "alert.json"
    alert.write_text("{}", encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, str(ROOT / "integrations" / "wazuh_integration.py"), str(alert), "bridge-secret", "file:///etc/passwd"],
        capture_output=True, text=True, timeout=5,
    )
    assert proc.returncode != 0
    assert "hook_url precisa usar" in (proc.stderr + proc.stdout)

print("WAZUH_BRIDGE_RETRY_OK")

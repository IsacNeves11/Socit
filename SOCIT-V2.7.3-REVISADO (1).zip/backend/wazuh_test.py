import json
import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import main

def reset_db():
    tmp = Path(tempfile.mkdtemp(prefix="soc-v24-wazuh-test-")) / "soc.db"
    main.DB_PATH = tmp
    main.init_db()

def main_test():
    reset_db()
    sample = json.loads((Path(__file__).resolve().parent / "examples" / "wazuh_bruteforce.json").read_text(encoding="utf-8"))
    normalized = main.normalize_wazuh_alert(sample)
    assert normalized["event_type"] == "brute_force"
    assert normalized["source_ip"] == "198.51.100.44"
    assert normalized["destination_ip"] == "192.168.10.10"
    assert normalized["username"] == "admin"
    assert normalized["asset"] == "srv-ad-01"
    assert normalized["rule_id"] == "5710"
    assert normalized["rule_level"] == 12
    assert normalized["agent_name"] == "srv-ad-01"
    iid,eid = main.process_alert(normalized)
    con = main.db()
    row = con.execute("SELECT * FROM incidents WHERE id=?", (iid,)).fetchone()
    assert row["score"] == 9 and row["severity"] == "critical" and row["priority"] == 1
    evidence = json.loads(row["evidence"])
    assert evidence["integration"]["rule_id"] == "5710"
    assert evidence["integrations"] and evidence["integrations"][-1]["rule_id"] == "5710"
    con.close()
    print("WAZUH_TEST_OK")

if __name__ == "__main__":
    main_test()

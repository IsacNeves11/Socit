import os, tempfile, sys
from pathlib import Path
from fastapi.testclient import TestClient

# Test production guard separately in a subprocess-like import context.
td = tempfile.mkdtemp(prefix='soc-v26-sec-')
os.environ['SOC_DB_PATH']=str(Path(td)/'guard.db')
os.environ['SOC_DEMO_MODE']='0'
os.environ.pop('SOC_ADMIN_PASSWORD',None); os.environ.pop('SOC_SUPERVISOR_PASSWORD',None); os.environ.pop('SOC_ANALYST_PASSWORD',None); os.environ.pop('SOC_WAZUH_WEBHOOK_TOKEN',None)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import main
try:
    main.init_db()
    raise AssertionError('production guard did not fire')
except RuntimeError:
    pass

# Reload in demo mode for HTTP checks.
os.environ['SOC_DEMO_MODE']='1'
import importlib
main = importlib.reload(main)
main.DB_PATH=Path(tempfile.mkdtemp(prefix='soc-v26-http-'))/'soc.db'
main.WAZUH_WEBHOOK_TOKEN='sec-test'
with TestClient(main.app) as c:
    pre=c.options('/api/incidents',headers={'Origin':'http://localhost:8000','Access-Control-Request-Method':'GET','Access-Control-Request-Headers':'authorization'})
    assert pre.status_code==200 and 'authorization' in pre.headers.get('access-control-allow-headers','').lower()
    assert c.get('/api/incidents').status_code==401
    bad=c.post('/api/webhooks/wazuh',json={'timestamp':'2026-10-03T18:00:00+00:00'})
    assert bad.status_code==401
    goodlogin=c.post('/api/auth/login',json={'username':'admin','password':'Admin@123456'})
    assert goodlogin.status_code==200
    token=goodlogin.json()['access_token']; h={'Authorization':f'Bearer {token}'}
    assert c.get('/api/incidents',headers=h).status_code==200
    out=c.post('/api/auth/logout',headers=h); assert out.status_code==200
    assert c.get('/api/incidents',headers=h).status_code==401
print('V27_SECURITY_OK')

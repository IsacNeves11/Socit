import json
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent))
import main


def reset_db():
    main.DB_PATH = Path(tempfile.mkdtemp(prefix="soc-v25-audit-")) / "soc.db"
    main.WORKER_TASKS = []
    main.init_db()


def test_core_and_late_events():
    ts1 = "2026-10-03T15:05:00-03:00"
    i, e1 = main.process_alert({
        "alert_id": "AUD-001", "timestamp": ts1, "source": "wazuh", "event_type": "brute_force",
        "source_ip": "192.0.2.10", "username": "admin", "asset": "srv-ad-01",
        "events_count": 1, "asset_criticality": 5, "threat": 5, "impact": 5, "context": 5,
    })
    i2, e2 = main.process_alert({
        "alert_id": "AUD-002", "timestamp": "2026-10-03T15:03:30-03:00", "source": "wazuh", "event_type": "brute_force",
        "source_ip": "192.0.2.11", "username": "admin", "asset": "srv-ad-01",
        "events_count": 1, "asset_criticality": 5, "threat": 5, "impact": 5, "context": 5,
    })
    assert i2 == i and e2 != e1
    con = main.db(); row = con.execute("SELECT * FROM incidents WHERE id=?", (i,)).fetchone(); con.close()
    assert row["event_count"] == 2
    assert row["last_event_at"] == "2026-10-03T18:05:00+00:00"
    evidence = json.loads(row["evidence"])
    assert evidence["first_event"]["timestamp"] < evidence["last_event"]["timestamp"]

    i3, _ = main.process_alert({
        "alert_id": "AUD-003", "timestamp": "2026-10-03T14:59:00-03:00", "source": "wazuh", "event_type": "brute_force",
        "source_ip": "192.0.2.12", "username": "admin", "asset": "srv-ad-01",
        "events_count": 1, "asset_criticality": 5, "threat": 5, "impact": 5, "context": 5,
    })
    assert i3 != i


def test_dedupe_queue_and_claim_lease():
    payload = {"alert_id": "QUEUE-001", "source": "wazuh", "event_type": "port_scan", "source_ip": "198.51.100.20", "asset": "web-01", "asset_criticality": 3, "threat": 3, "impact": 3, "context": 3}
    q1 = main.enqueue_alert(payload)
    q2 = main.enqueue_alert(payload)
    assert q1 == q2
    job1 = main.claim_queue_job(); assert job1 and job1["status"] == "processing" and job1["claim_token"]
    main.finish_queue_job(int(job1["id"]), "wrong-token", True)
    con=main.db(); status=con.execute("SELECT status FROM queue WHERE id=?",(q1,)).fetchone()[0]; con.close()
    assert status == "processing"
    main.finish_queue_job(int(job1["id"]), str(job1["claim_token"]), False, "boom")
    con=main.db(); row=con.execute("SELECT status,next_attempt_at,attempts FROM queue WHERE id=?",(q1,)).fetchone();
    assert row["status"] == "pending" and row["attempts"] == 1 and row["next_attempt_at"]
    con.execute("UPDATE queue SET next_attempt_at=? WHERE id=?",(main.now_iso(),q1)); con.close()

    # Simulate a stale lease: an old worker must not be able to finish a job reclaimed by a new worker.
    job2 = main.claim_queue_job(); assert job2
    con=main.db(); old=(datetime.now(timezone.utc)-timedelta(seconds=180)).isoformat(); con.execute("UPDATE queue SET started_at=? WHERE id=?",(old,q1)); con.close()
    job3 = main.claim_queue_job(); assert job3 and job3["id"] == q1 and job3["claim_token"] != job2["claim_token"]
    main.finish_queue_job(q1, str(job2["claim_token"]), True)
    con=main.db(); status=con.execute("SELECT status FROM queue WHERE id=?",(q1,)).fetchone()[0]; con.close()
    assert status == "processing"
    main.finish_queue_job(q1, str(job3["claim_token"]), True)
    con=main.db(); status=con.execute("SELECT status FROM queue WHERE id=?",(q1,)).fetchone()[0]; con.close()
    assert status == "done"


def test_wazuh_and_http_security():
    reset_db()
    sample = json.loads((Path(__file__).resolve().parent / "examples" / "wazuh_bruteforce.json").read_text(encoding="utf-8"))
    normalized = main.normalize_wazuh_alert(sample)
    assert normalized["event_type"] == "brute_force"
    level16 = json.loads(json.dumps(sample)); level16["id"]="wazuh-level16"; level16["rule"]["level"]=16
    normalized16 = main.normalize_wazuh_alert(level16)
    assert normalized16["rule_level"] == 16
    assert normalized["source_ip"] == "198.51.100.44"
    assert normalized["destination_ip"] == "192.168.10.10"
    assert normalized["username"] == "admin"
    assert normalized["asset"] == "srv-ad-01"
    assert normalized["rule_id"] == "5710"
    assert normalized["rule_level"] == 12
    main.WAZUH_WEBHOOK_TOKEN = "audit-secret"
    with TestClient(main.app) as client:
        r=client.get("/api/health")
        assert r.status_code == 200 and r.json()["version"] == "2.7.3" and "workers_alive" not in r.json()
        assert client.get("/").status_code == 200
        assert client.get("/backend/main.py").status_code == 404
        assert client.get("/backend/soc.db").status_code == 404
        r=client.options("/api/webhooks/wazuh", headers={"Origin":"http://localhost:8000", "Access-Control-Request-Method":"POST", "Access-Control-Request-Headers":"x-soc-webhook-token,content-type"})
        assert r.status_code == 200 and "x-soc-webhook-token" in r.headers.get("access-control-allow-headers", "").lower()
        r=client.post("/api/webhooks/wazuh/sync", json=sample)
        assert r.status_code == 401
        r=client.post("/api/webhooks/wazuh/sync", json=sample, headers={"X-SOC-Webhook-Token":"audit-secret"})
        assert r.status_code == 200
        r2=client.post("/api/webhooks/wazuh/sync", json=sample, headers={"X-SOC-Webhook-Token":"audit-secret"})
        assert r2.status_code == 200 and r2.json()["event_id"] == r.json()["event_id"]
        login=client.post("/api/auth/login",json={"username":"analyst","password":"Analyst@123456"})
        assert login.status_code==200
        auth={"Authorization":f"Bearer {login.json()['access_token']}"}
        hd=client.get("/api/health/details",headers=auth)
        assert hd.status_code==200 and hd.json()["workers_alive"] >= 0
        inc_id=r.json()["incident_id"]
        paged=client.get(f"/api/incidents/{inc_id}?event_limit=1&audit_limit=1",headers=auth)
        assert paged.status_code==200 and paged.json()["events_pagination"]["limit"]==1
        metrics=client.get("/api/metrics",headers=auth).json()
        assert "by_active_severity" in metrics and metrics["total_event_ingestions"]>=1
        headers={k.lower():v for k,v in r.headers.items()} if False else {k.lower():v for k,v in client.get("/api/health").headers.items()}
        assert "content-security-policy" in headers and "permissions-policy" in headers
        huge={"source":"x", "event_type":"unknown", "raw":{"blob":"x"*(2_100_000)}}
        r=client.post("/api/alerts/sync", json=huge, headers=auth)
        assert r.status_code == 413
        r=client.get("/api/incidents/%s" % ("x"*121,),headers=auth)
        assert r.status_code == 422


def test_concurrency_and_validation():
    reset_db()
    base={"source":"wazuh", "event_type":"brute_force", "username":"admin", "asset":"srv-conc", "asset_criticality":5, "threat":5, "impact":5, "context":5}
    with ThreadPoolExecutor(max_workers=8) as pool:
        ids=list(pool.map(lambda i: main.process_alert({**base,"source_ip":f"10.0.0.{i}","alert_id":f"C-{i}"}), range(40)))
    incident_ids=[x[0] for x in ids]
    assert len(set(incident_ids)) == 1
    con=main.db(); count=con.execute("SELECT event_count FROM incidents WHERE id=?",(incident_ids[0],)).fetchone()[0]; con.close(); assert count == 40
    from pydantic import ValidationError
    try:
        main.AlertIn(asset_criticality=0)
        raise AssertionError("validation missing")
    except ValidationError:
        pass


def test_frontend_contracts():
    app=(Path(__file__).resolve().parents[1]/"frontend"/"js"/"app.js").read_text(encoding="utf-8")
    html=(Path(__file__).resolve().parents[1]/"frontend"/"index.html").read_text(encoding="utf-8")
    assert 'currentView="detail"' in app
    assert 'incidentFilters' in app
    assert 'ownerInput' in app and 'noteInput' in app
    assert 'x.source_ip||"N/A"' in app and 'Authorization' in app and '/auth/login' in app
    assert '/health/details' in app and 'SOCV2.incidents("?limit=500")' in app
    assert 'Iniciar investigação' in app
    assert 'SOC Intelligent Triage V2.7.3' in html


if __name__ == "__main__":
    reset_db()
    test_core_and_late_events()
    test_dedupe_queue_and_claim_lease()
    test_wazuh_and_http_security()
    test_concurrency_and_validation()
    test_frontend_contracts()
    print("FULL_AUDIT_OK 5/5")

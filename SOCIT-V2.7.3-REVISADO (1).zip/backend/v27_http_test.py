import json
import tempfile
from pathlib import Path
import sys
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent))
import main


def reset_db():
    main.DB_PATH = Path(tempfile.mkdtemp(prefix="soc-v251-http-test-")) / "soc.db"
    main.init_db()


def sample():
    return json.loads((Path(__file__).resolve().parent / "examples" / "wazuh_bruteforce.json").read_text(encoding="utf-8"))


if __name__ == "__main__":
    reset_db()
    main.WAZUH_WEBHOOK_TOKEN = "test-secret"
    with TestClient(main.app) as client:
        login=client.post("/api/auth/login",json={"username":"analyst","password":"Analyst@123456"})
        assert login.status_code==200
        auth={"Authorization":f"Bearer {login.json()['access_token']}"}
        payload = sample()
        # Token is required when configured and must be a header.
        r = client.post("/api/webhooks/wazuh/sync", json=payload)
        assert r.status_code == 401, r.text
        r = client.post("/api/webhooks/wazuh/sync", json=payload, headers={"X-SOC-Webhook-Token":"test-secret"})
        assert r.status_code == 200, r.text
        out = r.json()
        assert out["incident_id"] and out["event_id"]

        # Replaying the same Wazuh alert is idempotent.
        r2 = client.post("/api/webhooks/wazuh/sync", json=payload, headers={"X-SOC-Webhook-Token":"test-secret"})
        assert r2.status_code == 200 and r2.json()["event_id"] == out["event_id"]

        # Queue endpoint returns 202 and the worker processes it.
        payload2 = sample(); payload2["id"] = "wazuh-queued-1"
        r3 = client.post("/api/webhooks/wazuh", json=payload2, headers={"X-SOC-Webhook-Token":"test-secret"})
        assert r3.status_code == 202 and r3.json()["queue_id"]

        # Batch endpoint accepts a JSON array up to 100 records.
        b = []
        for i in range(3):
            x = {"source":"batch", "event_type":"port_scan", "source_ip":f"10.0.0.{i+1}", "asset":"web-01", "asset_criticality":2, "threat":2, "impact":2, "context":2}
            b.append(x)
        rb = client.post("/api/alerts/batch", json=b, headers=auth)
        assert rb.status_code == 200 and rb.json()["queued"] == 3

        # Limits on batch size are enforced.
        too_many = b * 34  # 102
        rt = client.post("/api/alerts/batch", json=too_many, headers=auth)
        assert rt.status_code == 422, rt.text

        # Malformed scalar values in the Wazuh SOC extension are safely defaulted/clamped.
        malformed = sample(); malformed["id"] = "wazuh-malformed"; malformed["soc"]["asset_criticality"] = "not-a-number"; malformed["soc"]["business_impact"] = 99
        rm = client.post("/api/webhooks/wazuh/sync", json=malformed, headers={"X-SOC-Webhook-Token":"test-secret"})
        assert rm.status_code == 200, rm.text

        health = client.get("/api/health").json()
        assert health["version"] == "2.7.3"
        assert "queue_size" not in health and "wazuh_webhook" not in health
        details = client.get("/api/health/details", headers=auth)
        assert details.status_code == 200 and details.json()["wazuh_webhook"]["token_required"] is True
    print("V27_HTTP_TEST_OK")

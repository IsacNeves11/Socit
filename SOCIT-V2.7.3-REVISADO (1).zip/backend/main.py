from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
from pathlib import Path
import asyncio
import hashlib
import hmac
import ipaddress
import json
import logging
import os
import re
import time
import secrets
import sqlite3
import threading
import uuid
import base64
from typing import Any

from fastapi import Body, Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

try:
    from .db_compat import DBConnection, HybridRow, hybrid_row_factory, is_unique_violation
except ImportError:  # direct execution of backend tests
    from db_compat import DBConnection, HybridRow, hybrid_row_factory, is_unique_violation

BASE = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("SOC_DB_PATH", str(BASE / "soc.db")))
SOC_DB_URL = os.getenv("SOC_DB_URL", "").strip()
SOC_DB_HOST = os.getenv("SOC_DB_HOST", "").strip()
SOC_DB_PORT = os.getenv("SOC_DB_PORT", "5432").strip() or "5432"
SOC_DB_NAME = os.getenv("SOC_DB_NAME", "soc").strip() or "soc"
SOC_DB_USER = os.getenv("SOC_DB_USER", "soc").strip() or "soc"
SOC_DB_PASSWORD = os.getenv("SOC_DB_PASSWORD", "").strip()
DB_BACKEND = "postgres" if (SOC_DB_URL.lower().startswith(("postgresql://", "postgres://")) or SOC_DB_HOST) else "sqlite"
SOC_ENV = os.getenv("SOC_ENV", "demo").strip().lower() or "demo"
SOC_TRUSTED_ORIGINS = [x.strip() for x in os.getenv("SOC_TRUSTED_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000").split(",") if x.strip()]
SOC_REQUIRE_HTTPS = os.getenv("SOC_REQUIRE_HTTPS", "0").strip().lower() in {"1", "true", "yes"}
def _parse_proxy_networks(value: str):
    networks = []
    for item in value.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            networks.append(ipaddress.ip_network(item, strict=False))
        except ValueError:
            continue
    return networks

SOC_TRUSTED_PROXY_NETWORKS = _parse_proxy_networks(os.getenv("SOC_TRUSTED_PROXY_CIDRS", ""))
CORRELATION_WINDOW_SECONDS = 300
QUEUE_POLL_SECONDS = 0.40
QUEUE_MAX_ATTEMPTS = 3
def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


MAX_BODY_BYTES = env_int("SOC_MAX_BODY_BYTES", 2 * 1024 * 1024, 64 * 1024, 10 * 1024 * 1024)
WORKER_COUNT = env_int("SOC_WORKERS", 2, 1, 8)
SOC_HOST = os.getenv("SOC_HOST", "127.0.0.1").strip() or "127.0.0.1"
SOC_PORT = env_int("SOC_PORT", 8000, 1, 65535)
QUEUE_WAKE = asyncio.Event()
WAZUH_WEBHOOK_TOKEN = os.getenv("SOC_WAZUH_WEBHOOK_TOKEN", "").strip()
SESSION_TTL_SECONDS = env_int("SOC_SESSION_TTL_SECONDS", 8 * 60 * 60, 900, 7 * 24 * 60 * 60)
# Default operating timezone for business-hours scoring: UTC-03 (Brazil). Override for another SOC.
SOC_TIMEZONE_OFFSET_HOURS = env_int("SOC_TIMEZONE_OFFSET_HOURS", -3, -12, 14)
SOC_DEMO_MODE = (SOC_ENV == "demo") and (os.getenv("SOC_DEMO_MODE", "1").strip().lower() not in {"0", "false", "no"})
LOGIN_WINDOW_SECONDS = 300
LOGIN_MAX_FAILURES = 5
PBKDF2_ITERATIONS = 310_000
APP_VERSION = "2.7.3"
DEFAULT_DEMO_PASSWORDS = {
    "admin": "Admin@123456",
    "supervisor": "Supervisor@123456",
    "analyst": "Analyst@123456",
}

logger = logging.getLogger("soc-intelligent-triage")
logging.basicConfig(level=os.getenv("SOC_LOG_LEVEL", "INFO").upper(), format="%(asctime)s %(levelname)s %(name)s %(message)s")
WORKER_TASKS: list[asyncio.Task] = []
LOGIN_ATTEMPTS: dict[str, list[float]] = {}
LOGIN_LOCK = threading.Lock()
ROLE_ORDER = {"analyst": 1, "supervisor": 2, "admin": 3}

SEVERITY_BY_SCORE = [
    (7, "critical", 1),
    (6, "high", 2),
    (4, "medium", 3),
    (1, "low", 4),
]


class AlertIn(BaseModel):
    model_config = ConfigDict(extra="allow")

    timestamp: datetime | None = None
    source: str = Field(default="unknown", max_length=100)
    event_type: str = Field(default="unknown", max_length=80)
    title: str = Field(default="Security alert", max_length=240)
    source_ip: str | None = Field(default=None, max_length=64)
    destination_ip: str | None = Field(default=None, max_length=64)
    username: str | None = Field(default=None, max_length=160)
    asset: str | None = Field(default=None, max_length=200)
    asset_criticality: int = Field(default=2, ge=1, le=5)
    threat: int | None = Field(default=None, ge=1, le=5)
    impact: int | None = Field(default=None, ge=1, le=5)
    context: int | None = Field(default=None, ge=1, le=5)
    raw: dict[str, Any] = Field(default_factory=dict)

    # Compatibility aliases used by the project's original integration contract.
    alert_id: str | None = Field(default=None, max_length=240)
    target: str | None = Field(default=None, max_length=200)
    user: str | None = Field(default=None, max_length=160)
    threat_type: str | None = Field(default=None, max_length=80)
    events_count: int = Field(default=1, ge=1, le=100000)
    business_impact: int | None = Field(default=None, ge=1, le=5)
    context_score: int | None = Field(default=None, ge=1, le=5)
    description: str | None = Field(default=None, max_length=1000)

    # Optional SIEM/Wazuh context retained for traceability and dashboard detail.
    rule_id: str | None = Field(default=None, max_length=80)
    rule_level: int | None = Field(default=None, ge=0, le=16)
    agent_id: str | None = Field(default=None, max_length=80)
    agent_name: str | None = Field(default=None, max_length=200)
    manager_name: str | None = Field(default=None, max_length=200)
    mitre_ids: list[str] = Field(default_factory=list, max_length=30)

    @model_validator(mode="after")
    def normalize_input(self):
        if self.threat_type and self.event_type == "unknown":
            self.event_type = self.threat_type
        if self.user and not self.username:
            self.username = self.user
        if self.target and not self.asset:
            self.asset = self.target
        if self.business_impact is not None and self.impact is None:
            self.impact = self.business_impact
        if self.context_score is not None and self.context is None:
            self.context = self.context_score

        # "source" is usually the collector/system name. Only promote it to an IP
        # when it really parses as an address.
        if self.source_ip is None and self.source and self.source != "unknown":
            try:
                ipaddress.ip_address(self.source)
                self.source_ip = self.source
            except ValueError:
                pass

        if self.description and self.title == "Security alert":
            self.title = self.description

        self.event_type = (self.event_type or "unknown").strip().lower()
        if self.threat is None:
            self.threat = derive_threat(self.event_type, self.events_count)
        if self.impact is None:
            self.impact = 2
        if self.context is None:
            self.context = 2
        if len(json.dumps(self.raw, ensure_ascii=False, default=str)) > 120_000:
            raise ValueError("raw payload exceeds 120 KB")
        return self


class StatusIn(BaseModel):
    status: str = Field(min_length=1, max_length=30)
    owner: str | None = Field(default=None, max_length=120)
    owner_user_id: str | None = Field(default=None, max_length=80)
    note: str | None = Field(default=None, max_length=1000)


class LoginIn(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=8, max_length=200)


class PasswordChangeIn(BaseModel):
    current_password: str = Field(min_length=8, max_length=200)
    new_password: str = Field(min_length=12, max_length=200)


class UserCreateIn(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    display_name: str = Field(min_length=1, max_length=120)
    role: str = Field(default="analyst", min_length=5, max_length=20)
    password: str = Field(min_length=12, max_length=200)


class UserUpdateIn(BaseModel):
    display_name: str | None = Field(default=None, min_length=1, max_length=120)
    role: str | None = Field(default=None, min_length=5, max_length=20)
    active: bool | None = None


class AlertResponse(BaseModel):
    accepted: bool
    message: str
    event_id: int | None = None
    incident_id: str | None = None
    queue_id: int | None = None


def password_policy(password: str) -> None:
    if len(password) < 12:
        raise HTTPException(400, "Password must contain at least 12 characters")
    if not re.search(r"[A-Z]", password) or not re.search(r"[a-z]", password) or not re.search(r"\d", password) or not re.search(r"[^A-Za-z0-9]", password):
        raise HTTPException(400, "Password must contain upper, lower, numeric and special characters")


def hash_password(password: str) -> str:
    password_policy(password)
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_b64, digest_b64 = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        iterations_i = int(iterations)
        salt = base64.urlsafe_b64decode(salt_b64.encode())
        expected = base64.urlsafe_b64decode(digest_b64.encode())
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations_i)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


DUMMY_PASSWORD_HASH = hash_password("Unusable-Dummy-Auth-Token-2027!")


def normalize_username(username: str) -> str:
    return username.strip().lower()


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _trusted_proxy(request: Request) -> bool:
    raw = _client_ip(request)
    try:
        addr = ipaddress.ip_address(raw)
    except ValueError:
        return False
    return any(addr in network for network in SOC_TRUSTED_PROXY_NETWORKS)


def login_rate_limited(ip: str) -> bool:
    now = datetime.now(timezone.utc)
    now_iso_value = now.isoformat()
    # Fast local path, then authoritative persisted state shared by all workers.
    with LOGIN_LOCK:
        entries = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now.timestamp() - t < LOGIN_WINDOW_SECONDS]
        LOGIN_ATTEMPTS[ip] = entries
        if len(entries) >= LOGIN_MAX_FAILURES:
            return True
    con = db()
    try:
        row = con.execute("SELECT window_started_at, failure_count FROM login_throttle WHERE ip_address=?", (ip,)).fetchone()
        if not row:
            return False
        try:
            started = datetime.fromisoformat(str(row[0]))
        except ValueError:
            return False
        if now - started >= timedelta(seconds=LOGIN_WINDOW_SECONDS):
            return False
        return int(row[1]) >= LOGIN_MAX_FAILURES
    finally:
        con.close()


def register_login_failure(ip: str) -> None:
    now = datetime.now(timezone.utc)
    now_iso_value = now.isoformat()
    with LOGIN_LOCK:
        entries = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now.timestamp() - t < LOGIN_WINDOW_SECONDS]
        entries.append(now.timestamp())
        LOGIN_ATTEMPTS[ip] = entries[-LOGIN_MAX_FAILURES:]
        if len(LOGIN_ATTEMPTS) > 10000:
            stale = [key for key, times in LOGIN_ATTEMPTS.items() if not times or now.timestamp() - times[-1] >= LOGIN_WINDOW_SECONDS]
            for key in stale[:2000]:
                LOGIN_ATTEMPTS.pop(key, None)
            if len(LOGIN_ATTEMPTS) > 10000:
                victims = sorted(LOGIN_ATTEMPTS.items(), key=lambda item: item[1][-1] if item[1] else 0)[:1000]
                for key, _ in victims:
                    LOGIN_ATTEMPTS.pop(key, None)
    con = db()
    try:
        begin_tx(con)
        select_sql = "SELECT window_started_at, failure_count FROM login_throttle WHERE ip_address=?" + (" FOR UPDATE" if DB_BACKEND == "postgres" else "")
        row = con.execute(select_sql, (ip,)).fetchone()
        if not row:
            con.execute("INSERT INTO login_throttle(ip_address,window_started_at,failure_count,last_attempt_at) VALUES(?,?,?,?)", (ip, now_iso_value, 1, now_iso_value))
        else:
            try:
                started = datetime.fromisoformat(str(row[0]))
            except ValueError:
                started = now
            count = 1 if now - started >= timedelta(seconds=LOGIN_WINDOW_SECONDS) else min(LOGIN_MAX_FAILURES, int(row[1]) + 1)
            window_started = now_iso_value if count == 1 else row[0]
            con.execute("UPDATE login_throttle SET window_started_at=?,failure_count=?,last_attempt_at=? WHERE ip_address=?", (window_started, count, now_iso_value, ip))
        cutoff = (now - timedelta(seconds=LOGIN_WINDOW_SECONDS * 2)).isoformat()
        con.execute("DELETE FROM login_throttle WHERE last_attempt_at < ?", (cutoff,))
        con.execute("COMMIT")
    except Exception:
        try: con.execute("ROLLBACK")
        except Exception: pass
        # Keep the local limiter as a safe fallback if the throttle store is unavailable.
    finally:
        con.close()


def clear_login_failures(ip: str) -> None:
    with LOGIN_LOCK:
        LOGIN_ATTEMPTS.pop(ip, None)
    con = db()
    try:
        con.execute("DELETE FROM login_throttle WHERE ip_address=?", (ip,))
    finally:
        con.close()


def create_session(con: sqlite3.Connection, user_id: str, request: Request) -> str:
    token = secrets.token_urlsafe(48)
    now = datetime.now(timezone.utc)
    expires = now.timestamp() + SESSION_TTL_SECONDS
    expires_dt = datetime.fromtimestamp(expires, tz=timezone.utc)
    con.execute("INSERT INTO sessions(id,user_id,token_hash,created_at,expires_at,revoked_at,ip_address) VALUES(?,?,?,?,?,?,?)",
                (uuid.uuid4().hex, user_id, hash_token(token), now.isoformat(), expires_dt.isoformat(), None, _client_ip(request)))
    return token


def require_auth(authorization: str | None = Header(default=None, alias="Authorization")) -> dict[str, Any]:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Authentication required")
    token = authorization[7:].strip()
    if not token or len(token) > 256:
        raise HTTPException(401, "Invalid authentication token")
    con = db()
    try:
        row = con.execute("""SELECT u.id,u.username,u.display_name,u.role,u.active,s.token_hash,s.expires_at
                            FROM sessions s JOIN users u ON u.id=s.user_id
                            WHERE s.token_hash=? AND s.revoked_at IS NULL""", (hash_token(token),)).fetchone()
        if not row:
            raise HTTPException(401, "Invalid authentication token")
        try:
            expires = datetime.fromisoformat(row["expires_at"])
        except ValueError:
            raise HTTPException(401, "Invalid session expiry")
        if expires <= datetime.now(timezone.utc):
            con.execute("UPDATE sessions SET revoked_at=? WHERE token_hash=?", (now_iso(), row["token_hash"]))
            raise HTTPException(401, "Session expired")
        if not row["active"]:
            raise HTTPException(403, "User inactive")
        return {k: row[k] for k in ("id","username","display_name","role") }
    finally:
        con.close()


def require_role(user: dict[str, Any], minimum_role: str) -> None:
    if ROLE_ORDER.get(str(user.get("role")), 0) < ROLE_ORDER[minimum_role]:
        raise HTTPException(403, "Insufficient permissions")


def audit_auth_action(con: sqlite3.Connection, user: dict[str, Any], action: str, note: str | None = None) -> None:
    # Auth actions are kept in a separate table because incident_id is not applicable.
    con.execute("INSERT INTO auth_audit(user_id,username,created_at,action,note) VALUES(?,?,?,?,?)",
                (user["id"], user["username"], now_iso(), action, note))


def derive_threat(event_type: str, event_count: int) -> int:
    if event_type == "brute_force":
        return 5 if event_count >= 10 else 4 if event_count >= 3 else 3
    if event_type in {"malware", "data_exfiltration"}:
        return 5
    if event_type in {"malicious_ip", "anomalous_login"}:
        return 4
    if event_type == "port_scan":
        return 3
    return 2




def _first_path(payload: Any, paths: list[tuple[str, ...]]) -> Any:
    for path in paths:
        cur = payload
        ok = True
        for key in path:
            if not isinstance(cur, dict) or key not in cur:
                ok = False
                break
            cur = cur[key]
        if ok and cur not in (None, ""):
            return cur
    return None


def _collect_values(payload: Any, keys: set[str], limit: int = 50) -> list[Any]:
    found: list[Any] = []
    def walk(node: Any) -> None:
        if len(found) >= limit:
            return
        if isinstance(node, dict):
            for k, v in node.items():
                if k.lower() in keys and v not in (None, ""):
                    found.append(v)
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(node, list):
            for item in node:
                walk(item)
    walk(payload)
    return found


def _looks_like_ip(value: Any) -> bool:
    if value in (None, ""):
        return False
    try:
        ipaddress.ip_address(str(value))
        return True
    except ValueError:
        return False


def infer_wazuh_event_type(alert: dict[str, Any]) -> str:
    explicit = _first_path(alert, [
        ("soc", "event_type"), ("data", "event_type"), ("event_type",),
    ])
    if explicit:
        return str(explicit).strip().lower()
    groups = _first_path(alert, [("rule", "groups"), ("groups",)]) or []
    text = " ".join(map(str, groups if isinstance(groups, list) else [groups]))
    description = str(_first_path(alert, [("rule", "description"), ("description",)]) or "")
    haystack = f"{text} {description}".lower()
    rules = [
        ("brute_force", ["brute force", "authentication failure", "authentication_failed", "multiple failed", "failed logins", "ssh failed", "invalid user"]),
        ("malware", ["malware", "trojan", "virus", "ransomware", "rootkit", "suspicious file"]),
        ("port_scan", ["port scan", "portscan", "scan detected", "network scan", "reconnaissance"]),
        ("malicious_ip", ["malicious ip", "blacklisted ip", "threat intel", "virustotal", "reputation"]),
        ("data_exfiltration", ["exfiltration", "data transfer", "large upload", "unusual outbound"]),
        ("anomalous_login", ["anomalous login", "unusual login", "login outside", "impossible travel"]),
    ]
    for event_type, needles in rules:
        if any(n in haystack for n in needles):
            return event_type
    return "unknown"


def _bounded_int(value: Any, default: int, minimum: int, maximum: int) -> int:
    try:
        return max(minimum, min(maximum, int(value)))
    except (TypeError, ValueError):
        return default


def normalize_wazuh_alert(alert: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(alert, dict):
        raise ValueError("Wazuh alert must be a JSON object")
    rule = alert.get("rule") if isinstance(alert.get("rule"), dict) else {}
    agent = alert.get("agent") if isinstance(alert.get("agent"), dict) else {}
    manager = alert.get("manager") if isinstance(alert.get("manager"), dict) else {}
    data = alert.get("data") if isinstance(alert.get("data"), dict) else {}
    soc = alert.get("soc") if isinstance(alert.get("soc"), dict) else {}

    event_type = infer_wazuh_event_type(alert)
    src_ip = _first_path(alert, [("data", "srcip"), ("data", "src_ip"), ("srcip",), ("src_ip",), ("data", "src"), ("src",)])
    dst_ip = _first_path(alert, [("data", "dstip"), ("data", "dst_ip"), ("data", "dest_ip"), ("dstip",), ("dst_ip",), ("dest_ip",)])
    username = _first_path(alert, [("data", "dstuser"), ("data", "user"), ("data", "srcuser"), ("dstuser",), ("user",), ("username",)])
    agent_name = agent.get("name") or _first_path(alert, [("host",), ("hostname",)])
    asset = soc.get("asset") or agent_name or _first_path(alert, [("host",), ("hostname",)])
    source = soc.get("source") or manager.get("name") or "wazuh"
    title = rule.get("description") or alert.get("description") or f"Wazuh alert {rule.get('id') or alert.get('id') or ''}".strip()
    timestamp = alert.get("timestamp") or now_iso()
    alert_id = alert.get("id") or soc.get("alert_id")
    if not alert_id:
        stable = json.dumps({"timestamp": timestamp, "rule_id": rule.get("id"), "agent_id": agent.get("id"), "full_log": alert.get("full_log")}, sort_keys=True, ensure_ascii=False, default=str)
        alert_id = "wazuh-" + hashlib.sha256(stable.encode("utf-8")).hexdigest()[:20]

    rule_level = rule.get("level")
    try:
        rule_level = max(0, min(16, int(rule_level))) if rule_level is not None else None
    except (TypeError, ValueError):
        rule_level = None
    threat = soc.get("threat")
    if threat is None:
        if rule_level is None:
            threat = derive_threat(event_type, 1)
        elif rule_level >= 12:
            threat = 5
        elif rule_level >= 10:
            threat = 4
        elif rule_level >= 7:
            threat = 3
        elif rule_level >= 5:
            threat = 2
        else:
            threat = 1

    asset_criticality = soc.get("asset_criticality", 2)
    impact = soc.get("business_impact", soc.get("impact", 2))
    context = soc.get("context_score", soc.get("context", 2))
    events_count = soc.get("events_count", 1)
    mitre = []
    mitre_obj = rule.get("mitre") if isinstance(rule.get("mitre"), dict) else {}
    for key in ("id", "ids", "technique", "techniques"):
        value = mitre_obj.get(key)
        if isinstance(value, list): mitre.extend(str(v) for v in value)
        elif value: mitre.append(str(value))
    mitre.extend(str(v) for v in _collect_values(alert, {"id"}) if isinstance(v, str) and re.fullmatch(r"T\d{4}(?:\.\d{3})?", v))
    mitre = sorted(set(mitre))[:30]

    raw = dict(alert)
    raw["_soc_adapter"] = {"version": APP_VERSION, "event_type": event_type, "source_ip": src_ip, "destination_ip": dst_ip, "username": username, "asset": asset}
    return {
        "alert_id": str(alert_id)[:240], "timestamp": timestamp, "source": str(source)[:100],
        "event_type": event_type, "title": str(title)[:240], "source_ip": str(src_ip)[:64] if _looks_like_ip(src_ip) else None,
        "destination_ip": str(dst_ip)[:64] if _looks_like_ip(dst_ip) else None, "username": str(username)[:160] if username else None,
        "asset": str(asset)[:200] if asset else None, "asset_criticality": _bounded_int(asset_criticality, 2, 1, 5),
        "threat": _bounded_int(threat, 2, 1, 5), "impact": _bounded_int(impact, 2, 1, 5),
        "context": _bounded_int(context, 2, 1, 5), "events_count": _bounded_int(events_count, 1, 1, 100000),
        "description": str(title)[:1000], "rule_id": str(rule.get("id")) if rule.get("id") is not None else None,
        "rule_level": rule_level, "agent_id": str(agent.get("id")) if agent.get("id") is not None else None,
        "agent_name": str(agent_name) if agent_name else None, "manager_name": str(manager.get("name")) if manager.get("name") else None,
        "mitre_ids": mitre, "raw": raw,
    }


def require_wazuh_token(token: str | None) -> None:
    if WAZUH_WEBHOOK_TOKEN and not hmac.compare_digest(token or "", WAZUH_WEBHOOK_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid Wazuh webhook token")


def _json_size_limit(request: Request) -> int:
    value = request.headers.get("content-length")
    try:
        return int(value) if value else 0
    except ValueError:
        return 0


async def body_limit_middleware(request: Request, call_next):
    supplied_request_id = request.headers.get("X-Request-ID", "")
    request_id = re.sub(r"[^A-Za-z0-9._:-]", "-", supplied_request_id.strip())[:100] or uuid.uuid4().hex
    started = time.perf_counter()
    try:
        forwarded_proto = ""
        if _trusted_proxy(request):
            forwarded_proto = request.headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower()
        is_https = request.url.scheme == "https" or forwarded_proto == "https"
        if SOC_REQUIRE_HTTPS and request.method != "OPTIONS" and request.url.path not in {"/api/health", "/api/ready"} and not is_https:
            response = JSONResponse({"detail": "HTTPS is required for this deployment"}, status_code=400)
        elif request.method in {"POST", "PUT", "PATCH"}:
            declared = _json_size_limit(request)
            if declared and declared > MAX_BODY_BYTES:
                response = JSONResponse({"detail": f"Request body exceeds {MAX_BODY_BYTES} bytes"}, status_code=413)
            else:
                chunks: list[bytes] = []
                total = 0
                oversized = False
                async for chunk in request.stream():
                    total += len(chunk)
                    if total > MAX_BODY_BYTES:
                        oversized = True
                        break
                    chunks.append(chunk)
                if oversized:
                    response = JSONResponse({"detail": f"Request body exceeds {MAX_BODY_BYTES} bytes"}, status_code=413)
                else:
                    request._body = b"".join(chunks)
                    response = await call_next(request)
        else:
            response = await call_next(request)
        response.headers.setdefault("X-Request-ID", request_id)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if SOC_REQUIRE_HTTPS and is_https:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        elapsed_ms = (time.perf_counter() - started) * 1000
        logger.info("request_id=%s method=%s path=%s status=%s duration_ms=%.1f", request_id, request.method, request.url.path, response.status_code, elapsed_ms)
        return response
    except Exception:
        elapsed_ms = (time.perf_counter() - started) * 1000
        logger.exception("request_id=%s method=%s path=%s duration_ms=%.1f unhandled_error", request_id, request.method, request.url.path, elapsed_ms)
        raise

class HybridDBRow(HybridRow):
    pass


def db() -> DBConnection:
    if DB_BACKEND == "postgres":
        try:
            import psycopg
        except ImportError as exc:
            raise RuntimeError("PostgreSQL backend requires psycopg[binary]. Install backend requirements.") from exc
        kwargs = {"autocommit": True, "row_factory": hybrid_row_factory}
        if SOC_DB_HOST:
            raw = psycopg.connect(host=SOC_DB_HOST, port=SOC_DB_PORT, dbname=SOC_DB_NAME, user=SOC_DB_USER, password=SOC_DB_PASSWORD, **kwargs)
        else:
            raw = psycopg.connect(SOC_DB_URL, **kwargs)
        return DBConnection(raw, "postgres")

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    raw = sqlite3.connect(DB_PATH, timeout=15, isolation_level=None)
    raw.row_factory = sqlite3.Row
    raw.execute("PRAGMA busy_timeout=8000")
    raw.execute("PRAGMA journal_mode=WAL")
    raw.execute("PRAGMA foreign_keys=ON")
    return DBConnection(raw, "sqlite")


def _columns(con: DBConnection, table: str) -> set[str]:
    if DB_BACKEND == "postgres":
        rows = con.execute(
            "SELECT column_name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=?",
            (table,),
        ).fetchall()
        return {str(r["column_name"]) for r in rows}
    return {r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()}


def _add_column_if_missing(con: DBConnection, table: str, definition: str) -> None:
    name = definition.split()[0]
    if name not in _columns(con, table):
        con.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")


SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    revoked_at TEXT,
    ip_address TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS auth_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    username TEXT,
    created_at TEXT NOT NULL,
    action TEXT NOT NULL,
    note TEXT
);
CREATE TABLE IF NOT EXISTS login_throttle (
    ip_address TEXT PRIMARY KEY,
    window_started_at TEXT NOT NULL,
    failure_count INTEGER NOT NULL DEFAULT 0,
    last_attempt_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL,
    source TEXT NOT NULL,
    source_ip TEXT,
    destination_ip TEXT,
    username TEXT,
    asset TEXT,
    score INTEGER NOT NULL,
    severity TEXT NOT NULL,
    priority INTEGER NOT NULL,
    event_count INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'open',
    owner TEXT,
    owner_user_id TEXT,
    impact TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    evidence TEXT NOT NULL,
    fingerprint TEXT,
    threat_score INTEGER,
    impact_score INTEGER,
    context_score INTEGER,
    asset_criticality INTEGER,
    last_event_at TEXT,
    rule_id TEXT,
    rule_level INTEGER,
    agent_id TEXT,
    agent_name TEXT,
    manager_name TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT,
    incident_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    source TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    FOREIGN KEY(incident_id) REFERENCES incidents(id)
);
CREATE TABLE IF NOT EXISTS queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id TEXT,
    source TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT,
    error TEXT,
    claim_token TEXT,
    next_attempt_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    action TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    owner TEXT,
    note TEXT,
    actor_user_id TEXT,
    actor_username TEXT,
    FOREIGN KEY(incident_id) REFERENCES incidents(id)
);
CREATE TABLE IF NOT EXISTS schema_meta (
    id INTEGER PRIMARY KEY,
    version INTEGER NOT NULL,
    applied_at TEXT NOT NULL
);
"""

POSTGRES_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    token_hash TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    revoked_at TEXT,
    ip_address TEXT
);
CREATE TABLE IF NOT EXISTS auth_audit (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT,
    username TEXT,
    created_at TEXT NOT NULL,
    action TEXT NOT NULL,
    note TEXT
);
CREATE TABLE IF NOT EXISTS login_throttle (
    ip_address TEXT PRIMARY KEY,
    window_started_at TEXT NOT NULL,
    failure_count INTEGER NOT NULL DEFAULT 0,
    last_attempt_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL,
    source TEXT NOT NULL,
    source_ip TEXT,
    destination_ip TEXT,
    username TEXT,
    asset TEXT,
    score INTEGER NOT NULL,
    severity TEXT NOT NULL,
    priority INTEGER NOT NULL,
    event_count INTEGER NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'open',
    owner TEXT,
    owner_user_id TEXT,
    impact TEXT NOT NULL,
    recommendation TEXT NOT NULL,
    evidence TEXT NOT NULL,
    fingerprint TEXT,
    threat_score INTEGER,
    impact_score INTEGER,
    context_score INTEGER,
    asset_criticality INTEGER,
    last_event_at TEXT,
    rule_id TEXT,
    rule_level INTEGER,
    agent_id TEXT,
    agent_name TEXT,
    manager_name TEXT
);
CREATE TABLE IF NOT EXISTS events (
    id BIGSERIAL PRIMARY KEY,
    alert_id TEXT,
    incident_id TEXT NOT NULL REFERENCES incidents(id),
    timestamp TEXT NOT NULL,
    source TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS queue (
    id BIGSERIAL PRIMARY KEY,
    alert_id TEXT,
    source TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT,
    error TEXT,
    claim_token TEXT,
    next_attempt_at TEXT
);
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    incident_id TEXT NOT NULL REFERENCES incidents(id),
    created_at TEXT NOT NULL,
    action TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    owner TEXT,
    note TEXT,
    actor_user_id TEXT,
    actor_username TEXT
);
CREATE TABLE IF NOT EXISTS schema_meta (
    id INTEGER PRIMARY KEY,
    version INTEGER NOT NULL,
    applied_at TEXT NOT NULL
);
"""


def migrate_db(con: DBConnection) -> None:
    existing_version_row = con.execute("SELECT version FROM schema_meta WHERE id=1").fetchone()
    existing_schema_version = int(existing_version_row["version"]) if existing_version_row else None

    for table, ddl in (("incidents", "CREATE TABLE IF NOT EXISTS incidents (id TEXT PRIMARY KEY, created_at TEXT, updated_at TEXT, title TEXT, event_type TEXT, source TEXT, source_ip TEXT, destination_ip TEXT, username TEXT, asset TEXT, score INTEGER, severity TEXT, priority INTEGER, event_count INTEGER, status TEXT, owner TEXT, impact TEXT, recommendation TEXT, evidence TEXT)"),):
        # The initial schema is created by init_db; this guard exists only for damaged/partial legacy DBs.
        if not _columns(con, table):
            con.execute(ddl)

    for name, definition in (
        ("incidents", "destination_ip TEXT"), ("incidents", "fingerprint TEXT"), ("incidents", "threat_score INTEGER"),
        ("incidents", "impact_score INTEGER"), ("incidents", "context_score INTEGER"), ("incidents", "asset_criticality INTEGER"),
        ("incidents", "last_event_at TEXT"), ("incidents", "owner_user_id TEXT"), ("incidents", "rule_id TEXT"), ("incidents", "rule_level INTEGER"),
        ("incidents", "agent_id TEXT"), ("incidents", "agent_name TEXT"), ("incidents", "manager_name TEXT"),
        ("events", "alert_id TEXT"), ("queue", "alert_id TEXT"), ("queue", "started_at TEXT"), ("queue", "finished_at TEXT"),
        ("queue", "attempts INTEGER NOT NULL DEFAULT 0"), ("queue", "error TEXT"), ("queue", "claim_token TEXT"), ("queue", "next_attempt_at TEXT"),
        ("audit_log", "actor_user_id TEXT"), ("audit_log", "actor_username TEXT"),
    ):
        _add_column_if_missing(con, name, definition)

    # Backfill fingerprints/risk fields for incidents generated by older versions.
    rows = con.execute("SELECT id, evidence, event_type, username, asset, source_ip, destination_ip FROM incidents WHERE fingerprint IS NULL").fetchall()
    for row in rows:
        evidence = _load_evidence(row["evidence"])
        event = evidence.get("last_event") or evidence.get("first_event") or {}
        event_type = event.get("event_type") or row["event_type"] or "unknown"
        username = event.get("username") or row["username"]
        asset = event.get("asset") or row["asset"]
        source_ip = event.get("source_ip") or row["source_ip"]
        destination_ip = event.get("destination_ip") or row["destination_ip"]
        fp = incident_fingerprint({"event_type": event_type, "username": username, "asset": asset, "source_ip": source_ip, "destination_ip": destination_ip})
        threat = event.get("threat") if event.get("threat") is not None else derive_threat(event_type, 1)
        impact = event.get("impact") if event.get("impact") is not None else 2
        context = event.get("context") if event.get("context") is not None else 2
        asset_criticality = event.get("asset_criticality") or 2
        con.execute(
            """UPDATE incidents SET fingerprint=?, destination_ip=COALESCE(destination_ip,?), threat_score=COALESCE(threat_score,?),
               impact_score=COALESCE(impact_score,?), context_score=COALESCE(context_score,?), asset_criticality=COALESCE(asset_criticality,?) WHERE id=?""",
            (fp, destination_ip, int(threat), int(impact), int(context), int(asset_criticality), row["id"]),
        )

    for stmt in (
        "CREATE INDEX IF NOT EXISTS idx_incidents_fingerprint ON incidents(fingerprint, last_event_at, status)",
        "CREATE INDEX IF NOT EXISTS idx_incidents_updated ON incidents(updated_at)",
        "CREATE INDEX IF NOT EXISTS idx_incidents_owner_user ON incidents(owner_user_id)",
        "CREATE INDEX IF NOT EXISTS idx_events_incident_alert ON events(incident_id, alert_id)",
        "CREATE INDEX IF NOT EXISTS idx_events_alert_id ON events(alert_id)",
        "CREATE INDEX IF NOT EXISTS idx_queue_status_created ON queue(status, created_at)",
        "CREATE INDEX IF NOT EXISTS idx_queue_retry ON queue(status, next_attempt_at, created_at)",
        "CREATE INDEX IF NOT EXISTS idx_audit_incident ON audit_log(incident_id, created_at)",
        "CREATE INDEX IF NOT EXISTS idx_sessions_user_expiry ON sessions(user_id, expires_at)",
        "CREATE INDEX IF NOT EXISTS idx_auth_audit_user ON auth_audit(user_id, created_at)",
        "CREATE INDEX IF NOT EXISTS idx_login_throttle_last_attempt ON login_throttle(last_attempt_at)",
    ):
        con.execute(stmt)
    try:
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_queue_source_alert_active ON queue(source, alert_id) WHERE alert_id IS NOT NULL AND status IN ('pending','processing')")
    except Exception:
        logger.warning("Could not create queue uniqueness index", exc_info=True)
    try:
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS uq_events_source_alert_id ON events(source, alert_id) WHERE alert_id IS NOT NULL")
    except Exception:
        logger.warning("Could not create event uniqueness index", exc_info=True)

    # V2.7.3: scores move from the legacy 0-20 scale to the agreed 1-10 scale.
    # Existing v7 rows are normalized once; incident evidence/events are untouched.
    incident_count_before_score_migration = int(con.execute("SELECT COUNT(*) FROM incidents").fetchone()[0])
    should_normalize_legacy_scores = (
        (existing_schema_version is not None and existing_schema_version < 8)
        or (existing_schema_version is None and incident_count_before_score_migration > 0)
    )
    if should_normalize_legacy_scores:
        con.execute("UPDATE incidents SET score=CASE WHEN score IS NULL OR score < 1 THEN 1 ELSE (score + 1) / 2 END")
        con.execute("""UPDATE incidents SET
            severity=CASE WHEN score >= 7 THEN 'critical' WHEN score >= 5 THEN 'high' WHEN score >= 4 THEN 'medium' ELSE 'low' END,
            priority=CASE WHEN score >= 7 THEN 1 WHEN score >= 5 THEN 2 WHEN score >= 4 THEN 3 ELSE 4 END""")

    version_row = con.execute("SELECT version FROM schema_meta WHERE id=1").fetchone()
    now = now_iso()
    if version_row:
        con.execute("UPDATE schema_meta SET version=?, applied_at=? WHERE id=1", (8, now))
    else:
        con.execute("INSERT INTO schema_meta(id,version,applied_at) VALUES(1,?,?)", (8, now))


def _is_placeholder_secret(value: str) -> bool:
    value = (value or "").strip().lower()
    placeholders = (
        "change-me", "changeme", "replace-me", "replace_this", "your-",
        "your_", "example-secret", "example-password", "default-token", "put-a-", "put_a-", "replace-with-", "replace_with_",
    )
    return any(value.startswith(item) or item in value for item in placeholders)


def _validate_pilot_security_config() -> None:
    if not WAZUH_WEBHOOK_TOKEN or len(WAZUH_WEBHOOK_TOKEN) < 20 or _is_placeholder_secret(WAZUH_WEBHOOK_TOKEN):
        raise RuntimeError("Pilot/production mode requires a non-placeholder SOC_WAZUH_WEBHOOK_TOKEN of at least 20 characters")
    password_envs = (
        ("SOC_ADMIN_PASSWORD", "admin"),
        ("SOC_SUPERVISOR_PASSWORD", "supervisor"),
        ("SOC_ANALYST_PASSWORD", "analyst"),
    )
    for env_name, username in password_envs:
        value = os.getenv(env_name, "").strip()
        if len(value) < 12 or _is_placeholder_secret(value):
            raise RuntimeError(f"Pilot/production mode requires a non-placeholder {env_name} of at least 12 characters")
        if value == DEFAULT_DEMO_PASSWORDS[username]:
            raise RuntimeError(f"Pilot/production mode refuses the default demo credential for {username}")
        if not (re.search(r"[A-Z]", value) and re.search(r"[a-z]", value) and re.search(r"\d", value) and re.search(r"[^A-Za-z0-9]", value)):
            raise RuntimeError(f"{env_name} must contain upper, lower, numeric and special characters")
    if DB_BACKEND == "postgres" and SOC_DB_HOST:
        if not SOC_DB_PASSWORD or _is_placeholder_secret(SOC_DB_PASSWORD):
            raise RuntimeError("Pilot/production mode requires a non-placeholder SOC_DB_PASSWORD")
    elif _is_placeholder_secret(SOC_DB_URL):
        raise RuntimeError("Pilot/production mode refuses placeholder values in SOC_DB_URL")
    default_origins = {"http://127.0.0.1:8000", "http://localhost:8000"}
    if not SOC_TRUSTED_ORIGINS or set(SOC_TRUSTED_ORIGINS) <= default_origins:
        raise RuntimeError("Pilot/production mode requires SOC_TRUSTED_ORIGINS with the real dashboard origin")
    if any("example.com" in origin.lower() or "example.org" in origin.lower() or "example.net" in origin.lower() for origin in SOC_TRUSTED_ORIGINS):
        raise RuntimeError("Pilot/production mode refuses example domains in SOC_TRUSTED_ORIGINS")
    if SOC_ENV == "production" and not SOC_REQUIRE_HTTPS:
        raise RuntimeError("Production mode requires SOC_REQUIRE_HTTPS=1")
    if SOC_REQUIRE_HTTPS and any(not origin.lower().startswith("https://") for origin in SOC_TRUSTED_ORIGINS):
        raise RuntimeError("HTTPS-required mode requires HTTPS origins in SOC_TRUSTED_ORIGINS")
    if SOC_REQUIRE_HTTPS and not SOC_TRUSTED_PROXY_NETWORKS:
        logger.warning("SOC_REQUIRE_HTTPS enabled without SOC_TRUSTED_PROXY_CIDRS; only real HTTPS requests will be accepted")


def init_db() -> None:
    if SOC_ENV not in {"demo", "pilot", "production"}:
        raise RuntimeError("SOC_ENV must be demo, pilot or production")
    if SOC_ENV in {"pilot", "production"}:
        _validate_pilot_security_config()
        if DB_BACKEND != "postgres":
            raise RuntimeError("Pilot/production mode requires SOC_DB_URL pointing to PostgreSQL")
    con = db()
    advisory_locked = False
    try:
        if DB_BACKEND == "postgres":
            con.execute("SELECT pg_advisory_lock(hashtext(?))", ("soc-intelligent-triage:init",)).fetchone()
            advisory_locked = True
        con.executescript(POSTGRES_SCHEMA if DB_BACKEND == "postgres" else SQLITE_SCHEMA)
        migrate_db(con)
        seed_default_users(con)
    finally:
        if advisory_locked:
            try: con.execute("SELECT pg_advisory_unlock(hashtext(?))", ("soc-intelligent-triage:init",)).fetchone()
            except Exception: pass
        con.close()




def seed_default_users(con: DBConnection) -> None:
    defaults = [
        ("admin", "Administrador SOC", "admin", os.getenv("SOC_ADMIN_PASSWORD", "Admin@123456")),
        ("supervisor", "Supervisor SOC", "supervisor", os.getenv("SOC_SUPERVISOR_PASSWORD", "Supervisor@123456")),
        ("analyst", "Analista SOC", "analyst", os.getenv("SOC_ANALYST_PASSWORD", "Analyst@123456")),
    ]
    if not SOC_DEMO_MODE and any(not os.getenv(k) for k in ("SOC_ADMIN_PASSWORD", "SOC_SUPERVISOR_PASSWORD", "SOC_ANALYST_PASSWORD")):
        raise RuntimeError("Pilot/production mode requires SOC_ADMIN_PASSWORD, SOC_SUPERVISOR_PASSWORD and SOC_ANALYST_PASSWORD")
    begin_tx(con)
    try:
        if not SOC_DEMO_MODE:
            for username, _display_name, _role, _configured_password in defaults:
                row = con.execute("SELECT password_hash, active FROM users WHERE username=?", (username,)).fetchone()
                demo_password = DEFAULT_DEMO_PASSWORDS[username]
                if row and verify_password(demo_password, row["password_hash"]):
                    con.execute("ROLLBACK")
                    raise RuntimeError(f"Pilot/production mode refuses the default demo credential for user '{username}'. Change the password before deployment.")
        now = now_iso()
        for username, display_name, role, password in defaults:
            con.execute(
                "INSERT INTO users(id,username,display_name,role,password_hash,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(username) DO NOTHING",
                (uuid.uuid4().hex, username, display_name, role, hash_password(password), 1, now, now),
            )
        con.execute("DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL", (now,))
        con.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user_expiry ON sessions(user_id, expires_at)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_auth_audit_user ON auth_audit(user_id, created_at)")
        con.execute("COMMIT")
    except Exception:
        try: con.execute("ROLLBACK")
        except Exception: pass
        raise


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def event_time_iso(value: Any, fallback: str) -> str:
    if isinstance(value, str):
        try:
            dt = datetime.fromisoformat(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc).isoformat()
        except ValueError:
            pass
    return fallback


def correlation_window_bounds(event_dt: datetime) -> tuple[str, str]:
    """Return a safe +/- correlation window without overflowing datetime limits."""
    if event_dt.tzinfo is None:
        event_dt = event_dt.replace(tzinfo=timezone.utc)
    event_dt = event_dt.astimezone(timezone.utc)
    delta = timedelta(seconds=CORRELATION_WINDOW_SECONDS)
    min_dt = datetime.min.replace(tzinfo=timezone.utc)
    max_dt = datetime.max.replace(tzinfo=timezone.utc)
    lower_dt = min_dt if event_dt <= (min_dt + delta) else event_dt - delta
    upper_dt = max_dt if event_dt >= (max_dt - delta) else event_dt + delta
    return lower_dt.isoformat(), upper_dt.isoformat()


def _is_after_hours(timestamp_value: Any) -> bool:
    """Evaluate alert time in the SOC's configured fixed UTC offset."""
    if not timestamp_value:
        return False
    try:
        if isinstance(timestamp_value, datetime):
            dt = timestamp_value
        else:
            dt = datetime.fromisoformat(str(timestamp_value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone(timedelta(hours=SOC_TIMEZONE_OFFSET_HOURS)))
        local_dt = dt.astimezone(timezone(timedelta(hours=SOC_TIMEZONE_OFFSET_HOURS)))
        return local_dt.hour >= 22 or local_dt.hour < 6
    except (TypeError, ValueError, OverflowError):
        return False


def score_alert(a: dict[str, Any]) -> tuple[int, str, int]:
    """Score 1-10 using the project matrix plus business/security context.

    The average of threat, impact, asset criticality and context establishes a
    1-5 baseline. Failed-login indicators add +1 when isolated or +4 when
    repeated (3+ events / brute-force event). After-hours adds +2; Finance /
    Directorate / executive context adds +3. The result is capped at 10.
    """
    metric_values = [max(1, min(5, int(a.get(key, 2) or 2))) for key in
                    ("threat", "impact", "asset_criticality", "context")]
    baseline = max(1, min(5, (sum(metric_values) + 3) // 4))
    event_type = str(a.get("event_type") or a.get("threat_type") or "unknown").strip().lower().replace("-", "_")
    signal_text = " ".join(str(a.get(key) or "") for key in ("title", "description", "event_type", "threat_type")).lower()
    try:
        event_count = max(1, min(100000, int(a.get("events_count", a.get("event_count", 1)) or 1)))
    except (TypeError, ValueError):
        event_count = 1

    login_failure_types = {
        "brute_force", "authentication_failed", "authentication_failure", "failed_login",
        "login_failure", "login_incorrect", "invalid_login", "invalid_credentials",
        "multiple_failed_logins", "failed_password", "ssh_failed", "login_failed",
    }
    is_login_failure = event_type in login_failure_types or any(phrase in signal_text for phrase in (
        "failed login", "failed password", "authentication failure", "multiple failed", "login incorreto",
        "senha incorreta", "invalid credentials", "brute force", "força bruta",
    ))

    if is_login_failure:
        score = baseline + (4 if event_count >= 3 or event_type in {"brute_force", "multiple_failed_logins"} else 1)
    else:
        type_floor = {
            "malware": 6,
            "data_exfiltration": 6,
            "malicious_ip": 5,
            "anomalous_login": 4,
            "port_scan": 2,
        }.get(event_type, 1)
        score = max(baseline, type_floor)

    if _is_after_hours(a.get("timestamp")):
        score += 2
    business_context = " ".join(str(a.get(key) or "") for key in (
        "username", "asset", "target", "business_unit", "department", "title", "description",
    )).lower()
    if re.search(r"finance|finan|fiscal|diretor|diretoria|executiv|executive|president|presidente|\bcfo\b|\bceo\b|\bboard\b", business_context):
        score += 3

    score = max(1, min(10, int(score)))
    for minimum, severity, priority in SEVERITY_BY_SCORE:
        if score >= minimum:
            return score, severity, priority
    return 1, "low", 4


def incident_fingerprint(a: dict[str, Any]) -> str:
    event_type = (a.get("event_type") or "unknown").lower()
    username = a.get("username") or "-"
    asset = a.get("asset") or "-"
    source_ip = a.get("source_ip") or "-"
    destination_ip = a.get("destination_ip") or "-"

    # Prefer stable business/security anchors. If those anchors are missing,
    # fall back to source so unrelated unknown events do not collapse together.
    if event_type in {"brute_force", "anomalous_login"}:
        if username != "-" or asset != "-" or destination_ip != "-":
            parts = [event_type, username, asset, destination_ip]
        else:
            parts = [event_type, source_ip]
    elif event_type in {"malware", "data_exfiltration"}:
        if asset != "-" or username != "-" or destination_ip != "-":
            parts = [event_type, asset, username, destination_ip]
        else:
            parts = [event_type, source_ip]
    elif event_type == "port_scan":
        parts = [event_type, source_ip, asset, destination_ip]
    elif event_type == "malicious_ip":
        parts = [event_type, source_ip, destination_ip, asset]
    else:
        parts = [event_type, username, asset, source_ip, destination_ip]
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:16]


def recommendation(event_type: str, severity: str) -> str:
    playbooks = {
        "brute_force": "Validar origem, bloquear IP se confirmado malicioso, forçar troca de senha e revisar autenticações recentes.",
        "malicious_ip": "Isolar a comunicação com o destino, validar reputação do IP e investigar o endpoint afetado.",
        "malware": "Isolar o endpoint, coletar evidências, executar varredura e revisar persistência/credenciais afetadas.",
        "anomalous_login": "Validar identidade do usuário, revisar localização/horário e revogar sessões se houver indícios de comprometimento.",
        "port_scan": "Verificar origem, escopo da varredura e exposição dos ativos; bloquear origem somente após validação.",
        "data_exfiltration": "Preservar evidências, restringir o canal suspeito e investigar volume, destino e conta envolvida.",
    }
    base = playbooks.get(event_type, "Validar o evento, coletar evidências e seguir o playbook correspondente.")
    return "PRIORIDADE CRÍTICA: " + base if severity == "critical" else base


def impact_text(a: dict[str, Any]) -> str:
    if a["impact"] >= 4 or a["asset_criticality"] >= 4:
        return "Potencial impacto alto em ativo ou operação crítica."
    if a["impact"] >= 3:
        return "Potencial impacto moderado; requer investigação."
    return "Impacto potencial limitado com os dados disponíveis."


def _load_evidence(raw: Any) -> dict[str, Any]:
    try:
        data = json.loads(raw or "{}") if isinstance(raw, str) else raw
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _source_ips_from_evidence(evidence: dict[str, Any]) -> list[str]:
    values = evidence.get("source_ips", [])
    return [str(v) for v in values if v] if isinstance(values, list) else []


def begin_tx(con: DBConnection) -> None:
    con.execute("BEGIN IMMEDIATE" if DB_BACKEND == "sqlite" else "BEGIN")


def lock_correlation(con: DBConnection, fingerprint: str) -> None:
    """Serialize only events targeting the same correlation fingerprint on PostgreSQL."""
    if DB_BACKEND == "postgres":
        con.execute("SELECT pg_advisory_xact_lock(hashtext(?))", (fingerprint,)).fetchone()


def find_open_incident(con: DBConnection, a: dict[str, Any]) -> HybridRow | None:
    fp = incident_fingerprint(a)
    event_iso = event_time_iso(a.get("timestamp"), now_iso())
    event_dt = datetime.fromisoformat(event_iso)
    lower, upper = correlation_window_bounds(event_dt)
    if DB_BACKEND == "postgres":
        return con.execute(
            """SELECT * FROM incidents
               WHERE status NOT IN ('resolved','false_positive') AND fingerprint=?
                 AND COALESCE(last_event_at, updated_at) BETWEEN ? AND ?
               ORDER BY ABS(EXTRACT(EPOCH FROM (COALESCE(last_event_at, updated_at)::timestamptz - ?::timestamptz))) ASC, updated_at DESC
               LIMIT 1""",
            (fp, lower, upper, event_iso),
        ).fetchone()
    return con.execute(
        """SELECT * FROM incidents
           WHERE status NOT IN ('resolved','false_positive') AND fingerprint=?
             AND julianday(COALESCE(last_event_at, updated_at)) BETWEEN julianday(?) AND julianday(?)
           ORDER BY ABS((julianday(COALESCE(last_event_at, updated_at)) - julianday(?)) * 86400.0) ASC, julianday(updated_at) DESC
           LIMIT 1""",
        (fp, lower, upper, event_iso),
    ).fetchone()


def lock_postgres_advisory(con: DBConnection, key: str) -> None:
    if DB_BACKEND == "postgres":
        con.execute("SELECT pg_advisory_xact_lock(hashtext(?))", (key,)).fetchone()


def compact_event_for_evidence(a: dict[str, Any]) -> dict[str, Any]:
    """Keep incident evidence small; the complete payload remains in events.payload."""
    keep = (
        "alert_id", "timestamp", "source", "event_type", "title", "source_ip",
        "destination_ip", "username", "asset", "asset_criticality", "threat",
        "impact", "context", "events_count", "description", "rule_id", "rule_level",
        "agent_id", "agent_name", "manager_name", "mitre_ids",
    )
    out = {k: a.get(k) for k in keep if k in a}
    raw = a.get("raw")
    if isinstance(raw, dict):
        raw_bytes = json.dumps(raw, ensure_ascii=False, default=str).encode("utf-8")
        out["raw_hash"] = hashlib.sha256(raw_bytes).hexdigest()
        if len(raw_bytes) <= 16_384:
            out["raw"] = raw
        else:
            out["raw_excerpt"] = raw_bytes[:16_384].decode("utf-8", errors="replace")
            out["raw_truncated"] = True
    return out


def process_alert(a: dict[str, Any]) -> tuple[str, int | None]:
    validated = AlertIn.model_validate(a)
    payload = validated.model_dump(mode="json")
    payload["timestamp"] = event_time_iso(payload.get("timestamp"), now_iso())
    if not payload.get("alert_id"):
        payload["alert_id"] = "internal-" + uuid.uuid4().hex
    con = db()
    try:
        begin_tx(con)
        alert_id = payload.get("alert_id")
        source = str(payload.get("source") or "unknown")[:100]
        lock_postgres_advisory(con, f"alert:{source}:{alert_id}")
        if alert_id:
            existing_event = con.execute(
                "SELECT id, incident_id FROM events WHERE source=? AND alert_id=?",
                (source, alert_id),
            ).fetchone()
            if existing_event:
                con.execute("COMMIT")
                return existing_event["incident_id"], int(existing_event["id"])

        base_event_count = int(payload.get("events_count") or 1)
        payload["source"] = source
        payload["title"] = str(payload.get("title") or "Security alert")[:240]
        event_type = (payload.get("event_type") or "unknown").strip().lower()
        payload["event_type"] = event_type
        payload["threat"] = int(payload.get("threat") or derive_threat(event_type, base_event_count))
        payload["impact"] = int(payload.get("impact") or 2)
        payload["context"] = int(payload.get("context") or 2)
        payload["asset_criticality"] = int(payload.get("asset_criticality") or 2)
        payload["source_ip"] = payload.get("source_ip") if _looks_like_ip(payload.get("source_ip")) else None
        payload["destination_ip"] = payload.get("destination_ip") if _looks_like_ip(payload.get("destination_ip")) else None
        a = payload

        score, severity, priority = score_alert(a)
        now = now_iso()
        fingerprint = incident_fingerprint(a)
        lock_correlation(con, fingerprint)
        inc = find_open_incident(con, a)

        if inc:
            count = int(inc["event_count"]) + base_event_count
            threat = max(int(inc["threat_score"] or 1), derive_threat(event_type, count), int(a["threat"]))
            impact = max(int(inc["impact_score"] or 1), int(a["impact"]))
            asset_criticality = max(int(inc["asset_criticality"] or 1), int(a["asset_criticality"]))
            context = max(int(inc["context_score"] or 1), int(a["context"]))
            score, severity, priority = score_alert({
                "event_type": event_type,
                "title": a.get("title"),
                "timestamp": a.get("timestamp"),
                "events_count": count,
                "username": inc["username"] or a.get("username"),
                "asset": inc["asset"] or a.get("asset"),
                "threat": threat,
                "impact": impact,
                "asset_criticality": asset_criticality,
                "context": context,
            })

            evidence = _load_evidence(inc["evidence"])
            source_ips = set(_source_ips_from_evidence(evidence))
            if a.get("source_ip"):
                source_ips.add(str(a["source_ip"]))
            old_first = evidence.get("first_event") if isinstance(evidence.get("first_event"), dict) else None
            old_last = evidence.get("last_event") if isinstance(evidence.get("last_event"), dict) else None
            old_first_ts = event_time_iso(old_first.get("timestamp"), a["timestamp"]) if old_first else a["timestamp"]
            old_last_ts = event_time_iso(old_last.get("timestamp"), a["timestamp"]) if old_last else a["timestamp"]
            first_event = a if a["timestamp"] < old_first_ts else (old_first or a)
            last_event = a if a["timestamp"] >= old_last_ts else (old_last or a)
            evidence.update({
                "first_event": compact_event_for_evidence(first_event),
                "last_event": compact_event_for_evidence(last_event),
                "source_ips": sorted(source_ips)[:1000],
                "source_ips_truncated": len(source_ips) > 1000,
                "correlation": "5-minute window",
                "correlation_fingerprint": fingerprint,
                "correlated_event_count": count,
            })

            con.execute(
                """UPDATE incidents SET updated_at=?, title=?, source=?, source_ip=?, destination_ip=?, username=?, asset=?,
                   score=?, severity=?, priority=?, event_count=?, impact=?, recommendation=?, evidence=?,
                   fingerprint=?, threat_score=?, impact_score=?, context_score=?, asset_criticality=?, last_event_at=?,
                   rule_id=?, rule_level=?, agent_id=?, agent_name=?, manager_name=?
                   WHERE id=?""",
                (
                    now,
                    inc["title"] if inc["title"] != "Security alert" else a["title"],
                    inc["source"] or a["source"],
                    inc["source_ip"] or a.get("source_ip"),
                    inc["destination_ip"] or a.get("destination_ip"),
                    inc["username"] or a.get("username"),
                    inc["asset"] or a.get("asset"),
                    score, severity, priority, count,
                    impact_text({"impact": impact, "asset_criticality": asset_criticality}),
                    recommendation(event_type, severity), json.dumps(evidence, ensure_ascii=False),
                    fingerprint, threat, impact, context, asset_criticality,
                    max(
                        event_time_iso(inc["last_event_at"], a["timestamp"]),
                        a["timestamp"],
                    ),
                    inc["rule_id"] or a.get("rule_id"), inc["rule_level"] if inc["rule_level"] is not None else a.get("rule_level"),
                    inc["agent_id"] or a.get("agent_id"), inc["agent_name"] or a.get("agent_name"), inc["manager_name"] or a.get("manager_name"),
                    inc["id"],
                ),
            )
            incident_id = inc["id"]
        else:
            incident_id = "INC-" + datetime.now(timezone.utc).strftime("%y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:4].upper()
            evidence = {
                "first_event": compact_event_for_evidence(a),
                "last_event": compact_event_for_evidence(a),
                "source_ips": [a["source_ip"]] if a.get("source_ip") else [],
                "correlation": "5-minute window",
                "correlation_fingerprint": fingerprint,
                "correlated_event_count": base_event_count,
            }
            con.execute(
                """INSERT INTO incidents(
                    id,created_at,updated_at,title,event_type,source,source_ip,destination_ip,username,asset,
                    score,severity,priority,event_count,status,owner,owner_user_id,impact,recommendation,evidence,fingerprint,
                    threat_score,impact_score,context_score,asset_criticality,last_event_at,rule_id,rule_level,agent_id,agent_name,manager_name
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    incident_id, now, now, a["title"], event_type, a["source"], a.get("source_ip"),
                    a.get("destination_ip"), a.get("username"), a.get("asset"), score, severity, priority,
                    base_event_count, "open", None, None, impact_text(a), recommendation(event_type, severity),
                    json.dumps(evidence, ensure_ascii=False), fingerprint, int(a["threat"]), int(a["impact"]),
                    int(a["context"]), int(a["asset_criticality"]), a["timestamp"], a.get("rule_id"), a.get("rule_level"),
                    a.get("agent_id"), a.get("agent_name"), a.get("manager_name"),
                ),
            )
            con.execute(
                "INSERT INTO audit_log(incident_id,created_at,action,from_status,to_status,owner,note,actor_user_id,actor_username) VALUES(?,?,?,?,?,?,?,?,?)",
                (incident_id, now, "incident_created", None, "open", None, "Incident created by triage pipeline", None, None),
            )

        if DB_BACKEND == "postgres":
            event_row = con.execute(
                "INSERT INTO events(alert_id,incident_id,timestamp,source,event_type,payload) VALUES(?,?,?,?,?,?) RETURNING id",
                (alert_id, incident_id, a["timestamp"], a["source"], event_type, json.dumps(a, ensure_ascii=False)),
            ).fetchone()
            event_id = int(event_row["id"])
        else:
            con.execute(
                "INSERT INTO events(alert_id,incident_id,timestamp,source,event_type,payload) VALUES(?,?,?,?,?,?)",
                (alert_id, incident_id, a["timestamp"], a["source"], event_type, json.dumps(a, ensure_ascii=False)),
            )
            event_id = int(con.execute("SELECT last_insert_rowid()").fetchone()[0])

        evidence = _load_evidence(con.execute("SELECT evidence FROM incidents WHERE id=?", (incident_id,)).fetchone()[0])
        integration = {"source": a.get("source"), "rule_id": a.get("rule_id"), "rule_level": a.get("rule_level"), "agent_id": a.get("agent_id"), "agent_name": a.get("agent_name"), "manager_name": a.get("manager_name"), "mitre_ids": a.get("mitre_ids", [])}
        integrations = evidence.get("integrations", []) if isinstance(evidence.get("integrations", []), list) else []
        signature = json.dumps(integration, sort_keys=True, ensure_ascii=False, default=str)
        if not any(json.dumps(item, sort_keys=True, ensure_ascii=False, default=str) == signature for item in integrations if isinstance(item, dict)):
            integrations.append(integration)
        evidence["integrations"] = integrations[-50:]
        # Keep the latest integration context as a compatibility shortcut while preserving history above.
        evidence["integration"] = integration
        # Add the raw event id to evidence for direct traceability.
        event_ids = evidence.get("event_ids", []) if isinstance(evidence.get("event_ids", []), list) else []
        if event_id not in event_ids:
            event_ids.append(event_id)
        evidence["event_ids"] = event_ids[-100:]
        con.execute("UPDATE incidents SET evidence=? WHERE id=?", (json.dumps(evidence, ensure_ascii=False), incident_id))

        con.execute("COMMIT")
        return incident_id, event_id
    except Exception:
        try:
            con.execute("ROLLBACK")
        except Exception:
            pass
        raise
    finally:
        con.close()


def enqueue_alert(payload: dict[str, Any]) -> int:
    validated = AlertIn.model_validate(payload)
    normalized = validated.model_dump(mode="json")
    normalized["timestamp"] = event_time_iso(normalized.get("timestamp"), now_iso())
    source = str(normalized.get("source") or "unknown")[:100]
    alert_id = normalized.get("alert_id") or ("internal-" + uuid.uuid4().hex)
    normalized["alert_id"] = alert_id
    con = db()
    try:
        begin_tx(con)
        if alert_id:
            existing_event = con.execute(
                "SELECT id FROM events WHERE source=? AND alert_id=? LIMIT 1", (source, alert_id)
            ).fetchone()
            if existing_event:
                # The event was already persisted. If its original queue row is gone,
                # create a terminal deduplication record instead of reprocessing it.
                queued = con.execute(
                    "SELECT id FROM queue WHERE source=? AND alert_id=? ORDER BY id DESC LIMIT 1", (source, alert_id)
                ).fetchone()
                if queued:
                    con.execute("COMMIT")
                    return int(queued[0])
                replay_now = now_iso()
                if DB_BACKEND == "postgres":
                    replay_row = con.execute(
                        "INSERT INTO queue(alert_id,source,payload,status,attempts,created_at,finished_at,next_attempt_at,error) VALUES(?,?,?,?,?,?,?,?,?) RETURNING id",
                        (alert_id, source, json.dumps(normalized, ensure_ascii=False), "deduplicated", 0, replay_now, replay_now, None, "duplicate alert already processed"),
                    ).fetchone()
                    con.execute("COMMIT")
                    return int(replay_row["id"])
                replay_cur = con.execute(
                    "INSERT INTO queue(alert_id,source,payload,status,attempts,created_at,finished_at,next_attempt_at,error) VALUES(?,?,?,?,?,?,?,?,?)",
                    (alert_id, source, json.dumps(normalized, ensure_ascii=False), "deduplicated", 0, replay_now, replay_now, None, "duplicate alert already processed"),
                )
                replay_id = int(replay_cur.lastrowid)
                con.execute("COMMIT")
                return replay_id
            active = con.execute(
                "SELECT id FROM queue WHERE source=? AND alert_id=? AND status IN ('pending','processing') ORDER BY id LIMIT 1",
                (source, alert_id),
            ).fetchone()
            if active:
                con.execute("COMMIT")
                return int(active[0])
        if DB_BACKEND == "postgres":
            queue_row = con.execute(
                "INSERT INTO queue(alert_id,source,payload,status,attempts,created_at,next_attempt_at) VALUES(?,?,?,?,?,?,?) RETURNING id",
                (alert_id, source, json.dumps(normalized, ensure_ascii=False), "pending", 0, now_iso(), now_iso()),
            ).fetchone()
            queue_id = int(queue_row["id"])
        else:
            cur = con.execute(
                "INSERT INTO queue(alert_id,source,payload,status,attempts,created_at,next_attempt_at) VALUES(?,?,?,?,?,?,?)",
                (alert_id, source, json.dumps(normalized, ensure_ascii=False), "pending", 0, now_iso(), now_iso()),
            )
            queue_id = int(cur.lastrowid)
        con.execute("COMMIT")
        return queue_id
    except Exception as exc:
        if not is_unique_violation(exc):
            try:
                con.execute("ROLLBACK")
            finally:
                con.close()
            raise
        # Another worker/request inserted the same active alert between the read and insert.
        con.execute("ROLLBACK")
        if alert_id:
            row = con.execute(
                "SELECT id FROM queue WHERE source=? AND alert_id=? AND status IN ('pending','processing') ORDER BY id DESC LIMIT 1",
                (source, alert_id),
            ).fetchone()
            if row:
                return int(row[0])
        raise
    finally:
        try:
            con.close()
        except Exception:
            pass



def finish_queue_job(queue_id: int, claim_token: str, ok: bool, error: str | None = None) -> None:
    con = db()
    try:
        if ok:
            con.execute(
                "UPDATE queue SET status='done', finished_at=?, error=NULL, claim_token=NULL, next_attempt_at=NULL WHERE id=? AND status='processing' AND claim_token=?",
                (now_iso(), queue_id, claim_token),
            )
        else:
            row = con.execute("SELECT attempts FROM queue WHERE id=? AND status='processing' AND claim_token=?", (queue_id, claim_token)).fetchone()
            if not row:
                return
            attempts = int(row[0])
            if attempts >= QUEUE_MAX_ATTEMPTS:
                status = "failed"
                next_attempt = None
                finished_at = now_iso()
            else:
                status = "pending"
                next_attempt = datetime.fromtimestamp(
                    datetime.now(timezone.utc).timestamp() + min(60, 2 ** attempts), tz=timezone.utc
                ).isoformat()
                finished_at = None
            con.execute(
                "UPDATE queue SET status=?, finished_at=?, error=?, claim_token=NULL, next_attempt_at=? WHERE id=? AND status='processing' AND claim_token=?",
                (status, finished_at, (error or "processing error")[:1000], next_attempt, queue_id, claim_token),
            )
    finally:
        con.close()

def claim_queue_job() -> HybridRow | None:
    con = db()
    try:
        begin_tx(con)
        now = now_iso()
        stale_cutoff = datetime.fromtimestamp(datetime.now(timezone.utc).timestamp() - 120, tz=timezone.utc).isoformat()
        con.execute(
            """UPDATE queue SET status=CASE WHEN attempts >= ? THEN 'failed' ELSE 'pending' END,
               started_at=NULL, claim_token=NULL,
               finished_at=CASE WHEN attempts >= ? THEN COALESCE(finished_at, ?) ELSE finished_at END,
               next_attempt_at=CASE WHEN attempts >= ? THEN NULL ELSE ? END
               WHERE status='processing' AND started_at < ?""",
            (QUEUE_MAX_ATTEMPTS, QUEUE_MAX_ATTEMPTS, now, QUEUE_MAX_ATTEMPTS, now, stale_cutoff),
        )
        if DB_BACKEND == "postgres":
            row = con.execute(
                """SELECT * FROM queue WHERE status='pending'
                   AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
                   ORDER BY id LIMIT 1 FOR UPDATE SKIP LOCKED""",
                (now,),
            ).fetchone()
        else:
            row = con.execute(
                """SELECT * FROM queue WHERE status='pending'
                   AND (next_attempt_at IS NULL OR next_attempt_at <= ?)
                   ORDER BY id LIMIT 1""", (now,)
            ).fetchone()
        if not row:
            con.execute("COMMIT")
            return None
        claim_token = uuid.uuid4().hex
        con.execute(
            "UPDATE queue SET status='processing', attempts=attempts+1, started_at=?, error=NULL, claim_token=?, next_attempt_at=NULL WHERE id=?",
            (now, claim_token, row["id"]),
        )
        claimed = con.execute("SELECT * FROM queue WHERE id=?", (row["id"],)).fetchone()
        con.execute("COMMIT")
        return claimed
    except Exception:
        try:
            con.execute("ROLLBACK")
        except Exception:
            pass
        return None
    finally:
        try:
            con.close()
        except Exception:
            pass


async def worker_loop(worker_id: int):
    while True:
        job = await asyncio.to_thread(claim_queue_job)
        if job is None:
            try:
                await asyncio.wait_for(QUEUE_WAKE.wait(), timeout=QUEUE_POLL_SECONDS)
            except asyncio.TimeoutError:
                pass
            QUEUE_WAKE.clear()
            continue
        try:
            payload = json.loads(job["payload"])
            await asyncio.to_thread(process_alert, payload)
            await asyncio.to_thread(finish_queue_job, int(job["id"]), str(job["claim_token"]), True)
        except Exception as exc:
            await asyncio.to_thread(finish_queue_job, int(job["id"]), str(job["claim_token"]), False, str(exc))


@asynccontextmanager
async def lifespan(app: FastAPI):
    global WORKER_TASKS
    init_db()
    WORKER_TASKS = [asyncio.create_task(worker_loop(i + 1)) for i in range(WORKER_COUNT)]
    yield
    for task in WORKER_TASKS:
        task.cancel()
    if WORKER_TASKS:
        await asyncio.gather(*WORKER_TASKS, return_exceptions=True)
    WORKER_TASKS = []


app = FastAPI(title="SOC Intelligent Triage API", version=APP_VERSION, lifespan=lifespan, docs_url="/docs" if SOC_DEMO_MODE else None, redoc_url="/redoc" if SOC_DEMO_MODE else None, openapi_url="/openapi.json" if SOC_DEMO_MODE else None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=SOC_TRUSTED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-SOC-Webhook-Token", "X-Request-ID"],
)
app.middleware("http")(body_limit_middleware)


@app.post("/api/auth/login")
def auth_login(body: LoginIn, request: Request):
    ip = _client_ip(request)
    if login_rate_limited(ip):
        raise HTTPException(429, "Too many login attempts. Try again later.")
    username = normalize_username(body.username)
    con = db()
    try:
        row = con.execute("SELECT id,username,display_name,role,password_hash,active FROM users WHERE username=?", (username,)).fetchone()
        if not row:
            verify_password(body.password, DUMMY_PASSWORD_HASH)
            register_login_failure(ip)
            raise HTTPException(401, "Invalid username or password")
        if not row["active"]:
            verify_password(body.password, DUMMY_PASSWORD_HASH)
            register_login_failure(ip)
            raise HTTPException(401, "Invalid username or password")
        if not verify_password(body.password, row["password_hash"]):
            register_login_failure(ip)
            raise HTTPException(401, "Invalid username or password")
        clear_login_failures(ip)
        con.execute("DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL", (now_iso(),))
        token = create_session(con, row["id"], request)
        con.execute("INSERT INTO auth_audit(user_id,username,created_at,action,note) VALUES(?,?,?,?,?)", (row["id"],row["username"],now_iso(),"login",f"ip={ip}"))
        return {"access_token": token, "token_type": "bearer", "expires_in": SESSION_TTL_SECONDS, "user": {"id":row["id"],"username":row["username"],"display_name":row["display_name"],"role":row["role"]}}
    finally:
        con.close()


@app.get("/api/auth/me")
def auth_me(current_user: dict[str, Any] = Depends(require_auth)):
    return {"user": current_user}


@app.post("/api/auth/logout")
def auth_logout(authorization: str | None = Header(default=None, alias="Authorization"), current_user: dict[str, Any] = Depends(require_auth)):
    token = (authorization or "")[7:].strip()
    con = db()
    try:
        con.execute("UPDATE sessions SET revoked_at=? WHERE token_hash=?", (now_iso(), hash_token(token)))
        con.execute("INSERT INTO auth_audit(user_id,username,created_at,action,note) VALUES(?,?,?,?,?)", (current_user["id"],current_user["username"],now_iso(),"logout",None))
        return {"ok": True}
    finally:
        con.close()


@app.post("/api/auth/password")
def auth_password(body: PasswordChangeIn, current_user: dict[str, Any] = Depends(require_auth)):
    password_policy(body.new_password)
    con = db()
    try:
        begin_tx(con)
        row = con.execute("SELECT password_hash FROM users WHERE id=?", (current_user["id"],)).fetchone()
        if not row or not verify_password(body.current_password, row["password_hash"]):
            con.execute("ROLLBACK")
            raise HTTPException(400, "Current password is invalid")
        if body.current_password == body.new_password:
            con.execute("ROLLBACK")
            raise HTTPException(400, "New password must be different")
        con.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?", (hash_password(body.new_password),now_iso(),current_user["id"]))
        con.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL", (now_iso(),current_user["id"]))
        audit_auth_action(con,current_user,"password_change")
        con.execute("COMMIT")
        return {"ok": True, "message":"Password changed. Please sign in again."}
    except HTTPException:
        raise
    except Exception:
        try: con.execute("ROLLBACK")
        except Exception: pass
        raise
    finally:
        con.close()


@app.get("/api/users")
def list_users(current_user: dict[str, Any] = Depends(require_auth)):
    require_role(current_user,"admin")
    con=db()
    try:
        rows=con.execute("SELECT id,username,display_name,role,active,created_at,updated_at FROM users ORDER BY username").fetchall()
        return {"items":[dict(r) for r in rows]}
    finally:
        con.close()


@app.post("/api/users")
def create_user(body: UserCreateIn, current_user: dict[str, Any] = Depends(require_auth)):
    require_role(current_user,"admin")
    username=normalize_username(body.username)
    if body.role not in ROLE_ORDER:
        raise HTTPException(400,"Invalid role")
    password_policy(body.password)
    if username in {"unknown","null"}:
        raise HTTPException(400,"Invalid username")
    con=db()
    try:
        begin_tx(con)
        if con.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
            con.execute("ROLLBACK")
            raise HTTPException(409,"Username already exists")
        now=now_iso(); uid=uuid.uuid4().hex
        con.execute("INSERT INTO users(id,username,display_name,role,password_hash,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)", (uid,username,body.display_name.strip(),body.role,hash_password(body.password),1,now,now))
        audit_auth_action(con,current_user,"user_created",f"created_user={username};role={body.role}")
        con.execute("COMMIT")
        return {"ok":True,"user":{"id":uid,"username":username,"display_name":body.display_name.strip(),"role":body.role,"active":True}}
    except HTTPException:
        raise
    except Exception as exc:
        try: con.execute("ROLLBACK")
        except Exception: pass
        if is_unique_violation(exc):
            raise HTTPException(409,"Username already exists")
        raise
    finally:
        con.close()


@app.patch("/api/users/{user_id}")
def update_user(user_id: str, body: UserUpdateIn, current_user: dict[str, Any] = Depends(require_auth)):
    require_role(current_user,"admin")
    con=db()
    try:
        begin_tx(con)
        select_sql = "SELECT * FROM users WHERE id=?" + (" FOR UPDATE" if DB_BACKEND == "postgres" else "")
        row=con.execute(select_sql,(user_id,)).fetchone()
        if not row:
            con.execute("ROLLBACK")
            raise HTTPException(404,"User not found")
        if body.role is not None and body.role not in ROLE_ORDER:
            con.execute("ROLLBACK"); raise HTTPException(400,"Invalid role")
        active = row["active"] if body.active is None else int(body.active)
        role = body.role or row["role"]
        name = body.display_name.strip() if body.display_name is not None else row["display_name"]
        if user_id == current_user["id"] and active == 0:
            con.execute("ROLLBACK"); raise HTTPException(400,"You cannot deactivate your own account")
        if user_id == current_user["id"] and role != "admin":
            con.execute("ROLLBACK"); raise HTTPException(400,"You cannot remove your own admin role")
        if row["role"] == "admin" and (role != "admin" or active == 0):
            if DB_BACKEND == "postgres":
                active_admins = len(con.execute("SELECT id FROM users WHERE role='admin' AND active=1 FOR UPDATE").fetchall())
            else:
                active_admins = int(con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0])
            if active_admins <= 1:
                con.execute("ROLLBACK"); raise HTTPException(400,"At least one active administrator is required")
        if not name:
            con.execute("ROLLBACK"); raise HTTPException(400,"Display name cannot be empty")
        con.execute("UPDATE users SET display_name=?,role=?,active=?,updated_at=? WHERE id=?",(name,role,active,now_iso(),user_id))
        if active == 0 or role != row["role"]:
            con.execute("UPDATE sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",(now_iso(),user_id))
        audit_auth_action(con,current_user,"user_updated",f"target={row['username']}")
        con.execute("COMMIT")
        return {"ok":True,"user":{"id":user_id,"username":row["username"],"display_name":name,"role":role,"active":bool(active)}}
    except HTTPException:
        raise
    except Exception:
        try: con.execute("ROLLBACK")
        except Exception: pass
        raise
    finally:
        con.close()


@app.get("/api/health")
def health():
    # Public liveness endpoint: keep operational details out of unauthenticated responses.
    return {"status": "online", "service": "soc-intelligent-triage", "version": APP_VERSION, "environment": SOC_ENV, "demo_mode": SOC_DEMO_MODE}


@app.get("/api/health/details")
def health_details(current_user: dict[str, Any] = Depends(require_auth)):
    con = db()
    try:
        row = con.execute(
            "SELECT SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending, SUM(CASE WHEN status='processing' THEN 1 ELSE 0 END) processing, SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed FROM queue"
        ).fetchone()
        return {
            "status": "online",
            "service": "soc-intelligent-triage",
            "queue_size": int(row[0] or 0),
            "queue_processing": int(row[1] or 0),
            "queue_failed": int(row[2] or 0),
            "workers": WORKER_COUNT,
            "workers_alive": sum(1 for task in WORKER_TASKS if not task.done()),
            "workers_ready": bool(WORKER_TASKS) and all(not task.done() for task in WORKER_TASKS),
            "version": APP_VERSION,
            "environment": SOC_ENV,
            "database": DB_BACKEND,
            "wazuh_webhook": {"enabled": True, "token_required": bool(WAZUH_WEBHOOK_TOKEN)},
            "max_body_bytes": MAX_BODY_BYTES,
        }
    finally:
        con.close()


@app.get("/api/ready")
def ready():
    con = db()
    try:
        con.execute("SELECT 1").fetchone()
    finally:
        con.close()
    alive = sum(1 for task in WORKER_TASKS if not task.done())
    if not WORKER_TASKS or alive != WORKER_COUNT:
        raise HTTPException(503, "Workers are not ready")
    return {"status": "ready", "version": APP_VERSION}


@app.post("/api/webhooks/wazuh", response_model=AlertResponse, status_code=202)
async def wazuh_webhook(raw: dict[str, Any], x_soc_webhook_token: str | None = Header(default=None, alias="X-SOC-Webhook-Token")):
    require_wazuh_token(x_soc_webhook_token)
    try:
        normalized = normalize_wazuh_alert(raw)
        queue_id = enqueue_alert(normalized)
    except (ValidationError, ValueError) as exc:
        raise HTTPException(422, "Invalid Wazuh alert payload") from exc
    QUEUE_WAKE.set()
    return AlertResponse(accepted=True, message="Wazuh alert queued for processing", queue_id=queue_id)


@app.post("/api/webhooks/wazuh/sync", response_model=AlertResponse)
async def wazuh_webhook_sync(raw: dict[str, Any], x_soc_webhook_token: str | None = Header(default=None, alias="X-SOC-Webhook-Token")):
    require_wazuh_token(x_soc_webhook_token)
    try:
        normalized = normalize_wazuh_alert(raw)
        incident_id, event_id = await asyncio.to_thread(process_alert, normalized)
    except (ValidationError, ValueError) as exc:
        raise HTTPException(422, "Invalid Wazuh alert payload") from exc
    return AlertResponse(accepted=True, message="Wazuh alert processed", event_id=event_id, incident_id=incident_id)


@app.post("/api/alerts/batch")
async def ingest_batch(alerts_in: list[AlertIn] = Body(default_factory=list, max_length=100), current_user: dict[str, Any] = Depends(require_auth)):
    if len(alerts_in) > 100:
        raise HTTPException(413, "Batch limit is 100 alerts")
    queue_ids = []
    for alert in alerts_in:
        payload = alert.model_dump(mode="json")
        payload["timestamp"] = payload["timestamp"] or now_iso()
        queue_ids.append(enqueue_alert(payload))
    if queue_ids:
        QUEUE_WAKE.set()
    return {"accepted": True, "queued": len(queue_ids), "queue_ids": queue_ids}


@app.post("/api/alerts", response_model=AlertResponse, status_code=202)
async def ingest(alert: AlertIn, current_user: dict[str, Any] = Depends(require_auth)):
    payload = alert.model_dump(mode="json")
    payload["timestamp"] = payload["timestamp"] or now_iso()
    queue_id = enqueue_alert(payload)
    QUEUE_WAKE.set()
    return AlertResponse(accepted=True, message="Alert queued for processing", queue_id=queue_id)


@app.post("/api/alerts/sync", response_model=AlertResponse)
async def ingest_sync(alert: AlertIn, current_user: dict[str, Any] = Depends(require_auth)):
    payload = alert.model_dump(mode="json")
    payload["timestamp"] = payload["timestamp"] or now_iso()
    incident_id, event_id = await asyncio.to_thread(process_alert, payload)
    return AlertResponse(accepted=True, message="Alert processed", event_id=event_id, incident_id=incident_id)


def escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


@app.get("/api/incidents")
def incidents(
    status: str | None = Query(None, max_length=30),
    severity: str | None = Query(None, max_length=20),
    q: str | None = Query(None, max_length=120),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0, le=1_000_000),
    current_user: dict[str, Any] = Depends(require_auth),
):
    con = db()
    try:
        clauses = ["1=1"]
        params: list[Any] = []
        if status:
            clauses.append("status=?")
            params.append(status)
        if severity:
            clauses.append("severity=?")
            params.append(severity)
        if q:
            clauses.append("(id LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' OR event_type LIKE ? ESCAPE '\\' OR source LIKE ? ESCAPE '\\' OR source_ip LIKE ? ESCAPE '\\' OR destination_ip LIKE ? ESCAPE '\\' OR username LIKE ? ESCAPE '\\' OR asset LIKE ? ESCAPE '\\' OR EXISTS (SELECT 1 FROM events e WHERE e.incident_id=incidents.id AND e.alert_id LIKE ? ESCAPE '\\'))")
            x = f"%{escape_like(q)}%"
            params += [x, x, x, x, x, x, x, x, x]
        where = " AND ".join(clauses)
        total = int(con.execute(f"SELECT COUNT(*) FROM incidents WHERE {where}", params).fetchone()[0])
        rows = [dict(r) for r in con.execute(
            f"SELECT * FROM incidents WHERE {where} ORDER BY priority ASC, score DESC, updated_at DESC LIMIT ? OFFSET ?",
            params + [limit, offset],
        ).fetchall()]
        return {"items": rows, "total": total, "limit": limit, "offset": offset, "has_more": offset + len(rows) < total}
    finally:
        con.close()


@app.get("/api/incidents/{incident_id}")
def incident(
    incident_id: str,
    event_limit: int = Query(200, ge=1, le=500),
    event_offset: int = Query(0, ge=0, le=1_000_000),
    audit_limit: int = Query(200, ge=1, le=500),
    audit_offset: int = Query(0, ge=0, le=1_000_000),
    current_user: dict[str, Any] = Depends(require_auth),
):
    if not 1 <= len(incident_id) <= 120:
        raise HTTPException(422, "Invalid incident id")
    con = db()
    try:
        row = con.execute("SELECT * FROM incidents WHERE id=?", (incident_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Incident not found")
        events_total = int(con.execute("SELECT COUNT(*) FROM events WHERE incident_id=?", (incident_id,)).fetchone()[0])
        audit_total = int(con.execute("SELECT COUNT(*) FROM audit_log WHERE incident_id=?", (incident_id,)).fetchone()[0])
        events = [dict(r) for r in con.execute(
            ("SELECT * FROM events WHERE incident_id=? ORDER BY julianday(timestamp) ASC, id ASC LIMIT ? OFFSET ?" if DB_BACKEND == "sqlite" else "SELECT * FROM events WHERE incident_id=? ORDER BY timestamp ASC, id ASC LIMIT ? OFFSET ?"),
            (incident_id, event_limit, event_offset),
        ).fetchall()]
        audit = [dict(r) for r in con.execute(
            "SELECT * FROM audit_log WHERE incident_id=? ORDER BY created_at ASC, id ASC LIMIT ? OFFSET ?",
            (incident_id, audit_limit, audit_offset),
        ).fetchall()]
        result = dict(row)
        result["events"] = events
        result["events_pagination"] = {"total": events_total, "limit": event_limit, "offset": event_offset, "has_more": event_offset + len(events) < events_total}
        result["audit"] = audit
        result["audit_pagination"] = {"total": audit_total, "limit": audit_limit, "offset": audit_offset, "has_more": audit_offset + len(audit) < audit_total}
        result["evidence"] = _load_evidence(result.get("evidence"))
        return result
    finally:
        con.close()


@app.patch("/api/incidents/{incident_id}/status")
def update_status(incident_id: str, body: StatusIn, current_user: dict[str, Any] = Depends(require_auth)):
    allowed = {"open", "investigating", "resolved", "escalated", "false_positive"}
    if body.status not in allowed:
        raise HTTPException(400, "Invalid status")
    if body.status == "escalated":
        require_role(current_user, "supervisor")
    con = db()
    try:
        begin_tx(con)
        select_sql = "SELECT status, owner, owner_user_id, score FROM incidents WHERE id=?" + (" FOR UPDATE" if DB_BACKEND == "postgres" else "")
        row = con.execute(select_sql, (incident_id,)).fetchone()
        if not row:
            con.execute("ROLLBACK")
            raise HTTPException(404, "Incident not found")
        if body.status == "resolved" and int(row["score"] or 0) >= 10 and len((body.note or "").strip()) < 10:
            con.execute("ROLLBACK")
            raise HTTPException(400, "Score 10 incidents require a containment action note (at least 10 characters) before resolution")
        now = now_iso()
        owner_user_id_provided = "owner_user_id" in body.model_fields_set
        owner_provided = "owner" in body.model_fields_set
        new_owner_user_id = body.owner_user_id if owner_user_id_provided else row["owner_user_id"]
        if new_owner_user_id:
            owner_row = con.execute("SELECT id, display_name, active FROM users WHERE id=?", (new_owner_user_id,)).fetchone()
            if not owner_row or not owner_row["active"]:
                con.execute("ROLLBACK")
                raise HTTPException(400, "Owner user is not active or does not exist")
            if owner_row["id"] != current_user["id"] and ROLE_ORDER.get(str(current_user.get("role")), 0) < ROLE_ORDER["supervisor"]:
                con.execute("ROLLBACK")
                raise HTTPException(403, "Only supervisors or administrators can assign another user")
            new_owner = owner_row["display_name"]
        elif owner_provided and body.owner:
            owner_text = body.owner.strip()
            owner_row = con.execute(
                "SELECT id, display_name, username, active FROM users WHERE active=1 AND (display_name=? OR username=?) LIMIT 1",
                (owner_text, normalize_username(owner_text)),
            ).fetchone()
            if not owner_row:
                con.execute("ROLLBACK")
                raise HTTPException(400, "Owner must reference an active user")
            if owner_row["id"] != current_user["id"] and ROLE_ORDER.get(str(current_user.get("role")), 0) < ROLE_ORDER["supervisor"]:
                con.execute("ROLLBACK")
                raise HTTPException(403, "Only supervisors or administrators can assign another user")
            new_owner_user_id = owner_row["id"]
            new_owner = owner_row["display_name"]
        else:
            new_owner = row["owner"]
        if body.status == "investigating" and not new_owner:
            new_owner_user_id = current_user["id"]
            new_owner = current_user["display_name"]
        con.execute(
            "UPDATE incidents SET status=?, owner=?, owner_user_id=?, updated_at=? WHERE id=?",
            (body.status, new_owner, new_owner_user_id, now, incident_id),
        )
        con.execute(
            "INSERT INTO audit_log(incident_id,created_at,action,from_status,to_status,owner,note,actor_user_id,actor_username) VALUES(?,?,?,?,?,?,?,?,?)",
            (incident_id, now, "status_change", row["status"], body.status, new_owner, body.note, current_user["id"], current_user["username"]),
        )
        con.execute("COMMIT")
        return {"ok": True, "id": incident_id, "status": body.status, "owner": new_owner}
    except HTTPException:
        raise
    except Exception:
        try:
            con.execute("ROLLBACK")
        finally:
            con.close()
        raise
    finally:
        try:
            con.close()
        except Exception:
            pass


@app.get("/api/metrics")
def metrics(current_user: dict[str, Any] = Depends(require_auth)):
    con = db()
    try:
        rows = con.execute("SELECT severity, COUNT(*) c FROM incidents GROUP BY severity").fetchall()
        active_rows = con.execute("SELECT severity, COUNT(*) c FROM incidents WHERE status NOT IN ('resolved','false_positive') GROUP BY severity").fetchall()
        statuses = con.execute("SELECT status, COUNT(*) c FROM incidents GROUP BY status").fetchall()
        queue = con.execute("SELECT status, COUNT(*) c FROM queue GROUP BY status").fetchall()
        total_incidents = int(con.execute("SELECT COUNT(*) FROM incidents").fetchone()[0])
        active_incidents = int(con.execute("SELECT COUNT(*) FROM incidents WHERE status NOT IN ('resolved','false_positive')").fetchone()[0])
        total_ingestions = int(con.execute("SELECT COUNT(*) FROM events").fetchone()[0])
        total_consolidated_events = int(con.execute("SELECT COALESCE(SUM(event_count),0) FROM incidents").fetchone()[0])
        correlation_reduction = round((1 - total_incidents / max(1, total_ingestions)) * 100, 1)

        op_rows = con.execute(
            """SELECT i.id, i.created_at,
                      MIN(CASE WHEN a.to_status='investigating' THEN a.created_at END) AS first_investigating_at,
                      MIN(CASE WHEN a.to_status='resolved' THEN a.created_at END) AS first_resolved_at
                 FROM incidents i LEFT JOIN audit_log a ON a.incident_id=i.id
                 GROUP BY i.id, i.created_at"""
        ).fetchall()
        mtta_values: list[float] = []
        mttr_values: list[float] = []
        for row in op_rows:
            try:
                created = datetime.fromisoformat(str(row["created_at"]))
                if row["first_investigating_at"]:
                    mtta_values.append(max(0.0, (datetime.fromisoformat(str(row["first_investigating_at"])) - created).total_seconds()))
                if row["first_resolved_at"]:
                    mttr_values.append(max(0.0, (datetime.fromisoformat(str(row["first_resolved_at"])) - created).total_seconds()))
            except (TypeError, ValueError):
                continue

        queue_rows = con.execute(
            "SELECT started_at, finished_at FROM queue WHERE status='done' AND started_at IS NOT NULL AND finished_at IS NOT NULL ORDER BY id DESC LIMIT 5000"
        ).fetchall()
        queue_latency: list[float] = []
        for row in queue_rows:
            try:
                started = datetime.fromisoformat(str(row["started_at"]))
                finished = datetime.fromisoformat(str(row["finished_at"]))
                queue_latency.append(max(0.0, (finished - started).total_seconds()))
            except (TypeError, ValueError):
                continue

        return {
            "total_incidents": total_incidents,
            "active_incidents": active_incidents,
            "total_event_ingestions": total_ingestions,
            "total_consolidated_events": total_consolidated_events,
            "correlation_reduction_percent": max(0.0, correlation_reduction),
            "by_severity": {r[0]: int(r[1]) for r in rows},
            "by_active_severity": {r[0]: int(r[1]) for r in active_rows},
            "by_status": {r[0]: int(r[1]) for r in statuses},
            "queue": {r[0]: int(r[1]) for r in queue},
            "operations": {
                "mtta_seconds_avg": round(sum(mtta_values) / len(mtta_values), 2) if mtta_values else None,
                "mttr_seconds_avg": round(sum(mttr_values) / len(mttr_values), 2) if mttr_values else None,
                "queue_processing_seconds_avg": round(sum(queue_latency) / len(queue_latency), 3) if queue_latency else None,
            },
        }
    finally:
        con.close()


app.mount("/", StaticFiles(directory=str(BASE.parent / "frontend"), html=True), name="frontend")

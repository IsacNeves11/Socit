"""Verify that a processed alert replay never enters the worker again."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import main

main.DB_PATH = Path(tempfile.mkdtemp(prefix="soc-replay-") ) / "soc.db"
main.WORKER_TASKS = []
main.init_db()

payload = {
    "alert_id": "REPLAY-001",
    "source": "wazuh",
    "event_type": "brute_force",
    "source_ip": "198.51.100.10",
    "username": "admin",
    "asset": "srv-01",
    "events_count": 3,
    "asset_criticality": 5,
    "threat": 5,
    "impact": 5,
    "context": 5,
}
qid = main.enqueue_alert(payload)
job = main.claim_queue_job()
assert job and int(job["id"]) == qid
raw = json.loads(job["payload"])
main.process_alert(raw)
main.finish_queue_job(qid, str(job["claim_token"]), True)

con = main.db()
con.execute("DELETE FROM queue WHERE id=?", (qid,))
con.close()
replay_qid = main.enqueue_alert(payload)
assert replay_qid != qid
con = main.db()
row = con.execute("SELECT status,error FROM queue WHERE id=?", (replay_qid,)).fetchone()
con.close()
assert row["status"] == "deduplicated"
assert row["error"] == "duplicate alert already processed"
print("REPLAY_IDEMPOTENCY_OK")

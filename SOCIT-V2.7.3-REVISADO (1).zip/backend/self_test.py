import asyncio
import time
import json
import tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import main


def reset_db():
    tmp = Path(tempfile.mkdtemp(prefix="soc-v23-test-")) / "soc.db"
    main.DB_PATH = tmp
    main.init_db()
    return tmp


def test_normalization_and_score():
    a = main.AlertIn(
        alert_id="TEST-001",
        source="192.168.1.50",
        target="srv-ad-01",
        user="admin",
        threat_type="brute_force",
        events_count=47,
        asset_criticality=5,
        business_impact=5,
        context_score=5,
        description="47 tentativas de login contra conta administrativa",
    )
    payload=a.model_dump(mode="json")
    incident_id,event_id=main.process_alert(payload)
    con=main.db()
    row=con.execute("SELECT * FROM incidents WHERE id=?",(incident_id,)).fetchone()
    assert row["event_type"]=="brute_force"
    assert row["source_ip"]=="192.168.1.50"
    assert row["username"]=="admin"
    assert row["asset"]=="srv-ad-01"
    assert row["event_count"]==47
    assert row["score"]==9 and row["severity"]=="critical" and row["priority"]==1
    assert event_id is not None
    con.close()
    return incident_id


def test_correlation_and_dedupe(incident_id):
    common=dict(event_type="brute_force",username="admin",asset="srv-ad-01",asset_criticality=5,threat=5,impact=5,context=5)
    i2,e2=main.process_alert({**common,"source":"wazuh","source_ip":"192.168.1.51","alert_id":"TWO","events_count":4})
    assert i2==incident_id
    assert e2
    i3,e3=main.process_alert({**common,"source":"wazuh","source_ip":"192.168.1.51","alert_id":"TWO","events_count":4})
    assert i3==incident_id and e3==e2
    con=main.db()
    row=con.execute("SELECT * FROM incidents WHERE id=?",(incident_id,)).fetchone()
    assert row["event_count"]==51
    ev=con.execute("SELECT COUNT(*) FROM events WHERE incident_id=?",(incident_id,)).fetchone()[0]
    assert ev==2
    assert len(json.loads(row["evidence"])["source_ips"])==2
    con.close()


def test_event_isolation():
    a={"source":"wazuh","title":"Malware alert","event_type":"malware","asset":"ws-01","username":"u1","asset_criticality":4,"threat":5,"impact":4,"context":4}
    b={"source":"wazuh","title":"Malware alert","event_type":"malware","asset":"ws-02","username":"u1","asset_criticality":4,"threat":5,"impact":4,"context":4}
    ia,_=main.process_alert(a)
    ib,_=main.process_alert(b)
    assert ia!=ib


def test_durable_queue():
    payload={"source":"queue-test","event_type":"port_scan","source_ip":"10.0.0.8","asset":"web-01","asset_criticality":3,"threat":3,"impact":3,"context":3}
    qid=main.enqueue_alert(payload)
    row=main.claim_queue_job()
    assert row is not None and int(row["id"])==qid and row["status"]=="processing"
    main.finish_queue_job(qid, str(row["claim_token"]), True)
    con=main.db(); status=con.execute("SELECT status FROM queue WHERE id=?",(qid,)).fetchone()[0]; con.close()
    assert status=="done"



def test_metrics_semantics_and_internal_id():
    tmp=reset_db()
    q=main.enqueue_alert({"source":"unit","event_type":"brute_force","username":"admin","asset":"srv-1","threat":5,"impact":5,"context":5,"asset_criticality":5})
    con=main.db(); row=con.execute("SELECT alert_id,payload FROM queue WHERE id=?",(q,)).fetchone(); con.close()
    assert row[0].startswith("internal-")
    payload=json.loads(row[1]); assert payload["alert_id"].startswith("internal-")
    main.process_alert(payload)
    m=main.metrics()
    assert m["total_event_ingestions"]==1 and m["total_incidents"]==1 and m["correlation_reduction_percent"]==0.0
    return tmp

if __name__=="__main__":
    reset_db()
    # Re-running bootstrap must be idempotent.
    con=main.db()
    main.seed_default_users(con)
    main.seed_default_users(con)
    con.close()
    inc=test_normalization_and_score()
    test_correlation_and_dedupe(inc)
    test_event_isolation()
    test_durable_queue()
    test_metrics_semantics_and_internal_id()

    # API smoke test with the real lifespan/worker.
    from fastapi.testclient import TestClient
    with TestClient(main.app) as client:
        login=client.post("/api/auth/login",json={"username":"analyst","password":"Analyst@123456"})
        assert login.status_code==200
        auth={"Authorization":f"Bearer {login.json()['access_token']}"}
        r=client.post("/api/alerts",json={
            "alert_id":"ASYNC-001","source":"wazuh","threat_type":"brute_force",
            "source_ip":"10.10.10.10","user":"admin","target":"srv-async",
            "events_count":12,"asset_criticality":5,"business_impact":5,"context_score":5
        },headers=auth)
        assert r.status_code==202 and r.json()["queue_id"]
        for _ in range(30):
            data=client.get("/api/incidents?q=ASYNC-001",headers=auth).json()
            if data["total"]:
                break
            time.sleep(0.05)
        assert data["total"]==1
        iid=data["items"][0]["id"]
        me=client.get("/api/auth/me",headers=auth).json()["user"]
        r=client.patch(f"/api/incidents/{iid}/status",json={"status":"investigating","owner_user_id":me["id"],"note":"Início da análise"},headers=auth)
        assert r.status_code==200
        detail=client.get(f"/api/incidents/{iid}",headers=auth).json()
        assert detail["audit"] and detail["audit"][-1]["to_status"]=="investigating"
        assert detail["owner_user_id"] == me["id"]
        metrics=client.get("/api/metrics",headers=auth).json()
        assert metrics["total_event_ingestions"]>=1
        assert client.get("/api/health").json()["version"]=="2.7.3"
    from concurrent.futures import ThreadPoolExecutor
    results=[]
    concurrent_base={"source":"wazuh","title":"Concurrent brute force","event_type":"brute_force","username":"admin","asset":"srv-concurrent","asset_criticality":5,"threat":5,"impact":5,"context":5}
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(main.process_alert,{**concurrent_base,"source_ip":f"10.20.0.{i}","alert_id":f"CONC-{i}"}) for i in range(30)]
        results=[f.result()[0] for f in futures]
    assert len(set(results))==1
    con=main.db(); count=con.execute("SELECT event_count FROM incidents WHERE id=?",(results[0],)).fetchone()[0]; con.close()
    assert count==30
    print("SELF_TEST_OK")

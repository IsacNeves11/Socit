import json
import os
import urllib.request

PORT = os.getenv("SOC_PORT", "8000")
BASE_URL = os.getenv("SOC_API_BASE_URL", f"http://127.0.0.1:{PORT}/api")

alerts = [
 {"alert_id":"seed-001","source":"wazuh-sim","event_type":"brute_force","title":"Brute force against administrative account","source_ip":"203.0.113.44","username":"admin","asset":"srv-auth-01","asset_criticality":5,"threat":5,"impact":5,"context":4},
 {"alert_id":"seed-002","source":"wazuh-sim","event_type":"malicious_ip","title":"Communication with known malicious IP","source_ip":"198.51.100.20","asset":"ws-finance-07","asset_criticality":4,"threat":5,"impact":4,"context":4},
 {"alert_id":"seed-003","source":"wazuh-sim","event_type":"malware","title":"Malware detected on endpoint","asset":"ws-executive-02","asset_criticality":4,"threat":4,"impact":4,"context":3},
 {"alert_id":"seed-004","source":"wazuh-sim","event_type":"anomalous_login","title":"Anomalous login outside normal hours","source_ip":"203.0.113.71","username":"user01","asset":"vpn-gateway","asset_criticality":3,"threat":3,"impact":3,"context":3},
 {"alert_id":"seed-005","source":"wazuh-sim","event_type":"port_scan","title":"Port scan against internal asset","source_ip":"203.0.113.88","asset":"web-01","asset_criticality":2,"threat":2,"impact":2,"context":2},
]
for a in alerts:
    req=urllib.request.Request(BASE_URL + '/alerts/sync',data=json.dumps(a).encode(),headers={'Content-Type':'application/json'},method='POST')
    print(urllib.request.urlopen(req, timeout=10).read().decode())

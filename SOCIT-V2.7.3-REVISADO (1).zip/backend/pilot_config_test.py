"""Offline pilot-readiness checks that do not require Docker/PostgreSQL."""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def run_import_with_env(env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    code = "import backend.main as m; m.init_db(); print(m.DB_BACKEND, m.SOC_ENV, m.app.docs_url, m.app.openapi_url)"
    e = os.environ.copy()
    e.update(env)
    return subprocess.run([PY, "-c", code], cwd=ROOT, env=e, text=True, capture_output=True, timeout=20)


def test_pilot_rejects_sqlite():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "pilot.db"
        r = run_import_with_env({
            "SOC_ENV": "pilot",
            "SOC_DB_URL": f"sqlite:///{p.as_posix()}",
            "SOC_WAZUH_WEBHOOK_TOKEN": "long-token-for-test",
            "SOC_TRUSTED_ORIGINS": "https://soc.example.com",
            "SOC_ADMIN_PASSWORD": "Admin-Pilot-Strong-2026!",
            "SOC_SUPERVISOR_PASSWORD": "Supervisor-Pilot-Strong-2026!",
            "SOC_ANALYST_PASSWORD": "Analyst-Pilot-Strong-2026!",
        })
        assert r.returncode != 0
        assert "requires SOC_DB_URL pointing to PostgreSQL" in (r.stderr + r.stdout) or "non-placeholder" in (r.stderr + r.stdout)


def test_demo_keeps_docs():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "demo.db"
        r = run_import_with_env({
            "SOC_ENV": "demo",
            "SOC_DEMO_MODE": "1",
            "SOC_DB_PATH": str(p),
        })
        assert r.returncode == 0, r.stderr
        assert "sqlite demo None /openapi.json" not in r.stdout
        assert " /openapi.json" in r.stdout or "/openapi.json" in r.stdout



def test_production_rejects_insecure_and_example_config():
    with tempfile.TemporaryDirectory() as td:
        # Deliberately use a placeholder token/origin and an example DB URL.
        r = run_import_with_env({
            "SOC_ENV": "production",
            "SOC_DB_URL": "postgresql://soc:CHANGE-ME@db:5432/soc",
            "SOC_WAZUH_WEBHOOK_TOKEN": "CHANGE-ME-LONG-RANDOM-TOKEN",
            "SOC_TRUSTED_ORIGINS": "https://soc.example.com",
            "SOC_REQUIRE_HTTPS": "0",
            "SOC_ADMIN_PASSWORD": "CHANGE-ME-Admin-Strong-2026!",
            "SOC_SUPERVISOR_PASSWORD": "CHANGE-ME-Supervisor-Strong-2026!",
            "SOC_ANALYST_PASSWORD": "CHANGE-ME-Analyst-Strong-2026!",
        })
        assert r.returncode != 0
        combined = r.stderr + r.stdout
        assert "non-placeholder" in combined or "requires SOC_REQUIRE_HTTPS=1" in combined


def test_db_compat_and_expected_files():
    sys.path.insert(0, str(ROOT / "backend"))
    from db_compat import translate_qmarks
    assert translate_qmarks("SELECT * FROM x WHERE a=? AND b=?") == "SELECT * FROM x WHERE a=%s AND b=%s"
    for rel in ["Dockerfile", "compose.yaml", ".env.example", "SECURITY.md", "PILOT_ACCEPTANCE.md", "deploy/backup.ps1", "deploy/restore.ps1"]:
        assert (ROOT / rel).exists(), rel


if __name__ == "__main__":
    test_pilot_rejects_sqlite()
    test_demo_keeps_docs()
    test_production_rejects_insecure_and_example_config()
    test_db_compat_and_expected_files()
    print("PILOT_CONFIG_OK")

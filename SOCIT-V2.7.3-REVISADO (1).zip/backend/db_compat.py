"""Small DB-API compatibility layer for SQLite and PostgreSQL.

The application keeps parameterized SQL with ``?`` placeholders so the
same business logic can run locally on SQLite and in a pilot on PostgreSQL.
PostgreSQL support requires ``psycopg[binary]`` at runtime.
"""
from __future__ import annotations

from typing import Any, Iterable

import sqlite3


class HybridRow(dict):
    """Mapping row that also supports the tuple-style row[0] access used by legacy code."""

    def __getitem__(self, key: Any) -> Any:  # type: ignore[override]
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


def hybrid_row_factory(cursor):
    fields = [col.name if hasattr(col, "name") else col[0] for col in cursor.description]

    def make_row(values: Iterable[Any]) -> HybridRow:
        return HybridRow(zip(fields, values))

    return make_row


def translate_qmarks(sql: str) -> str:
    """Translate the simple qmark placeholders used by the app to psycopg's %s."""
    return sql.replace("?", "%s")


class DBConnection:
    def __init__(self, raw: Any, backend: str):
        self.raw = raw
        self.backend = backend

    def execute(self, sql: str, params: tuple | list | None = None):
        if self.backend == "postgres":
            return self.raw.execute(translate_qmarks(sql), params or ())
        return self.raw.execute(sql, params or ())

    def executescript(self, script: str) -> None:
        if self.backend == "sqlite":
            self.raw.executescript(script)
            return
        # Pilot schema statements are simple CREATE/ALTER/CREATE INDEX commands.
        statements = [part.strip() for part in script.split(";") if part.strip()]
        for statement in statements:
            self.execute(statement)

    def commit(self) -> None:
        self.raw.commit()

    def rollback(self) -> None:
        self.raw.rollback()

    def close(self) -> None:
        self.raw.close()


def sqlite_integrity_error(exc: Exception) -> bool:
    return isinstance(exc, sqlite3.IntegrityError)


def is_unique_violation(exc: Exception) -> bool:
    if isinstance(exc, sqlite3.IntegrityError):
        message = str(exc).lower()
        return "unique constraint failed" in message or "unique" in message
    return getattr(exc, "sqlstate", None) == "23505"

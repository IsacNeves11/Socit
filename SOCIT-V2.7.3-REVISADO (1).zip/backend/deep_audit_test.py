import concurrent.futures
import importlib
import json
import os
import sys
import tempfile
from pathlib import Path

from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

ENV_KEYS = [
    "SOC_DEMO_MODE", "SOC_DB_PATH", "SOC_WAZUH_WEBHOOK_TOKEN",
    "SOC_ADMIN_PASSWORD", "SOC_SUPERVISOR_PASSWORD", "SOC_ANALYST_PASSWORD",
    "SOC_MAX_BODY_BYTES",
]


def fresh(env):
    for key in ENV_KEYS:
        os.environ.pop(key, None)
    os.environ.update(env)
    if "main" in sys.modules:
        del sys.modules["main"]
    main = importlib.import_module("main")
    return importlib.reload(main)


def login(client, username="admin", password="Admin@123456"):
    r = client.post("/api/auth/login", json={"username": username, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def main_test():
    # Production docs must be disabled.
    prod_db = Path(tempfile.mkdtemp()) / "prod.db"
    main = fresh({
        "SOC_DEMO_MODE": "0", "SOC_DB_PATH": str(prod_db),
        "SOC_WAZUH_WEBHOOK_TOKEN": "ProdW@123456",
        "SOC_ADMIN_PASSWORD": "ProdAdmin@123456",
        "SOC_SUPERVISOR_PASSWORD": "ProdSup@123456",
        "SOC_ANALYST_PASSWORD": "ProdAnalyst@123456",
    })
    with TestClient(main.app) as client:
        assert client.get("/docs").status_code == 404
        assert client.get("/openapi.json").status_code == 404
    
    # A demo database must not silently enter production with known credentials.
    switch_db = Path(tempfile.mkdtemp()) / "switch.db"
    main = fresh({"SOC_DEMO_MODE": "1", "SOC_DB_PATH": str(switch_db)})
    with TestClient(main.app) as client:
        assert client.post("/api/auth/login", json={"username": "admin", "password": "Admin@123456"}).status_code == 200
    main = fresh({
        "SOC_DEMO_MODE": "0", "SOC_DB_PATH": str(switch_db),
        "SOC_WAZUH_WEBHOOK_TOKEN": "ProdW@123456",
        "SOC_ADMIN_PASSWORD": "ProdAdmin@123456",
        "SOC_SUPERVISOR_PASSWORD": "ProdSup@123456",
        "SOC_ANALYST_PASSWORD": "ProdAnalyst@123456",
    })
    try:
        with TestClient(main.app):
            raise AssertionError("default demo credential guard did not fire")
    except RuntimeError as exc:
        assert "default demo credential" in str(exc)

    # Edge timestamps must never crash the API with an OverflowError/500.
    main = fresh({"SOC_DEMO_MODE": "1", "SOC_DB_PATH": str(Path(tempfile.mkdtemp()) / "edge.db")})
    with TestClient(main.app) as client:
        h = login(client)
        for i, ts in enumerate(("0001-01-01T00:00:00Z", "9999-12-31T23:59:59Z"), 1):
            r = client.post("/api/alerts/sync", headers=h, json={
                "alert_id": f"edge-{i}", "timestamp": ts, "event_type": "brute_force",
                "source_ip": "1.1.1.1", "username": "admin", "asset": "srv",
                "asset_criticality": 5, "threat": 5, "impact": 5, "context": 5,
            })
            assert r.status_code in (200, 400, 422), r.text
            assert r.status_code != 500, r.text

    # Limit abuse, Wazuh token and 50-way correlation/concurrency.
    main = fresh({
        "SOC_DEMO_MODE": "1",
        "SOC_DB_PATH": str(Path(tempfile.mkdtemp()) / "stress.db"),
        "SOC_WAZUH_WEBHOOK_TOKEN": "sec",
        "SOC_MAX_BODY_BYTES": "65536",
    })
    with TestClient(main.app) as client:
        h = login(client)
        assert client.get("/api/incidents?offset=1000001", headers=h).status_code == 422
        assert client.get("/api/incidents/NOPE?event_offset=1000001", headers=h).status_code == 422
        assert client.get("/api/incidents/NOPE?audit_offset=1000001", headers=h).status_code == 422
        assert client.post("/api/alerts/sync", headers=h, json={"event_type": "x", "raw": {"x": "a" * 70000}}).status_code == 413
        assert client.post("/api/webhooks/wazuh", json={"id": "x"}).status_code == 401

        wazuh = {
            "timestamp": "2026-10-03T18:30:00.000+0000", "id": "wz-deep",
            "rule": {"id": "5710", "level": 16, "description": "multiple failed logins", "groups": ["authentication_failed"]},
            "agent": {"id": "001", "name": "srv"}, "manager": {"name": "wm"},
            "data": {"srcip": "198.51.100.10", "dstip": "192.0.2.10", "dstuser": "admin"},
            "soc": {"asset_criticality": 5, "business_impact": 5, "context_score": 5},
        }
        wr = client.post("/api/webhooks/wazuh/sync", json=wazuh, headers={"X-SOC-Webhook-Token": "sec"})
        assert wr.status_code == 200, wr.text
        iid = wr.json()["incident_id"]
        repeat = client.post("/api/webhooks/wazuh/sync", json=wazuh, headers={"X-SOC-Webhook-Token": "sec"})
        assert repeat.status_code == 200 and repeat.json()["event_id"] == wr.json()["event_id"]
        detail = client.get(f"/api/incidents/{iid}", headers=h).json()
        assert detail["rule_level"] == 16
        assert detail["evidence"]["integration"]["rule_level"] == 16

        def send(i):
            r = client.post("/api/alerts/sync", headers=h, json={
                "alert_id": f"cc-{i}", "timestamp": "2026-10-03T20:00:00Z",
                "source": "wazuh", "source_ip": f"198.51.100.{(i % 200) + 20}",
                "event_type": "brute_force", "username": "admin", "asset": "srv",
                "asset_criticality": 5, "threat": 5, "impact": 5, "context": 5,
            })
            assert r.status_code == 200, r.text
            return r.json()["incident_id"]
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
            ids = list(pool.map(send, range(50)))
        assert len(set(ids)) == 1
        final = client.get(f"/api/incidents/{ids[0]}", headers=h).json()
        assert final["event_count"] == 50

    print("DEEP_AUDIT_12_OK")


if __name__ == "__main__":
    main_test()

import json, sqlite3, tempfile
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import main

dbpath=Path(tempfile.mkdtemp())/'legacy.db'
con=sqlite3.connect(dbpath)
con.execute('CREATE TABLE incidents (id TEXT PRIMARY KEY, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, title TEXT NOT NULL, event_type TEXT NOT NULL, source TEXT NOT NULL, source_ip TEXT, username TEXT, asset TEXT, score INTEGER NOT NULL, severity TEXT NOT NULL, priority INTEGER NOT NULL, event_count INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT "open", owner TEXT, impact TEXT NOT NULL, recommendation TEXT NOT NULL, evidence TEXT NOT NULL)')
con.execute('CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT NOT NULL, timestamp TEXT NOT NULL, source TEXT NOT NULL, event_type TEXT NOT NULL, payload TEXT NOT NULL)')
con.execute('CREATE TABLE queue (id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT "pending", created_at TEXT NOT NULL)')
con.execute('CREATE TABLE audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT NOT NULL, created_at TEXT NOT NULL, action TEXT NOT NULL, from_status TEXT, to_status TEXT, owner TEXT, note TEXT)')
ev={"first_event":{"timestamp":"2026-10-03T18:00:00+00:00","event_type":"brute_force","username":"admin","asset":"srv-ad-01","source_ip":"192.0.2.50","threat":5,"impact":5,"context":5,"asset_criticality":5}}
con.execute('INSERT INTO incidents VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('LEG-1','2026-10-03T18:00:00+00:00','2026-10-03T18:00:00+00:00','Legacy','brute_force','wazuh','192.0.2.50','admin','srv-ad-01',20,'critical',1,1,'open',None,'high','rec',json.dumps(ev)))
con.commit(); con.close()
main.DB_PATH=dbpath
main.init_db()
con=main.db(); cols={r[1] for r in con.execute('PRAGMA table_info(queue)').fetchall()}; row=con.execute('SELECT fingerprint,last_event_at,asset_criticality,score,severity,priority FROM incidents WHERE id="LEG-1"').fetchone(); con.close()
assert {'claim_token','next_attempt_at'}<=cols
assert row['fingerprint'] and row['asset_criticality']==5
assert row['score']==10 and row['severity']=='critical' and row['priority']==1
print('MIGRATION_OK')

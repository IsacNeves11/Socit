import os, sys, json, tempfile, subprocess, time, re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient

ROOT=Path(__file__).resolve().parents[1]
os.environ['SOC_ENV']='demo'
os.environ['SOC_DEMO_MODE']='1'
os.environ['SOC_DB_PATH']=str(Path(tempfile.mkdtemp(prefix='soc-v271-deep-'))/'audit.db')
os.environ.pop('SOC_TRUSTED_PROXY_CIDRS',None)
for k in ['SOC_DB_HOST','SOC_DB_PORT','SOC_DB_NAME','SOC_DB_USER','SOC_DB_PASSWORD']:
    os.environ.pop(k,None)
sys.path.insert(0,str(ROOT))
import main

main.WAZUH_WEBHOOK_TOKEN='audit-token-271'

with TestClient(main.app) as c:
    # 1 public health minimal disclosure
    h=c.get('/api/health'); assert h.status_code==200 and 'queue_size' not in h.json() and 'database' not in h.json()
    assert c.get('/api/health/details').status_code==401
    # 2 protected health details after login
    r=c.post('/api/auth/login',json={'username':'admin','password':'Admin@123456'}); assert r.status_code==200
    token=r.json()['access_token']; auth={'Authorization':f'Bearer {token}'}
    d=c.get('/api/health/details',headers=auth); assert d.status_code==200 and 'queue_size' in d.json()
    # 3 session token is not persisted by frontend
    appjs=(ROOT/'frontend/js/app.js').read_text()
    assert 'sessionStorage.setItem(AUTH_STORAGE' not in appjs and 'let authToken = "";' in appjs
    # 4 demo controls are hidden by default and gated
    html=(ROOT/'frontend/index.html').read_text()
    assert 'demo-only' in html and 'SOCV2.wazuhSync' in appjs and 'if(!demoEnvironment)' in appjs
    # 5 backend is the only incident source; no stale frontend/mock queue fallback remains
    assert 'clearLocalCache()' not in appjs and 'seedAlerts' not in appjs and 'alerts=[];' in appjs
    assert 'dados reais ocultados por segurança' in appjs
    # 6 CSV injection neutralization
    assert 'csvSafe' in appjs and '/^[=+\\-@]/' in appjs
    # 7 real owner user id assignment
    payload={'alert_id':'owner-1','source':'qa','event_type':'brute_force','username':'admin','asset':'srv-owner','asset_criticality':5,'threat':5,'impact':5,'context':5}
    rr=c.post('/api/alerts/sync',json=payload,headers=auth); assert rr.status_code==200
    iid=rr.json()['incident_id']
    analyst_login=c.post('/api/auth/login',json={'username':'analyst','password':'Analyst@123456'}); assert analyst_login.status_code==200
    ah={'Authorization':f"Bearer {analyst_login.json()['access_token']}"}
    users=c.get('/api/users',headers=auth); assert users.status_code==200
    analyst=next(u for u in users.json()['items'] if u['username']=='analyst')
    rr=c.patch(f'/api/incidents/{iid}/status',json={'status':'investigating','owner_user_id':analyst['id'],'owner':'spoofed'},headers=ah)
    assert rr.status_code==200 and rr.json()['owner']=='Analista SOC'
    detail=c.get(f'/api/incidents/{iid}',headers=ah).json(); assert detail['owner_user_id']==analyst['id']
    # 8 invalid owner rejected
    rr=c.patch(f'/api/incidents/{iid}/status',json={'status':'investigating','owner_user_id':'missing'},headers=ah); assert rr.status_code==400
    # Analyst cannot assign an incident to another user.
    rr=c.patch(f'/api/incidents/{iid}/status',json={'status':'investigating','owner_user_id':next(u['id'] for u in users.json()['items'] if u['username']=='supervisor')},headers=ah); assert rr.status_code==403
    # 9 HTTP forwarded proto trusted only for configured proxy
    os.environ['SOC_TRUSTED_PROXY_CIDRS']='10.0.0.0/8'
    # TestClient source is testclient, so a spoofed header must not satisfy HTTPS.
    main.SOC_TRUSTED_PROXY_NETWORKS=main._parse_proxy_networks('10.0.0.0/8')
    os.environ['SOC_REQUIRE_HTTPS']='1'; main.SOC_REQUIRE_HTTPS=True
    rr=c.get('/api/auth/me',headers={'X-Forwarded-Proto':'https','Authorization':analyst_login.json()['access_token'] if False else ah['Authorization']})
    assert rr.status_code==400
    main.SOC_REQUIRE_HTTPS=False
    # 10 migration schema has owner_user_id and indexes
    con=main.db(); cols=main._columns(con,'incidents'); assert 'owner_user_id' in cols
    idx=list(con.execute("SELECT name FROM sqlite_master WHERE type='index' AND name='idx_incidents_owner_user'")); assert idx
    con.close()
    # 11 semantic timestamp correlation across offset representations
    base={'source':'qa','event_type':'brute_force','username':'timeadmin','asset':'srv-time','asset_criticality':5,'threat':5,'impact':5,'context':5}
    iid1,_=main.process_alert({**base,'alert_id':'time-a','timestamp':'2026-10-04T15:00:00+00:00','source_ip':'10.0.0.1'})
    iid2,_=main.process_alert({**base,'alert_id':'time-b','timestamp':'2026-10-04T12:04:00-03:00','source_ip':'10.0.0.2'})
    assert iid1==iid2
    # 12 same alert ID under concurrency remains one event
    con=main.db();
    try:
        # fresh alert id, queue-level race simulated by direct process calls
        con.close()
    except: pass
    def proc(i):
        return main.process_alert({**base,'alert_id':'same-concurrent','timestamp':'2026-10-04T15:10:00+00:00','source_ip':f'10.1.0.{i}'})
    with ThreadPoolExecutor(max_workers=12) as pool:
        vals=list(pool.map(proc,range(12)))
    ids={x[1] for x in vals}; assert len(ids)==1
    con=main.db(); count=con.execute("SELECT COUNT(*) FROM events WHERE source='qa' AND alert_id='same-concurrent'").fetchone()[0]; con.close(); assert count==1
    # 13 source IP list is bounded against evidence growth
    for i in range(1500):
        main.process_alert({**base,'alert_id':f'ip-{i}','timestamp':'2026-10-04T16:00:00+00:00','source_ip':f'10.2.{i//255}.{i%255}'})
    con=main.db(); row=con.execute("SELECT evidence FROM incidents WHERE fingerprint=? ORDER BY updated_at DESC LIMIT 1",(main.incident_fingerprint(base),)).fetchone(); con.close()
    ev=main._load_evidence(row[0]); assert len(ev.get('source_ips',[]))<=1000 and ev.get('source_ips_truncated') is True
    # 14 malformed external timestamp is a client error, not an internal server error
    malformed={"id":"bad-ts","timestamp":"definitely-not-a-date","rule":{"id":"100100","level":12,"description":"bad timestamp"},"agent":{"id":"001","name":"srv"},"data":{"srcip":"10.0.0.10"}}
    rr=c.post('/api/webhooks/wazuh/sync',json=malformed,headers={'X-SOC-Webhook-Token':'audit-token-271'}); assert rr.status_code==422
    # 15 out-of-range Wazuh levels are safely clamped to the model maximum
    extreme={"id":"level-99","timestamp":"2026-10-04T17:00:00+00:00","rule":{"id":"100101","level":99,"description":"extreme level"},"agent":{"id":"001","name":"srv"},"data":{"srcip":"10.0.0.11"}}
    rr=c.post('/api/webhooks/wazuh/sync',json=extreme,headers={'X-SOC-Webhook-Token':'audit-token-271'}); assert rr.status_code==200
    iid=rr.json()['incident_id']; detail=c.get(f'/api/incidents/{iid}',headers=ah).json(); assert detail['rule_level']==16
    # 16 local pilot placeholders are rejected, preventing accidental insecure deployment.
    assert main._is_placeholder_secret('PUT-A-STRONG-PASSWORD-HERE') is True
    assert main._is_placeholder_secret('REPLACE_WITH_SOC_WAZUH_WEBHOOK_TOKEN') is True

print('V271_DEEP_AUDIT_OK 16/16')

from __future__ import annotations
import asyncio, os, tempfile, threading, subprocess, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from starlette.requests import Request
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def test_demo_password_rejected():
    env=os.environ.copy(); env.update({"SOC_ENV":"pilot","SOC_WAZUH_WEBHOOK_TOKEN":"A"*32,"SOC_ADMIN_PASSWORD":"Admin@123456","SOC_SUPERVISOR_PASSWORD":"SomeSupervisor@2026!","SOC_ANALYST_PASSWORD":"SomeAnalyst@2026!","SOC_DB_HOST":"postgres","SOC_DB_PASSWORD":"SomePostgres@2026!","SOC_TRUSTED_ORIGINS":"https://soc.local"})
    p=subprocess.run([sys.executable,"-c","from backend import main; main._validate_pilot_security_config()"],cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
    assert p.returncode != 0 and "default demo credential" in (p.stdout+p.stderr)

async def _body_limit():
    import backend.main as main
    chunks=[b"{"+b"a"*(main.MAX_BODY_BYTES//2), b"b"*(main.MAX_BODY_BYTES//2), b"c"*10, b"}"]
    i=0
    async def receive():
        nonlocal i
        j=i; i+=1
        if j < len(chunks): return {"type":"http.request","body":chunks[j],"more_body":j<len(chunks)-1}
        return {"type":"http.disconnect"}
    scope={"type":"http","method":"POST","path":"/api/alerts","headers":[],"query_string":b"","scheme":"http","client":("127.0.0.1",1),"server":("127.0.0.1",8000)}
    req=Request(scope,receive); called=False
    async def nxt(_):
        nonlocal called; called=True; return None
    resp=await main.body_limit_middleware(req,nxt)
    assert resp.status_code==413 and not called

def test_body_limit(): asyncio.run(_body_limit())

def test_bridge_204():
    class H(BaseHTTPRequestHandler):
        def do_POST(self): self.send_response(204); self.end_headers()
        def log_message(self,*a): pass
    s=HTTPServer(("127.0.0.1",0),H); threading.Thread(target=s.serve_forever,daemon=True).start()
    p=subprocess.run([sys.executable,str(ROOT/"integrations/wazuh_integration.py"),str(ROOT/"backend/examples/wazuh_bruteforce.json"),f"http://127.0.0.1:{s.server_port}/hook"],capture_output=True,text=True,timeout=15); s.shutdown()
    assert p.returncode != 0 and "inesperado" in (p.stdout+p.stderr)

def test_compact_evidence():
    with tempfile.TemporaryDirectory() as td:
        env=os.environ.copy(); env.update({"SOC_ENV":"demo","SOC_DEMO_MODE":"1","SOC_DB_PATH":str(Path(td)/"soc.db")})
        code='''from backend import main\nmain.init_db()\na={"alert_id":"BIG-EVID-1","timestamp":main.now_iso(),"source":"qa","event_type":"malware","title":"big","source_ip":"198.51.100.10","asset":"srv-01","asset_criticality":5,"threat":5,"impact":5,"context":5,"raw":{"blob":"x"*100000}}\ni,_=main.process_alert(a)\ncon=main.db(); raw=con.execute("SELECT evidence FROM incidents WHERE id=?",(i,)).fetchone()[0]; con.close()\nassert len(raw)<50000, len(raw)\nprint("COMPACT_EVIDENCE_OK")'''
        p=subprocess.run([sys.executable,"-c",code],cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
        assert p.returncode==0, p.stdout+p.stderr

def test_sqlite_concurrent_init():
    with tempfile.TemporaryDirectory() as td:
        dbp=str(Path(td)/"concurrent.db"); env=os.environ.copy(); env.update({"SOC_ENV":"demo","SOC_DEMO_MODE":"1","SOC_DB_PATH":dbp})
        code='from backend import main; main.init_db(); print("INIT_OK")'
        procs=[subprocess.Popen([sys.executable,"-c",code],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(8)]
        bad=[]
        for p in procs:
            out,err=p.communicate(timeout=30)
            if p.returncode!=0: bad.append((p.returncode,out,err))
        assert not bad, bad

if __name__=="__main__":
    test_demo_password_rejected(); test_body_limit(); test_bridge_204(); test_compact_evidence(); test_sqlite_concurrent_init(); print("PREFLIGHT_V272_OK 5/5")

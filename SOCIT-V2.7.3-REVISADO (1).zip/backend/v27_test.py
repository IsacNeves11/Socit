import os, tempfile, importlib, sys
from pathlib import Path

with tempfile.TemporaryDirectory() as td:
    os.environ['SOC_DB_PATH'] = str(Path(td)/'test.db')
    os.environ['SOC_DEMO_MODE'] = '1'
    if 'main' in sys.modules: del sys.modules['main']
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import main
    from fastapi.testclient import TestClient

    with TestClient(main.app) as client:
        assert client.get('/api/health').status_code == 200
        assert client.get('/api/incidents').status_code == 401

        r=client.post('/api/auth/login',json={'username':'analyst','password':'Analyst@123456'})
        assert r.status_code==200, r.text
        analyst=r.json(); at=analyst['access_token']; ah={'Authorization':f'Bearer {at}'}
        assert client.get('/api/auth/me',headers=ah).status_code==200
        assert client.get('/api/users',headers=ah).status_code==403

        alert={'alert_id':'v26-001','timestamp':'2026-10-03T18:00:00+00:00','source':'192.168.1.50','target':'srv-ad-01','user':'admin','threat_type':'brute_force','events_count':47,'asset_criticality':5,'business_impact':5,'context_score':5,'description':'47 tentativas'}
        r=client.post('/api/alerts/sync',json=alert,headers=ah)
        assert r.status_code==200, r.text
        iid=r.json()['incident_id']
        d=client.get(f'/api/incidents/{iid}',headers=ah); assert d.status_code==200
        assert d.json()['score']==9 and d.json()['severity']=='critical' and d.json()['event_count']==47

        r=client.patch(f'/api/incidents/{iid}/status',json={'status':'investigating'},headers=ah)
        assert r.status_code==200 and r.json()['owner']=='Analista SOC', r.text
        r=client.patch(f'/api/incidents/{iid}/status',json={'status':'escalated'},headers=ah)
        assert r.status_code==403, r.text

        r=client.post('/api/auth/login',json={'username':'supervisor','password':'Supervisor@123456'})
        assert r.status_code==200
        st=r.json()['access_token']; sh={'Authorization':f'Bearer {st}'}
        r=client.patch(f'/api/incidents/{iid}/status',json={'status':'escalated'},headers=sh)
        assert r.status_code==200, r.text
        r=client.post('/api/auth/logout',headers=sh); assert r.status_code==200
        assert client.get('/api/incidents',headers=sh).status_code==401

        r=client.post('/api/auth/login',json={'username':'admin','password':'Admin@123456'})
        assert r.status_code==200
        admin=r.json()['access_token']; ad={'Authorization':f'Bearer {admin}'}
        assert client.get('/api/users',headers=ad).status_code==200
        r=client.post('/api/users',json={'username':'qauser','display_name':'QA User','role':'analyst','password':'QaUser@123456'},headers=ad)
        assert r.status_code==200, r.text
        uid=r.json()['user']['id']
        r=client.patch(f'/api/users/{uid}',json={'active':False},headers=ad); assert r.status_code==200, r.text
        r=client.post('/api/auth/login',json={'username':'qauser','password':'QaUser@123456'}); assert r.status_code==401

        # Login rate limiting is per process/IP.
        for _ in range(5):
            rr=client.post('/api/auth/login',json={'username':'analyst','password':'wrong-pass'})
            assert rr.status_code in (401,429)
        assert client.post('/api/auth/login',json={'username':'analyst','password':'wrong-pass'}).status_code==429

        # Password policy and self-protection.
        r=client.post('/api/auth/password',json={'current_password':'Admin@123456','new_password':'short'},headers=ad)
        assert r.status_code==422 or r.status_code==400
        r=client.patch('/api/users/'+json_user_id if False else f'/api/users/{""}',json={'role':'analyst'},headers=ad)
        assert r.status_code in (307,404,422,405)

    print('V27_AUTH_RBAC_OK')

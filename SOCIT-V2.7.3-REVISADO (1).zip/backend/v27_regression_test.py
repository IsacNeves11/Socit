import os,tempfile,sys
from pathlib import Path
from fastapi.testclient import TestClient
sys.path.insert(0,str(Path(__file__).resolve().parent))
import main

# Production-style startup with explicit secrets.
os.environ['SOC_DEMO_MODE']='0'
os.environ['SOC_ADMIN_PASSWORD']='ProdAdmin@123456'
os.environ['SOC_SUPERVISOR_PASSWORD']='ProdSupervisor@123456'
os.environ['SOC_ANALYST_PASSWORD']='ProdAnalyst@123456'
os.environ['SOC_WAZUH_WEBHOOK_TOKEN']='ProdWazuh@123456'
main = __import__('importlib').reload(main)
main.DB_PATH=Path(tempfile.mkdtemp())/'prod.db'
with TestClient(main.app) as c:
    h=c.get('/api/health'); assert h.status_code==200 and h.json()['version']=='2.7.3' and 'wazuh_webhook' not in h.json()
    r=c.post('/api/auth/login',json={'username':'admin','password':'ProdAdmin@123456'}); assert r.status_code==200
    ah={'Authorization':f"Bearer {r.json()['access_token']}"}
    details=c.get('/api/health/details',headers=ah); assert details.status_code==200 and details.json()['wazuh_webhook']['token_required'] is True
    users=c.get('/api/users',headers=ah); assert users.status_code==200
    admins=[u for u in users.json()['items'] if u['role']=='admin' and u['active']]
    assert len(admins)>=1
    uid=admins[0]['id']
    # Cannot remove the only active admin.
    if len(admins)==1:
        rr=c.patch(f'/api/users/{uid}',json={'active':False},headers=ah); assert rr.status_code==400
    # Password change revokes active session.
    rr=c.post('/api/auth/password',json={'current_password':'ProdAdmin@123456','new_password':'NewProdAdmin@123456'},headers=ah)
    assert rr.status_code==200
    assert c.get('/api/auth/me',headers=ah).status_code==401
print('V27_REGRESSION_OK')

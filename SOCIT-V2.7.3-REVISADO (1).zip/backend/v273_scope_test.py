"""Regression checks for the V2.7.3 scope fixes."""
import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

with tempfile.TemporaryDirectory(prefix="soc-v273-scope-") as td:
    os.environ["SOC_ENV"] = "demo"
    os.environ["SOC_DEMO_MODE"] = "1"
    os.environ["SOC_DB_PATH"] = str(Path(td) / "soc.db")
    for key in ("SOC_ADMIN_PASSWORD", "SOC_SUPERVISOR_PASSWORD", "SOC_ANALYST_PASSWORD"):
        os.environ.pop(key, None)
    import main
    from fastapi.testclient import TestClient

    # Explicit matrix checks: isolated login, repeated login, off-hours and sensitive area.
    assert main.score_alert({"event_type":"login_incorrect","events_count":1,"timestamp":"2026-10-21T15:00:00-03:00","username":"joao","asset":"app","threat":1,"impact":1,"asset_criticality":1,"context":1}) == (2,"low",4)
    assert main.score_alert({"event_type":"brute_force","events_count":47,"timestamp":"2026-10-21T15:00:00-03:00","username":"admin","asset":"srv-auth","threat":4,"impact":2,"asset_criticality":2,"context":2}) == (7,"critical",1)
    assert main.score_alert({"event_type":"malware","events_count":2,"timestamp":"2026-10-21T02:00:00-03:00","username":"diretoria_fin","asset":"srv-finance","threat":5,"impact":5,"asset_criticality":5,"context":5}) == (10,"critical",1)
    assert main.score_alert({"event_type":"port_scan","timestamp":"2026-10-21T15:00:00-03:00","threat":3,"impact":3,"asset_criticality":3,"context":3}) == (3,"low",4)
    with TestClient(main.app) as client:
        health = client.get("/api/health")
        assert health.status_code == 200 and health.json()["version"] == "2.7.3"
        # Sensitive data endpoints must not become public even if the static shell loads.
        assert client.get("/api/incidents").status_code == 401
        assert client.get("/api/metrics").status_code == 401
        login = client.post("/api/auth/login", json={"username":"admin","password":"Admin@123456"})
        assert login.status_code == 200, login.text
        headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

        alert = {
            "alert_id":"V273-SCORE-10", "source":"soc-test", "event_type":"malware",
            "title":"Test critical alert", "timestamp":"2026-10-21T02:00:00-03:00", "source_ip":"203.0.113.50", "username":"diretoria_fin",
            "asset":"srv-finance-critical", "asset_criticality":5, "threat":5, "impact":5, "context":5,
        }
        created = client.post("/api/alerts/sync", json=alert, headers=headers)
        assert created.status_code == 200, created.text
        incident_id = created.json()["incident_id"]
        detail = client.get(f"/api/incidents/{incident_id}", headers=headers)
        assert detail.status_code == 200 and detail.json()["score"] == 10 and detail.json()["severity"] == "critical"

        # Critical 10/10 alerts must document containment before resolution.
        blocked = client.patch(f"/api/incidents/{incident_id}/status", json={"status":"resolved"}, headers=headers)
        assert blocked.status_code == 400 and "containment action note" in blocked.text
        resolved = client.patch(f"/api/incidents/{incident_id}/status", json={"status":"resolved","note":"IP bloqueado e endpoint isolado"}, headers=headers)
        assert resolved.status_code == 200, resolved.text

        false_positive = client.patch(f"/api/incidents/{incident_id}/status", json={"status":"false_positive","note":"Evento confirmado como benigno"}, headers=headers)
        assert false_positive.status_code == 200, false_positive.text
        metrics = client.get("/api/metrics", headers=headers).json()
        assert metrics["active_incidents"] == 0

    print("V273_SCOPE_OK: score 1-10, auth, critical containment note, false-positive status")

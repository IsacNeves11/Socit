$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
python -m compileall -q backend
python backend/pilot_config_test.py
python backend/replay_idempotency_test.py
python backend/self_test.py
python backend/full_audit_test.py
python backend/migration_test.py
python backend/wazuh_test.py
python backend/wazuh_bridge_test.py
python backend/v27_test.py
python backend/v27_http_test.py
python backend/v27_regression_test.py
python backend/v27_security_test.py
python backend/v273_scope_test.py
python backend/login_throttle_persistence_test.py
python backend/deep_audit_test.py
python backend/v271_deep_audit_test.py
Write-Host "V2.7.3 AUDIT PASS" -ForegroundColor Green

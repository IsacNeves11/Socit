@echo off
setlocal
cd /d %~dp0

if not exist .venv (
    echo [1/4] Criando ambiente virtual...
    python -m venv .venv
    if errorlevel 1 goto :error
) else (
    echo [1/4] Ambiente virtual encontrado.
)

call .venv\Scripts\activate
if errorlevel 1 goto :error

echo [2/4] Atualizando pip...
python -m pip install --upgrade pip --disable-pip-version-check
if errorlevel 1 goto :error

echo [3/4] Instalando dependencias...
python -m pip install --only-binary=:all: -r backend\requirements.txt
if errorlevel 1 goto :error

echo [4/4] Iniciando SOC Intelligent Triage V2.7.3...
if "%SOC_PORT%"=="" set "SOC_PORT=8000"
if "%SOC_HOST%"=="" set "SOC_HOST=127.0.0.1"
start "SOC Backend" cmd /k "cd /d %~dp0 && call .venv\Scripts\activate && set SOC_PORT=%SOC_PORT% && set SOC_HOST=%SOC_HOST% && python -m uvicorn backend.main:app --host %SOC_HOST% --port %SOC_PORT%"

set /a tries=0
:waitloop
set /a tries+=1
powershell -NoProfile -Command "try { $r=Invoke-RestMethod -Uri ('http://127.0.0.1:%SOC_PORT%/api/health') -TimeoutSec 1; if($r.status -eq 'online' -and $r.version -eq '2.7.3'){exit 0}; exit 1 } catch { exit 1 }"
if not errorlevel 1 goto :openbrowser
if %tries% GEQ 30 goto :error
>nul ping 127.0.0.1 -n 2
goto :waitloop

:openbrowser
start "SOC Frontend" http://127.0.0.1:%SOC_PORT%
exit /b 0

:error
echo.
echo [ERRO] A inicializacao nao foi concluida ou a porta %SOC_PORT% ja esta sendo usada.
echo Verifique a mensagem acima.
pause
exit /b 1

# Relatório de Auditoria — SOC Intelligent Triage V2.7.2

## Objetivo

Tentar quebrar a V2.7.1 antes do teste real de campo, incluindo segurança, entrada externa, Wazuh, fila, concorrência, persistência e implantação.

## Achados corrigidos

1. Credenciais demo padrão agora são recusadas em `pilot`/`production` mesmo quando explicitamente configuradas nas variáveis de ambiente.
2. O limite de body passou a ser aplicado durante o streaming da requisição, reduzindo risco de consumir payload arbitrariamente grande sem `Content-Length` confiável.
3. O bridge Wazuh não trata mais qualquer resposta 2xx como sucesso: exige HTTP 200/202 e rejeita `accepted:false`.
4. Evidências de incidente usam snapshots compactos; o payload completo permanece em `events.payload`, com hash e excerpt limitado.
5. Scripts PowerShell de backup/restore usam I/O binário direto no processo Docker.

## Bateria executada

Todos os testes legados disponíveis na V2.7.1 passaram novamente após as mudanças, incluindo:

- SELF_TEST_OK
- FULL_AUDIT_OK 5/5
- MIGRATION_OK
- WAZUH_TEST_OK
- WAZUH_BRIDGE_OK
- WAZUH_BRIDGE_RETRY_OK
- V27_AUTH_RBAC_OK
- V27_HTTP_TEST_OK
- V27_REGRESSION_OK
- V27_SECURITY_OK
- DEEP_AUDIT_12_OK
- V271_DEEP_AUDIT_OK 16/16
- PILOT_CONFIG_OK
- REPLAY_IDEMPOTENCY_OK
- LOGIN_THROTTLE_PERSISTENCE_OK
- PREFLIGHT_V272_OK 5/5

Também passaram compilação Python, sintaxe JavaScript, validação YAML e checagens estáticas de release.

## Limitação

Este ambiente não possui Docker/PostgreSQL/Wazuh reais. Portanto a execução E2E desses componentes continua obrigatoriamente no teste da máquina/VM de laboratório.

## Status

**V2.7.2 aprovada como candidata a teste de campo controlado.**

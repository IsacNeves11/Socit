# SOC Intelligent Triage — V2.7.3

Protótipo acadêmico de triagem e priorização inteligente de alertas para SOC, preparado para demonstração e validação controlada. Não é uma plataforma homologada nem deve ser conectado a ambientes reais sem revisão e autorização da equipe responsável.

## O problema

Ferramentas de segurança geram grande volume de eventos, muitos repetidos ou de baixa prioridade. O produto consolida eventos relacionados, calcula risco e organiza uma fila operacional para o analista.

## Fluxo do produto

```text
Wazuh / SIEM
    ↓
Webhook / API
    ↓
Normalização
    ↓
Fila persistida
    ↓
Correlação
    ↓
Risk Engine
    ↓
Incidente
    ↓
Dashboard SOC
    ↓
Analista → investigação → resolução/escala
```

## O que a V2.7 adiciona

- PostgreSQL como banco recomendado para piloto/produção.
- SQLite mantido para desenvolvimento local e testes.
- Camada de compatibilidade de banco para o mesmo pipeline funcionar nos dois ambientes.
- Dockerfile com usuário não-root, `no-new-privileges`, filesystem somente leitura e healthcheck.
- `compose.yaml` com PostgreSQL persistente e backend isolado.
- Configuração por `.env` sem secrets no código.
- Modo `SOC_ENV=demo`, `pilot` e `production`.
- Em `pilot/production`, SQLite é recusado e credenciais demo são recusadas.
- Matriz de score 1–10: falha de login isolada (+1), falhas repetidas (+4), fora de horário (+2), Financeiro/Diretoria/executivo (+3); teto 10.
- Dashboard, fila e indicadores usam a mesma fonte de dados; o frontend não inventa alertas quando o backend retorna zero.
- Incidentes com score 10 exigem observação de contenção antes de serem encerrados; há status “Falso positivo”.
- `X-Request-ID`, logs estruturados básicos e `/api/ready`.
- Métricas operacionais de MTTA, MTTR e tempo médio de processamento da fila.
- Backups/restore do PostgreSQL em PowerShell e shell script.
- Documentação de implantação, TLS/reverse proxy, rollback e operação.
- Integração Wazuh customizada preservando metadados e IDs MITRE quando presentes.
- Segurança do webhook com token constante em comparação de tempo.

## Requisitos de desenvolvimento local

- Windows 10/11 ou Linux/macOS.
- Python 3.13 ou superior para execução local (o container Docker usa Python 3.14).
- Para desenvolvimento rápido: SQLite.
- Para piloto: Docker + PostgreSQL.

## Desenvolvimento local

**Somente no modo demo local:** usuários iniciais são `admin` / `Admin@123456`, `supervisor` / `Supervisor@123456` e `analyst` / `Analyst@123456`. Nunca reutilize essas credenciais em `pilot` ou `production`; o backend recusa esses valores nesses ambientes.

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install --only-binary=:all: -r backend\requirements.txt
$env:SOC_ENV='demo'
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Ou:

```powershell
.\run-v2.7.bat
```

## Piloto com Docker + PostgreSQL

1. Copie `.env.example` para `.env`.
2. Troque todas as senhas/tokens e defina o domínio real do dashboard em `SOC_TRUSTED_ORIGINS`.
3. Use `SOC_ENV=pilot`.
4. Para teste privado sem TLS, use `.env.local-pilot.example` e defina `SOC_REQUIRE_HTTPS=0`. Em ambiente empresarial, use `SOC_REQUIRE_HTTPS=1` e TLS no reverse proxy aprovado.
5. Execute:

```powershell
docker compose up -d --build
```

6. Valide:

```powershell
Invoke-RestMethod http://127.0.0.1:8080/api/health
Invoke-RestMethod http://127.0.0.1:8080/api/ready
```

A porta publicada no compose é `127.0.0.1:8080` de propósito; não exponha diretamente o backend na internet.

## TLS e rede

O aplicativo pode exigir HTTPS, mas em uma empresa a terminação TLS deve ficar no reverse proxy/load balancer aprovado pela organização. O proxy deve encaminhar `X-Forwarded-Proto: https` quando `SOC_REQUIRE_HTTPS=1`.

Não use certificados de demonstração como certificados de produção.

## PostgreSQL

Variável principal:

```text
SOC_DB_URL=postgresql://usuario:senha@host:5432/soc
```

A V2.7.3 usa PostgreSQL no modo piloto/produção. O schema é criado automaticamente na primeira execução e é versionado pela tabela `schema_meta`.

## Wazuh

A integração customizada utiliza o contrato documentado pelo Wazuh: o nome começa por `custom-`, o primeiro argumento do script é o arquivo JSON do alerta, seguido pela `api_key` e `hook_url`; `alert_format=json` faz o Integrator preparar o alerta em JSON.

Arquivo de integração:

```text
integrations/custom-soc-intelligent-triage
```

Exemplo de `ossec.conf`:

```xml
<integration>
  <name>custom-soc-intelligent-triage</name>
  <hook_url>https://soc.example.com/api/webhooks/wazuh</hook_url>
  <api_key>SEU_TOKEN</api_key>
  <level>10</level>
  <alert_format>json</alert_format>
</integration>
```

O Wazuh documenta níveis de regra de 0 a 16 e suporta filtros por nível, rule ID, grupo e localização de evento.

## Autenticação e RBAC

Papéis:

- `analyst`: investigação, atualização de incidentes e resolução.
- `supervisor`: funções de analista + escala de incidentes.
- `admin`: gestão de usuários e funções administrativas.

Senhas usam PBKDF2-HMAC-SHA256 com salt aleatório. Tokens de sessão são armazenados somente como hash.

## Operação do incidente

```text
open
  ↓
investigating
  ↓
resolved
```

ou:

```text
open / investigating
        ↓
escalated
```

Ações operacionais são registradas na auditoria com ator, horário, status anterior/novo, responsável e observação.

Os playbooks são deliberadamente orientativos nesta fase. Nenhuma ação destrutiva em infraestrutura é disparada automaticamente.

## Métricas de valor

A API `/api/metrics` expõe:

- quantidade de incidentes e eventos.
- redução por correlação.
- distribuição por severidade/status.
- MTTA médio: criação → primeira investigação.
- MTTR médio: criação → resolução.
- tempo médio de processamento dos jobs concluídos.

Essas métricas são o principal instrumento para um piloto empresarial: compare o processo atual da empresa com o processo após a adoção da triagem.

## Backup e rollback

Windows:

```powershell
.\deploy\backup.ps1
.\deploy\restore.ps1 -BackupFile .\backups\soc-YYYYMMDD-HHMMSS.dump
```

Linux/macOS:

```bash
./deploy/backup.sh
```

Antes de atualização de schema ou nova versão:

1. faça backup;
2. registre a versão atual;
3. aplique a mudança em ambiente de piloto;
4. valide health/ready e fluxo de alerta;
5. só então promova para produção.

## Testes

Instale também as dependências de desenvolvimento/teste: `python -m pip install -r backend\requirements-dev.txt`. Os testes são scripts executáveis independentes (não exigem `pytest`).

Os testes ativos da V2.7.3 ficam em `backend/` e cobrem:

- normalização e score.
- correlação/deduplicação.
- fila persistida e retry.
- concorrência.
- autenticação/RBAC.
- integração Wazuh/bridge.
- migração de schema SQLite.
- métricas operacionais.
- headers e superfície HTTP.
- compatibilidade da versão.
- score, autenticação sem token, nota de contenção para score 10 e status “Falso positivo”.

Execute o conjunto em um ambiente de desenvolvimento com:

```powershell
python backend\pilot_config_test.py
python backend\replay_idempotency_test.py
python backend\login_throttle_persistence_test.py
python backend\self_test.py
python backend\full_audit_test.py
python backend\migration_test.py
python backend\wazuh_test.py
python backend\wazuh_bridge_test.py
python backend\wazuh_bridge_retry_test.py
python backend\v27_test.py
python backend\v27_http_test.py
python backend\v27_regression_test.py
python backend\v27_security_test.py
python backend\deep_audit_test.py
python backend\v271_deep_audit_test.py
python backend\v273_scope_test.py
python -m compileall -q backend integrations
```

Consulte `AUDIT_REPORT_V2.7.3_VALIDATION.md` para o resultado da execução de revisão desta entrega. Os testes locais não substituem a validação no Windows, em PostgreSQL/Docker ou com uma instância real do Wazuh.

## Limites explícitos do piloto

Antes de considerar o piloto aceito, execute a stack Docker com PostgreSQL e confirme o fluxo Wazuh real conforme `PILOT_ACCEPTANCE.md`. A auditoria local valida código e configuração, mas não substitui a validação no ambiente autorizado da empresa.

A V2.7.3 é uma base de piloto, não uma plataforma enterprise final. Antes de uso produtivo amplo, valide com a equipe de segurança da empresa: SSO/MFA, política de secrets, TLS/certificados, backup automatizado, retenção de dados, monitoramento, centralização de logs, teste de carga, DAST/SAST, gestão de vulnerabilidades e integração com os controles existentes.

## Referências oficiais

- Wazuh Docker deployment: https://documentation.wazuh.com/current/deployment-options/docker/wazuh-container.html
- Wazuh external/custom integrations: https://documentation.wazuh.com/current/user-manual/manager/integration-with-external-apis.html
- Wazuh integration reference: https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/integration.html

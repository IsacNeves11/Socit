# Correcao local de login — V2.7.3

Esta versao corrigida inclui uma regra CSS para respeitar o atributo HTML `hidden`, evitando que a estrutura do dashboard seja exibida por baixo/simultaneamente com a tela de login.

## Desbloqueio de tentativas
O backend limita a 5 falhas por janela de 5 minutos. A alternativa mais simples e sem mexer no banco e aguardar 5 minutos desde a ultima tentativa e depois tentar uma vez com a senha correta.

Se precisar limpar imediatamente o bloqueio local, primeiro pare o servidor na janela `SOC Backend` com Ctrl+C. Execute `reset-local-login-throttle.ps1` a partir desta pasta e digite `SIM`. O script cria um backup consistente de `backend/soc.db` e apaga apenas as linhas de `login_throttle` para `127.0.0.1` e `::1`. Ele nao apaga incidentes, eventos, usuarios ou auditoria.

Nao execute esse script em uma instancia compartilhada, publicada ou de producao. Ele e apenas para desbloqueio do ambiente local de desenvolvimento.

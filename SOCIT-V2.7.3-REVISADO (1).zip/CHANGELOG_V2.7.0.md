# Changelog — V2.7.0

## Pilot Ready

A V2.7.0 transforma a solução em uma base de piloto empresarial.

### Infraestrutura
- PostgreSQL recomendado para piloto/produção.
- SQLite mantido para desenvolvimento local.
- Dockerfile não-root, filesystem read-only, cap-drop e no-new-privileges.
- Compose com PostgreSQL persistente e healthcheck.

### Segurança
- Configuração por ambiente (`demo`, `pilot`, `production`).
- Token Wazuh obrigatório em piloto/produção.
- Credenciais demo rejeitadas em piloto/produção.
- Headers de segurança e limite de payload.
- Sessões/RBAC e auditoria existentes mantidos.

### Operação
- `/api/ready`.
- Métricas de MTTA, MTTR e processamento da fila.
- Backup/restore PostgreSQL.
- Runbook de implantação, rollback e aceitação.

### Confiabilidade
- Correlação PostgreSQL com advisory lock.
- Fila com lease e `SKIP LOCKED` em PostgreSQL.
- Idempotência forte para replay de alertas, inclusive após limpeza da fila.
- Evidências e metadados Wazuh preservados.

### Validação
- Suíte regressiva completa da V2.6.x.
- Testes específicos de piloto e idempotência.
- Validação estática do Compose.

# Relatório de Auditoria — SOC Intelligent Triage V2.7.0

**Objetivo:** avaliar a V2.7.0 como base de piloto empresarial, procurando regressões e falhas de persistência, idempotência, autenticação/RBAC, integração Wazuh, segurança HTTP, configuração e implantação.

## Status

**PASS — base adequada para início de piloto controlado, condicionada aos critérios de aceitação do ambiente da empresa.**

## Resultado da suíte

```text
COMPILE_OK
PILOT_CONFIG_OK
REPLAY_IDEMPOTENCY_OK
SELF_TEST_OK
FULL_AUDIT_OK 5/5
MIGRATION_OK
WAZUH_TEST_OK
WAZUH_BRIDGE_OK
V27_AUTH_RBAC_OK
V27_HTTP_TEST_OK
V27_REGRESSION_OK
V27_SECURITY_OK
DEEP_AUDIT_12_OK
ARTIFACT_STATIC_OK
```

## Correções relevantes na revisão final

1. **Replay após limpeza da fila:** um `alert_id` já processado não volta ao worker. O replay vira um registro terminal `deduplicated`, mantendo rastreabilidade.
2. **Segredos de exemplo:** valores `CHANGE-ME`, `YOUR-*`, `REPLACE-*` e outros placeholders são recusados em `pilot`/`production`.
3. **Produção sem HTTPS:** `SOC_ENV=production` exige `SOC_REQUIRE_HTTPS=1`.
4. **Origens de exemplo:** domínios `example.com`, `example.org` e `example.net` são recusados em `pilot`/`production`.
5. **Dependência PostgreSQL:** `psycopg[binary]==3.3.6`, versão atual com wheels para CPython 3.14 no PyPI.
6. **Scripts de teste:** labels e roteiro foram alinhados para V2.7.

## Áreas verificadas

- API e contratos HTTP.
- Normalização e scoring.
- Correlação por fingerprint e janela temporal.
- Eventos fora de ordem.
- Deduplicação e idempotência.
- Fila persistida, retry, lease e recuperação.
- Concorrência.
- PostgreSQL compatibility layer e schema.
- Migração do schema legado.
- Autenticação, sessões e RBAC.
- Headers e superfície HTTP.
- Limites de payload/paginação.
- Integração Wazuh e bridge.
- Preservação de evidências e metadados.
- Métricas operacionais.
- Configuração de `demo`, `pilot` e `production`.
- Compose, Dockerfile e arquivos de implantação.
- Limpeza de artefatos temporários.

## Limites

O ambiente desta auditoria não possui Docker Desktop nem um PostgreSQL real disponível. Portanto, a execução real de `docker compose up`, a persistência efetiva em PostgreSQL e a cadeia Wazuh → Integrator → webhook ainda precisam ser demonstradas no ambiente autorizado do piloto.

Não há afirmação de que o produto esteja pronto para produção enterprise ampla. Antes disso, devem ser concluídos SSO/MFA conforme política da empresa, TLS/reverse proxy aprovado, gestão de secrets, backup/restore real, DAST/SAST, análise de dependências, teste de carga, retenção, observabilidade e validação de segurança pelo cliente.

## Critério de promoção

A promoção de piloto para produção depende do `PILOT_ACCEPTANCE.md` e da aprovação da equipe responsável pelo ambiente.

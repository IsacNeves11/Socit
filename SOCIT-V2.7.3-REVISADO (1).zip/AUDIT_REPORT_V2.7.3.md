# Relatório de revisão — V2.7.3

## Alterações verificadas por código

1. O score é calculado na escala 1–10 pela matriz de contexto: baseline das quatro dimensões (1–5), login isolado +1, falhas repetidas +4, fora de horário +2 e Financeiro/Diretoria/executivo +3, limitado a 10. A severidade é Crítico (7–10), Alto (6), Médio (4–5) e Baixo (1–3).
2. A migração de schema v7 para v8 normaliza scores existentes e recalcula severidade/prioridade sem apagar incidentes, eventos, logs ou usuários.
3. A fila de incidentes não é mais preenchida com alertas de demonstração do frontend enquanto os indicadores usam dados vazios do backend.
4. O status `false_positive` é aceito pelo backend e disponível na interface.
5. Encerramento de score 10 exige nota de contenção; a regra impede fechamento silencioso, mas não garante que a ação externa tenha sido executada.
6. Os endpoints privados existentes continuam usando `require_auth`; o endpoint público de saúde permanece somente para liveness.

## Verificação pendente no computador do usuário

- Executar os testes automatizados em Windows no ambiente-alvo.
- Confirmar a autenticação no navegador após atualização e desbloqueio local.
- Verificar a instalação/integração com Wazuh e permissões reais antes de qualquer piloto.

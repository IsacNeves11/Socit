# Atualizar para SOC Intelligent Triage V2.7.3 sem perder dados (Windows)

Este pacote é uma atualização corretiva da V2.7.2 para a V2.7.3. A atualização migra o banco SQLite antigo automaticamente quando o servidor inicia. Siga a ordem abaixo para preservar incidentes, eventos, usuários e auditoria.

## 1. Parar a versão antiga

1. Vá à janela do terminal chamada `SOC Backend` que está executando a V2.7.2.
2. Pressione `Ctrl+C` e espere o servidor parar. Feche também a janela do navegador que estava usando, se preferir.

## 2. Extrair a nova versão em uma pasta separada

1. Extraia `SOC-Intelligent-Triage-V2.7.3-CORRIGIDA.zip` para uma pasta nova, por exemplo:
   `C:\Users\SEU_USUARIO\Downloads\SOC-Intelligent-Triage-V2.7.3-CORRIGIDA`
2. Não extraia por cima da pasta antiga. Isso mantém a V2.7.2 disponível para rollback.
3. Não copie a pasta `.venv` da versão antiga; o inicializador da nova versão criará seu próprio ambiente.

## 3. Copiar o banco antigo para a pasta nova

Antes de iniciar a V2.7.3 pela primeira vez:

1. Na pasta antiga, localize `backend\soc.db`.
2. Copie esse arquivo para `backend\soc.db` dentro da pasta nova.
3. Se o Windows perguntar se quer substituir um arquivo, confira se está copiando para a pasta V2.7.3 correta. Preserve também qualquer cópia de segurança que já exista.

**Não apague nem recrie `soc.db`.** Se a versão antiga estiver usando outro banco (por exemplo, PostgreSQL ou um caminho definido por variável de ambiente), não use este passo para SQLite; consulte o administrador do ambiente.

## 4. Limpar apenas o bloqueio local de login

Com o servidor parado, abra o PowerShell na pasta raiz da nova versão (a pasta onde está `reset-local-login-throttle.ps1`) e execute:

```powershell
.\reset-local-login-throttle.ps1
```

Digite `SIM` quando o script solicitar. Ele criará um arquivo de backup do banco antes de remover apenas os registros de bloqueio para `127.0.0.1` e `::1`. Ele não apaga incidentes, eventos, usuários ou auditoria.

Se o script disser que o banco ou a tabela `login_throttle` não existe, pare e confira se copiou o banco certo. Não apague o banco para contornar o erro.

## 5. Iniciar a V2.7.3

Dê dois cliques em `run-v2.bat`. A primeira execução pode precisar de internet para instalar as dependências Python. Deixe a janela `SOC Backend` aberta.

Quando estiver pronto, o endereço local é:

`http://127.0.0.1:8000`

Para confirmar a versão, abra:

`http://127.0.0.1:8000/api/health`

O resultado deve indicar `"version":"2.7.3"` e `"environment":"demo"`.

## 6. Entrar e validar a fila

- Use a senha que já existia no banco copiado. A senha padrão `Admin@123456` só funciona se não foi alterada anteriormente.
- A fila não mostrará alertas fictícios. Se o banco não tiver incidentes ativos, os cartões e a fila mostrarão zero até que alertas reais ou de demonstração sejam inseridos.
- Para teste local, use o botão `Simular alerta` depois de entrar e confirme se o incidente aparece na fila e nos contadores.
- Um incidente com score 10 só pode ser marcado como resolvido depois que o analista registrar uma observação de contenção com pelo menos 10 caracteres.

## Limites importantes

Este pacote é para desenvolvimento/demonstração local. Não conecte a produção da empresa nem habilite bloqueios reais de firewall/EDR sem revisão, autorização e teste do SOC responsável. O campo de contenção registra a ação documentada pelo analista; ele não executa sozinho o bloqueio de rede.

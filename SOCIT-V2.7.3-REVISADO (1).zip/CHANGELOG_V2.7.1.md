# SOC Intelligent Triage — V2.7.2

Revisão de segurança e confiabilidade do release Pilot Ready.

## Correções
- Saúde pública reduzida a liveness; detalhes operacionais exigem autenticação.
- Correlação SQLite passa a comparar timestamps semanticamente.
- Atribuição de incidente pode referenciar usuário ativo por ID.
- Criação e alteração de usuários usam transações e tratam corridas de unicidade.
- Troca de senha é transacional.
- Token de sessão não é persistido no navegador; fica somente em memória.
- Cache local e dados simulados são desativados fora do ambiente demo.
- Controles de simulação ficam ocultos fora do demo.
- Exportação CSV neutraliza fórmulas iniciadas por `=`, `+`, `-` ou `@`.
- Bridge Wazuh limita tamanho de alerta e usa retry para falhas transitórias.
- Exemplo Wazuh do Compose usa a porta publicada 8080.
- `.env`/backups protegidos por `.gitignore` e `.dockerignore`.
- PostgreSQL do Compose usa parâmetros separados de conexão, evitando problemas com caracteres especiais em senhas de URL.

## Limites
O release ainda exige validação com Docker/PostgreSQL/Wazuh reais no ambiente autorizado da empresa.

- Proteção de rate limit de login persistida no banco para cenários com múltiplos workers.
- Bootstrap PostgreSQL serializado e criação de usuários padrão idempotente.
- Deduplicação concorrente de `alert_id` protegida por lock de identidade no PostgreSQL.
- Atribuição de responsável vinculada a usuário ativo e controle de permissão para atribuição a terceiros.
- Frontend limpa métricas em indisponibilidade de dados reais.
- Teste do bridge Wazuh cobre retry e rejeição de URL insegura.
